package com.example.SystemLibraries.services;

import com.example.SystemLibraries.models.Basket;
import com.example.SystemLibraries.models.Subscription;
import com.example.SystemLibraries.views.BasketView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Service
public class BasketViewService {
    @Autowired
    BasketService basketService;
    @Autowired
    UserService userService;
    @Autowired
    EditionService editionService;
    public List<BasketView> getAll(Long userId) throws IOException {
        List<BasketView> list = new ArrayList<>();
        List<Basket> baskets = basketService.getAlsoBasketsByUserId(userId);
        for(Basket basket : baskets){
            Subscription subscription = new Subscription();
            long maxCountCopies = 0L;
            if(basket.getLibId() != null && basket.getLibId()>0){
                subscription = userService.getSubs(userId, basket.getLibId());
                maxCountCopies = editionService.getCountInLib(basket.getLibId(), basket.getEdId());
            }
            list.add(new BasketView(basket, subscription, maxCountCopies));
        }
        return list;
    }
    public BasketView get(Basket basket) throws IOException {
        Subscription subscription = userService.getSubs(basket.getUsId(), basket.getLibId());
        long maxCountCopies = editionService.getCountInLib(basket.getLibId(), basket.getEdId());

        return new BasketView(basket, subscription, maxCountCopies);
    }
    public BasketView save(Basket basket) throws IOException {
        basket = basketService.save(basket);
        Subscription subscription = userService.getSubs(basket.getUsId(), basket.getLibId());
        long maxCountCopies = editionService.getCountInLib(basket.getLibId(), basket.getEdId());

        return new BasketView(basket, subscription, maxCountCopies);
    }

    private List<Long> getListIds(String ids) {
        List<Long> list = new ArrayList<>();
        List<String> arr = new ArrayList<>();
        for (String s : ids.split(", ")){
            list.add(Long.parseLong(s, 10));
        }
        return list;
    }
    public List<BasketView> getListBasketByIds(String ids) throws IOException {
        List<BasketView> baskets = new ArrayList<>();
        for(Long id : getListIds(ids)){
            BasketView basket = get(basketService.getBasket(id));
            if(basket != null)
                baskets.add(basket);
        }
        return baskets;
    }
}
