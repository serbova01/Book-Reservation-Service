package com.example.SystemLibraries.restControllers;

import com.example.SystemLibraries.models.Genre;
import com.example.SystemLibraries.services.GenreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/rest/genre")
public class GenreRestController {
    @Autowired
    public GenreService genreService;
    @GetMapping("/get-all")
    public List<Genre> getAllGenre(){
        return genreService.getAllGenres();
    }
    @GetMapping("/get-all/{id}")
    public List<Genre> getAllGenre(@PathVariable Long id){
        return genreService.getAllGenresByLibId(id);
    }
    @PostMapping("/save")
    public Genre save(@RequestBody Genre genre){
        return genreService.save(genre);
    }
    @GetMapping("/get/{id}")
    public Genre getGenreById(@PathVariable Long id){
        return genreService.getGenre(id);
    }
    @DeleteMapping("/delete/{id}")
    public void delete(@PathVariable Long id){
        genreService.deleteById(id);
    }
}
