package com.example.SystemLibraries.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Subscription {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String numbers;
    private int actualNumber;
    private int cur_count_issueds;
    private int max_count_issueds;
    @Column(name = "library_id", insertable=false, updatable=false)
    private Long libId;
    @ManyToOne
    @JsonIgnore
    //@JsonManagedReference(value="subscription-library")
    private Library library;
    @OneToMany(mappedBy = "subscription")
    @JsonIgnore
    //@JsonBackReference(value="reservation-subscription")
    private List<Reservation> reservations;
    @OneToMany(mappedBy = "subscription")
    @JsonIgnore
    //@JsonBackReference(value="request-subscription")
    private List<Request> requests;
    @OneToMany(mappedBy = "subscription")
    @JsonIgnore
    //@JsonBackReference(value="postponed-subscription")
    private List<Postponed> postponeds;
    @OneToMany(mappedBy = "subscription")
    @JsonIgnore
    //@JsonBackReference(value="historyReader-subscription")
    private List<HistoryReader> historyReaders;
    @OneToMany(mappedBy = "readerId.subscription")
    @JsonIgnore
    //@JsonBackReference(value="reader-subscription")
    private List<Reader> readers;

    public String getNumbersStr(List<Integer> numbers){
        String str = "";
        for (int i=0; i<numbers.size()-1; i++){
            str = str.concat(numbers.get(i) + ", ");
        }
        str = str.concat(numbers.get(numbers.size()-1).toString());
        return str;
    }
    public List<Integer> getNumbersList(){
        List<Integer> list = new ArrayList<>();
        String[] nums = numbers.split(",");
        for(String num : nums){
            list.add(Integer.valueOf(num));
        }
        return list;
    }

    public void setLibrary(Library library) {
        this.library = library;
        setLibId(library.getId());
    }

    public int getCur_count_issueds() {
        return historyReaders.stream().filter(hr -> hr.isRelevance()).toList().size();
    }

    public int getMax_count_issueds() {
        return readers.size() * 5;
    }
    public boolean getMayBeReserv(){
        return historyReaders.stream().filter(hr->hr.isRelevance() && hr.getDateReturn().isBefore(LocalDate.now())).count()==0;
    }

    public Long getId() {
        return id;
    }

    public String getNumbers() {
        return numbers;
    }

    public int getActualNumber() {
        return actualNumber;
    }

    public Long getLibId() {
        return libId;
    }

    public Library getLibrary() {
        return library;
    }

    public List<Reservation> getReservations() {
        return reservations;
    }

    public List<Request> getRequests() {
        return requests;
    }

    public List<Postponed> getPostponeds() {
        return postponeds;
    }

    public List<HistoryReader> getHistoryReaders() {
        return historyReaders;
    }

    public List<Reader> getReaders() {
        return readers;
    }
}
