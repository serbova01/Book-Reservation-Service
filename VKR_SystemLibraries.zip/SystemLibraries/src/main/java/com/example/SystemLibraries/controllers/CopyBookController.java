package com.example.SystemLibraries.controllers;

import com.example.SystemLibraries.formModels.CopyBookEdit;
import com.example.SystemLibraries.models.*;
import com.example.SystemLibraries.services.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/copyBook")
public class CopyBookController {
    @Autowired
    private CopyBookService copyBookService;
    @Autowired
    private EditionService editionService;
    @Autowired
    private DepartmentService departmentService;
    @Autowired
    private LibraryService libraryService;
    @Autowired
    private UserService userService;
    private String[] messages={
            "Заполните обязательное поле: Инвентарный номер.",
            "Выберете издание из списка",
            "У выбранного произведения не указан автор.",
            "Экземпляр книги с таким инвентарным номером уже существует."
    };
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/list")
    public String list(Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            model.addAttribute("user", user);
            List<CopyBook> list = copyBookService.getAllCopyBooks();
            // Библиотекарь
            list = list.stream().filter(cb ->
                    cb.getDepartment().getLibrary().getId() ==
                            user.getLibrary().getId()).collect(Collectors.toList());
            // Библиотекарь
            model.addAttribute("copyBooks", list);
            model.addAttribute("insertable", true);
            model.addAttribute("deletable", false);
            //model.addAttribute("user", user);
            return "copyBook/list";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/list-available")
    public String listAvailable(Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            model.addAttribute("user", user);
            List<CopyBook> list = copyBookService.getAllCopyBooksIsAvailableByLibId(user.getLibId());
            model.addAttribute("copyBooks", list);
            model.addAttribute("insertable", true);
            model.addAttribute("deletable", true);
            //model.addAttribute("user", user);
            return "copyBook/list";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/list-reserv")
    public String listReservs(Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            model.addAttribute("user", user);
            List<CopyBook> list = copyBookService.getReservedCopyBooksByLibId(user.getLibId());
            model.addAttribute("copyBooks", list);
            model.addAttribute("insertable", false);
            model.addAttribute("deletable", false);
            //model.addAttribute("user", user);
            return "copyBook/list";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/list-writtenoff")
    public String listWritenOff(Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            model.addAttribute("user", user);
            List<CopyBook> list = copyBookService.getAllWrittenOffByLibId(user.getLibId());
            model.addAttribute("copyBooks", list);
            model.addAttribute("insertable", false);
            model.addAttribute("deletable", false);
            //model.addAttribute("user", user);
            return "copyBook/list";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/details/{id}")
    public String details(Model model, @PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB) {
            model.addAttribute("user", user);
            if(copyBookService.getAllCopyBooks().stream().filter(item -> item.getId() == id &&
                    (user.getLibId() == null || item.getDepartment().getLibId() == user.getLibId())).count()>0){
                CopyBook copyBook = copyBookService.getCopyBook(id);
                String subsNum = null;
                List<Reservation> reservationList = copyBook.getReservations().stream().filter(reserv ->
                        reserv.getSubscription().getLibrary().getId() == copyBook.getDepartment().getLibrary().getId()).toList();
                if(!reservationList.isEmpty()){
                    subsNum = String.valueOf(reservationList.get(0).getSubscription().getActualNumber());
                }else{
                    List<Request> requests = copyBook.getRequests().stream().filter(reserv ->
                            reserv.getSubscription().getLibrary().getId() == copyBook.getDepartment().getLibrary().getId()).toList();
                    if(!requests.isEmpty()){
                        subsNum = String.valueOf(requests.get(0).getSubscription().getActualNumber());
                    }
                }
                model.addAttribute("copyBook", copyBook);
                model.addAttribute("subsNum", subsNum);
                //model.addAttribute("user", copyBookService.findUserByLogin(principal.getName()));
                return "copyBook/details";
            }else
                return "redirect:/copyBook/list";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @RequestMapping(path = {"/create", "/create/search"})
    public String create(Model model, Principal principal, String keyword){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            model.addAttribute("user", user);
            //User user =  copyBookService.findUserByLogin(principal.getName());
            List<Edition> editions;
            if(keyword!=null && keyword.length() >= 1 && Character.isLetterOrDigit(keyword.toCharArray()[0])) {
                editions = editionService.getByKeyword(keyword);
            }else
                editions = editionService.getAllEditions();
            model.addAttribute("editions", editions);
            model.addAttribute("keyword", keyword);
            model.addAttribute("copyBook", new CopyBookEdit());
            //model.addAttribute("user", user);
            return "copyBook/create";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/chooseEd/{id}")
    public String create(Model model, @PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            model.addAttribute("user", user);
            //User user =  copyBookService.findUserByLogin(principal.getName());
            List<Edition> editions = editionService.getAllEditions();
            Edition edition = editionService.getEdition(id);
            editions.remove(edition);
            CopyBookEdit copyBookEdit = new CopyBookEdit();
            copyBookEdit.setEdition(edition);
            model.addAttribute("editions", editions);
            model.addAttribute("copyBook", copyBookEdit);
            //model.addAttribute("user", user);
            return "copyBook/create";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @PostMapping("/create")
    public String create(@ModelAttribute CopyBookEdit copyBook, Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        List<Edition> editions = editionService.getAllEditions();
        model.addAttribute("editions", editions);
        model.addAttribute("copyBook", copyBook);
        if (copyBook.getInvNumber() == null || copyBook.getInvNumber().trim().length() < 1){
            model.addAttribute("message", messages[0]);
            return "copyBook/create";
        }
        if (copyBook.getEdition() == null){
            model.addAttribute("message", messages[1]);
            return "copyBook/create";
        }
        if (copyBook.getEdition().getBook().getAuthors().isEmpty()){
            model.addAttribute("message", messages[2]);
            return "copyBook/create";
        }
        copyBook.setLibrary(libraryService.getLibrary(user.getLibId()));
        if(copyBook.getInvNumber().equals("б/н") || copyBookService.getByInvNumberInLib(copyBook.getInvNumber(),
                copyBook.getLibrary().getId()) == null){
            CopyBook newCopyBook = copyBook.convertToCopyBook(new CopyBook());
            newCopyBook.setStatusInThisLib("в наличии");
            copyBookService.saveWithAnDep(newCopyBook, copyBook.getLibrary());
            return "redirect:/copyBook/list";
        }else{
            model.addAttribute("message", messages[3]);
            return "copyBook/create";
        }
    }
    /*@PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/edit/{id}")
    public String edit(Model model, @PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            model.addAttribute("user", user);
            //User user =  copyBookService.findUserByLogin(principal.getName());
            List<Edition> editions = editionService.getAllEditions();
            List<Library> libraries = libraryService.getAllLibraries();

            model.addAttribute("editions", editions);
            model.addAttribute("departments", libraries);
            model.addAttribute("copyBook", new CopyBookEdit(copyBookService.getCopyBook(id)));
            //model.addAttribute("user", user);
            return "copyBook/edit";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/edit-m/{id_m}/{id}")
    public String edit(Model model, @PathVariable Long id, @PathVariable("id_m") Long id_m, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            model.addAttribute("user", user);
            if(id_m == 1)
                model.addAttribute("message", messages[0]);
            else{
                if(id_m == 3)
                    model.addAttribute("message", "Экземпляр книги с таким инвентарным номером уже существует.");
                else
                    model.addAttribute("message", "У выбранного произведения не указан автор.");
            }
            List<Edition> editions = editionService.getAllEditions();
            List<Library> libraries = libraryService.getAllLibraries();
            model.addAttribute("editions", editions);
            model.addAttribute("departments", libraries);
            model.addAttribute("copyBook", new CopyBookEdit(copyBookService.getCopyBook(id)));
            //model.addAttribute("user", user);
            return "author/edit";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @PostMapping("/edit")
    public String edit(@ModelAttribute CopyBookEdit copyBook, Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        if (copyBook.getInvNumber() == null || copyBook.getInvNumber().trim().length() < 1){
            return "copyBook/edit";
        }
        if (copyBook.getEdition().getBook().getAuthors().isEmpty()){
            return "copyBook/edit";
        }
        //инвентарный номер уникален в пределах своей библиотеки
        CopyBook copyBookCheck = copyBookService.getByInvNumberInLib(copyBook.getInvNumber(), copyBook.getLibrary().getId());
        if (copyBookCheck != null && copyBookCheck.getId() != copyBook.getId()){
            return "copyBook/edit";
        }else{
            CopyBook newCopyBook = copyBookService.getCopyBook(copyBook.getId());
            if(newCopyBook.getDepartment().getLibrary().getId() != copyBook.getLibrary().getId() ||
                    newCopyBook.getEdition().getBook().getId() != copyBook.getEdition().getBook().getId()){
                copyBookService.saveWithAnDep(copyBook.convertToCopyBook(new CopyBook()), copyBook.getLibrary());
            }else{
                copyBookService.save(copyBook.convertToCopyBook(copyBook.convertToCopyBook(newCopyBook)));
            }
            return "redirect:/copyBook/list";
        }
    }*/
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            copyBookService.deleteById(id);
            return "redirect:/copyBook/list";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/write_off/{id}")
    public String write_off(@PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            copyBookService.writeOffCopyBook(id);
            return "redirect:/copyBook/list";
        }else
            return "redirect:/home";
    }
}
