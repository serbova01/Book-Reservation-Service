package com.example.SystemLibraries.controllers;

import com.example.SystemLibraries.models.*;
import com.example.SystemLibraries.services.*;
import com.example.SystemLibraries.views.IssuedHRView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.security.Principal;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/historyReader")
public class HistoryReaderController {
    @Autowired
    private HistoryReaderService mainServer;
    @Autowired
    private CopyBookService copyBookService;
    @Autowired
    private SubscriptionService subscriptionService;
    @Autowired
    private UserService userService;
    @Autowired
    private IssuedHRService issuedHRService;

    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/list")
    public String list(Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            model.addAttribute("user", user);
            List<HistoryReader> list = mainServer.getAllHistoryReadersByLibId(user.getLibId());
            model.addAttribute("historyReaders", list);
            return "historyReader/list";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/delayedList")
    public String delayedList(Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            model.addAttribute("user", user);
            List<HistoryReader> list = mainServer.getAllDelayedHR(user.getLibId());
            model.addAttribute("historyReaders", list);
            return "historyReader/delayedList";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/returnedList")
    public String returnedList(Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            model.addAttribute("user", user);
            List<HistoryReader> list = mainServer.getAllReturnedHR(user.getLibId());
            model.addAttribute("historyReaders", list);
            return "historyReader/list";
        }else
            return "redirect:/home";

    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/issuedList")
    public String issuedList(Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            model.addAttribute("user", user);
            List<HistoryReader> list = mainServer.getAllIssuedsHR(user.getLibId());
            model.addAttribute("historyReaders", list);
            return "historyReader/issuedList";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/details/{id}")
    public String details(Model model, @PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB) {
            model.addAttribute("user", user);
            HistoryReader historyReader = mainServer.getHistoryReader(id);
            model.addAttribute("historyReader", historyReader);
            //model.addAttribute("user", user);
            return "historyReader/details";
        }else
            return "redirect:/home";
    }

    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/create")
    public String create(Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            model.addAttribute("user", user);
            //Библиотекарь
            List<CopyBook> copyBooks = copyBookService.getAllCopyBooksIsAvailableByLibId(user.getLibId());
            List<Subscription> subscriptions = subscriptionService.getAllSubscriptions();
            //List<Subscription> subscribers = mainServer.findAllSubs();
            model.addAttribute("copyBooks", copyBooks);
            model.addAttribute("subscribers", subscriptions);
            model.addAttribute("historyReader", new HistoryReader());
            //model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
            return "historyReader/create";
        }else
            return "redirect:/home";
    }

    @PreAuthorize("hasAuthority('LIB')")
    @PostMapping("/create")
    public String create(@ModelAttribute HistoryReader historyReader, Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
            mainServer.add(historyReader);
            return "redirect:/historyReader/list";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/edit/{id}")
    public String edit(Model model, @PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            model.addAttribute("user", user);
            HistoryReader hr = mainServer.getHistoryReader(id);
            List<CopyBook> copyBooks = copyBookService.getAllCopyBooksIsAvailableByLibId(user.getLibId()).
                    stream().filter(c -> c.getInvNumber() != hr.getCopyBook().getInvNumber()).collect(Collectors.toList());
            List<Subscription> subscriptions = subscriptionService.getAllSubscriptionsByLibId(user.getLibId());
            model.addAttribute("copyBooks", copyBooks);
            model.addAttribute("subscribers", subscriptions);
            model.addAttribute("historyReader", hr);
            //model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
            return "historyReader/edit";
        }else
            return "redirect:/home";
    }

    @PreAuthorize("hasAuthority('LIB')")
    @PostMapping("/edit")
    public String edit(@ModelAttribute HistoryReader historyReader, Model model){
        mainServer.save(historyReader);
        return "redirect:/historyReader/list";
    }

    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            mainServer.deleteById(id);
            return "redirect:/historyReader/list";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB') || hasAuthority('USER')")
    @GetMapping("/extendIssuedBook/{idHR}")
    public String extendIssuedBook(Model model, @PathVariable("idHR") Long idHR, Principal principal) throws IOException {
        User user =  userService.getUserByUsername(principal.getName());
        HistoryReader historyReader = mainServer.getHistoryReader(idHR);
        if(user.getRole() == Role.LIB || (user.getRole() == Role.USER &&
                userService.getSubsList(user.getId()).stream().filter(subs ->
                        subs.getId() == historyReader.getSubsId()).count()>0)){
            mainServer.prolongHR(idHR);
            if(user.getRole() == Role.LIB){
                return "redirect:/historyReader/issuedList";
            }else{
                return "redirect:/user/issuedList";
            }
        }else {
            return "redirect:/home";
        }
    }
    @PreAuthorize("hasAuthority('LIB') || hasAuthority('USER')")
    @GetMapping("/extendDelayedBook/{idHR}")
    public String extendDelayedBook(Model model, @PathVariable("idHR") Long idHR, Principal principal) throws IOException {
        User user =  userService.getUserByUsername(principal.getName());
        HistoryReader historyReader = mainServer.getHistoryReader(idHR);
        if(user.getRole() == Role.LIB || (user.getRole() == Role.USER &&
                userService.getSubsList(user.getId()).stream().filter(subs ->
                        subs.getId() == historyReader.getSubsId()).count()>0)){
            mainServer.prolongHR(idHR);
            if(user.getRole() == Role.LIB){
                return "redirect:/historyReader/delayedList";
            }else{
                return "redirect:/user/delayedList";
            }
        }else {
            return "redirect:/home";
        }
    }
    @PreAuthorize("hasAuthority('USER')")
    @GetMapping("/extendIssuedsBook")
    public String extendIssuedsBook(Model model, Principal principal) throws IOException {
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.USER){
            List<IssuedHRView> hrViews = issuedHRService.getAllIssuedByUserEmail(user.getId());
            prolongHRListUser(hrViews);
            return "redirect:/user/issuedList";
        }else {
            return "redirect:/home";
        }
    }
    @PreAuthorize("hasAuthority('USER')")
    @GetMapping("/extendDelayedsBook")
    public String extendDelayedsBook(Model model, Principal principal) throws IOException {
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.USER){
            List<IssuedHRView> hrViews = issuedHRService.getAllDelayedByUserEmail(user.getId());
            prolongHRListUser(hrViews);
            return "redirect:/user/delayedList";
        }else {
            return "redirect:/home";
        }
    }

    private void prolongHRListUser(List<IssuedHRView> hrViews) throws IOException {
        for(IssuedHRView issuedHRView : hrViews){
            mainServer.prolongHR(issuedHRView.getId());
        }
    }
    private void prolongHRList(List<HistoryReader> hrViews) throws IOException {
        for(HistoryReader issuedHRView : hrViews){
            mainServer.prolongHR(issuedHRView.getId());
        }
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/extendBook/{idSubs}")
    public String extendBook(Model model, @PathVariable("idSubs") Long idSubs, Principal principal) throws IOException {
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            Subscription subscription = subscriptionService.getSubscription(idSubs);
            prolongHRList(subscription.getHistoryReaders().stream().filter(historyReader ->
                    historyReader.isRelevance()).toList());
            return "redirect:/subscriber/details/" + idSubs;
        }else {
            return "redirect:/home";
        }
    }
}
