package com.example.SystemLibraries.formModels;

import com.example.SystemLibraries.models.Library;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LibDetails {
    private Long id;
    private String name;
    private String cityNumber;
    private String email;
    private String street;
    private String house;
    private double latitude;
    private double longitude;

    public LibDetails(Library library){
        id = library.getId();
        name = library.getName();
        cityNumber = library.getCityNumber();
        email = library.getEmail();
        if(library.getAddress() != null){
            String[] address = library.getAddress().split(", ");
            street = address[0];
            house = address[1];
        }else{
            street = "";
            house = "";
        }
        latitude=library.getLatitude();
        longitude = library.getLongitude();
    }

    public Library convertToLibrary(Library library){
        library.setName(name);
        library.setAddress(street + ", " + house);
        library.setEmail(email);
        library.setCityNumber(cityNumber);
        return  library;
    }

    public boolean isNullFields() {
        return name == null || name.length() == 0 || ((cityNumber == null || cityNumber.length() == 0) &&
                (email == null || email.length() == 0)) || street == null || street.length() == 0 ||
                house == null || house.length() == 0;
    }


}
