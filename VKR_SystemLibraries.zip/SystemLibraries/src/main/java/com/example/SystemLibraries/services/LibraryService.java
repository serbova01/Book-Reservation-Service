package com.example.SystemLibraries.services;

import com.example.SystemLibraries.models.Library;
import com.example.SystemLibraries.repositories.LibraryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.util.Streamable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class LibraryService {
    @Autowired
    private LibraryRepository libraryRepository;

    public Library save(Library library){
        return  libraryRepository.save(library);
    }
    public void deleteById(long libraryId){
        libraryRepository.deleteById(libraryId);
    }
    public List<Library> getAllLibraries(){
        List<Library> libraries = new ArrayList<>();
        Streamable.of(libraryRepository.findAll()).forEach(libraries::add);
        return libraries;
    }
    public Library getLibrary(long id){
        return  libraryRepository.findById(id).get();
    }

    public Library getByAddress(String address) {
        return libraryRepository.findByAddress(address);
    }
}
