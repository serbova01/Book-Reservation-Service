package com.example.SystemLibraries.controllers;

import com.example.SystemLibraries.models.*;
import com.example.SystemLibraries.services.GenreService;
import com.example.SystemLibraries.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.annotation.security.RolesAllowed;
import java.security.Principal;
import java.util.List;

@Controller
@RequestMapping("/genre")
public class GenreController {
    @Autowired
    private GenreService mainServer;
    @Autowired
    private UserService userService;

    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/list")
    public String list(Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        List<Genre> list = mainServer.getAllGenres();
        model.addAttribute("genres", list);
        //model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
        return "genre/list";

    }

    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/details/{id}")
    public String details(Model model, @PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        Genre genre = mainServer.getGenre(id);
        model.addAttribute("genre", genre);
        //model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
        return "genre/details";

    }

    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/create")
    public String create(Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        model.addAttribute("genre", new Genre());
        //model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
        return "genre/create";
    }

    @PreAuthorize("hasAuthority('LIB')")
    @PostMapping("/create")
    public String create(@ModelAttribute Genre genre, Model model){
        if (genre.getName()==null || genre.getName().trim().length() < 2){
            model.addAttribute("message", "Заполните обязательное поле: Название");
            return "genre/create";
        }
        if(mainServer.getByName(genre.getName()) == null){
            mainServer.save(genre);
            return "redirect:/genre/list";
        }else{
            model.addAttribute("message", "Жанр с таким названием уже существует.");
            return "genre/create";
        }
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/edit/{id}")
    public String edit(Model model, @PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        model.addAttribute("genre", mainServer.getGenre(id));
        //model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
        return "genre/edit";

    }

    @PreAuthorize("hasAuthority('LIB')")
    @PostMapping("/edit")
    public String edit(@ModelAttribute Genre genre, Model model){
        if (genre.getName()==null || genre.getName().trim().length() < 2){
            model.addAttribute("message", "Заполните обязательное поле: Название");
            return "genre/edit/" + genre.getId();
        }
        Genre genreCheck = mainServer.getByName(genre.getName());
        if (genreCheck != null && genreCheck.getId() != genre.getId()){
            model.addAttribute("genre", genre);
            model.addAttribute("message", "Жанр с таким названием уже существует.");
            return "genre/edit/" + genre.getId();
        }else{
            mainServer.save(genre);
            return "redirect:/genre/list";
        }
    }

    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id, Principal principal){
        //User user =  mainServer.findUserByLogin(principal.getName());
        mainServer.deleteById(id);
        return "redirect:/genre/list";

    }
}
