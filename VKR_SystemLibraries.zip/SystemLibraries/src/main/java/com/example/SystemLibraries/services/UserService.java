package com.example.SystemLibraries.services;

import com.example.SystemLibraries.formModels.UserConfimEmail;
import com.example.SystemLibraries.models.*;
import com.example.SystemLibraries.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.util.Streamable;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private ReaderService readerService;
    @Autowired
    private LibraryService libraryService;

    public User save(User user){
        if(user.getId() != null && user.getId()>0){
            User oldUser = getUser(user.getId());
            if(!oldUser.getPassword().equals(user.getPassword())){
                BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
                user.setPassword(passwordEncoder.encode(user.getPassword()));
            }
            if(!oldUser.getEmail().equals(user.getEmail())){
                for(Reader reader : readerService.getReaderByEmail(oldUser.getEmail())){
                    reader.setEmail(user.getEmail());
                    readerService.save(reader);
                }
            }
        }
        if(user.getLibId()!=null && user.getLibId() > 0){
            user.setLibrary(libraryService.getLibrary(user.getLibId()));
        }
        return  userRepository.save(user);
    }
    public User save(User oldUser, UserConfimEmail newUser){
        if(!oldUser.getEmail().equals(newUser.getEmail())){
            for(Reader reader : readerService.getReaderByEmail(oldUser.getEmail())){
                reader.setEmail(newUser.getEmail());
                readerService.save(reader);
            }
        }
        oldUser.setEmail(newUser.getEmail());
        return  userRepository.save(oldUser);
    }
    public void deleteById(long id){
        userRepository.deleteById(id);
    }
    public List<User> getAllUsers(){
        List<User> users = new ArrayList<>();
        Streamable.of(userRepository.findAll()).forEach(users::add);
        return users;
    }
    public void add(User user, Reader reader){
        reader.setEmail(user.getEmail());
        readerService.save(reader);
        user.setRole(Role.USER);
        userRepository.save(user);
    }
    public User getUser(long id){
        User user = userRepository.findById(id).get();
        return userRepository.findById(id).get();
    }
    public List<Library> getLibsByUserEmail(Long id){
        List<Library> list = new ArrayList<>();
        String email = getUser(id).getEmail();
        List<Reader> readers = readerService.getReaderByEmail(email).stream().toList();
        if(!readers.isEmpty()){
            for (Reader reader : readers){
                list.add(reader.getReaderId().getSubscription().getLibrary());
            }
        }
        return list;
    }
    public long getCountReservs(User user){
        long count = 0;
        if(user != null && user.getId() != null && user.getId()>0){
            for(Subscription subscription : getSubsList(user.getId())){
                count += subscription.getReservations().size();
            }
        }
        return count;
    }
    public User checkByLogin(User user) {
        return userRepository.findByUsernameAndPassword(user.getUsername(), user.getPassword());
    }
    public Reader checkByEmail(User user){
        if(userRepository.findByEmail(user.getEmail()) == null &&
                readerService.getReaderByEmail(user.getEmail()).stream().count() > 0){
            return readerService.getReaderByEmail(user.getEmail()).get(0);
        }
        return new Reader();
    }

    public Subscription getSubs(long usId, long libId){
        List<Reader> readers = readerService.getReaderByEmail(getUser(usId).getEmail()).stream().filter(reader ->
                reader.getReaderId().getSubscription().getLibId() == libId).toList();
        if(readers.isEmpty())
            return new Subscription();
        else
            return readers.get(0).getReaderId().getSubscription();
    }

    public List<Subscription> getSubsList(long usId){
        List<Reader> readers = readerService.getReaderByEmail(getUser(usId).getEmail());
        if(readers.isEmpty())
            return new ArrayList<>();
        else{
            List<Subscription> subscriptions = new ArrayList<>();
            for (Reader reader : readers) {
                subscriptions.add(reader.getReaderId().getSubscription());
            }
            return subscriptions;
        }
    }

    public List<Subscription> getListSubs(Long usId, String libIds) {
        List<Subscription> list = new ArrayList<>();
        for(Long id : getListIds(libIds)){
            Subscription subscription = getSubs(usId, id);
            if(list.stream().filter(l -> l.getId() == subscription.getId()).count() == 0){
                list.add(subscription);
            }
        }
        return list;
    }

    private List<Long> getListIds(String ids) {
        List<Long> list = new ArrayList<>();
        List<String> arr = new ArrayList<>();
        for (String s : ids.split(", ")){
            list.add(Long.parseLong(s, 10));
        }
        return list;
    }

    public User getUserByUsername(String name) {
        return userRepository.findByUsername(name);
    }

    public User getByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    public List<Reader> getReadersById(Long id) {
        String email = getUser(id).getEmail();
        List<Reader> list = readerService.getReaderByEmail(email);
        return list;
    }

    public boolean getMayBeUseEmail(String email) {
        if(getByEmail(email) != null){
            return false;
        }else{
            List<Reader> readers = readerService.getReaderByEmail(email);
            return readerService.getReaderByEmail(email).stream().count() == 0;
        }
    }
}
