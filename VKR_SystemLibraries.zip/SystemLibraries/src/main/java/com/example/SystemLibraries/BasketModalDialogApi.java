package com.example.SystemLibraries;

import com.example.SystemLibraries.formModels.BasketChoose;
import com.example.SystemLibraries.models.Basket;
import com.example.SystemLibraries.models.Library;
import com.example.SystemLibraries.services.BasketService;
import com.example.SystemLibraries.services.EditionService;
import com.example.SystemLibraries.services.LibraryService;
import com.example.SystemLibraries.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/basket")
public class BasketModalDialogApi {
    @Autowired
    private BasketService basketService;
    @Autowired
    UserService userService;
    @Autowired
    EditionService editionService;
    @Autowired
    LibraryService libraryService;

    @GetMapping("/{basketId}")
    public BasketChoose findById(@PathVariable("basketId") long basketId) throws IOException {
        Basket basket = basketService.getBasket(basketId);
        BasketChoose basketChoose = new BasketChoose(basket, getLibs(basket));
        //basketChoose.getLibraryList().add(basketChoose.getLibraryList().get(0));
        return basketChoose;
    }

    @PostMapping
    public BasketChoose create(@RequestBody BasketChoose basketChoose) throws IOException {
        Basket basket = basketService.getBasket(basketChoose.getId());
        Long id = Long.valueOf(basketChoose.getSelLibId());
        basket.setLibrary(libraryService.getLibrary(id));
        return new BasketChoose(basketService.save(basket), getLibs(basket));
    }

    private List<Library> getLibs(Basket basket) throws IOException {
        List<Library> libraries = userService.getLibsByUserEmail(basket.getUser().getId());
        List<Library> libraryList = new ArrayList<>();
        for(Library library : libraries){
            if(editionService.getCountInLib(library.getId(), basket.getEdId()) > 0 &&
                    (basket.getLibrary() == null || basket.getLibrary().getId() != library.getId())) {
                libraryList.add(library);
            }
        }
        return libraryList;
    }
}
