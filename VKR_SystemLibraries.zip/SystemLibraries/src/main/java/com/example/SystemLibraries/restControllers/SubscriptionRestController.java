package com.example.SystemLibraries.restControllers;

import com.example.SystemLibraries.models.Subscription;
import com.example.SystemLibraries.services.SubscriptionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/rest/subscription")
public class SubscriptionRestController {
    @Autowired
    public SubscriptionService subscriptionService;
    @GetMapping("/get-all")
    public List<Subscription> getAllSubscription(){
        return subscriptionService.getAllSubscriptions();
    }
    @GetMapping("/get-all/{id}")
    public List<Subscription> getAllSubscription(@PathVariable Long id){
        return subscriptionService.getAllSubscriptionsByLibId(id);
    }
    /*@GetMapping("/get-by-reader/{id}")
    public List<Subscription> getAllSubscriptionsByReadId(@PathVariable Long id){
        return subscriptionService.getAllSubscriptionsByReadId(id);
    }*/
    @PostMapping("/save")
    public Subscription save(@RequestBody Subscription subscription){
        return subscriptionService.save(subscription);
    }
    @GetMapping("/get/{id}")
    public Subscription getSubscriptionById(@PathVariable Long id){
        return subscriptionService.getSubscription(id);
    }
    @DeleteMapping("/delete/{id}")
    public void delete(@PathVariable Long id){
        subscriptionService.deleteById(id);
    }
    /*@GetMapping("change-subscription/{readerId}/{old_subsId}/{new_subsId}")
    public void changeSubscriptionByReader(@PathVariable long readerId, @PathVariable long old_subsId,
                                           @PathVariable long new_subsId){
        subscriptionService.changeSubscriptionByReader(readerId, old_subsId, new_subsId);
    }*/
}
