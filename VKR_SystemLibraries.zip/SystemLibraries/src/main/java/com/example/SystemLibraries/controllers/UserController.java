package com.example.SystemLibraries.controllers;

import com.example.SystemLibraries.formModels.*;
import com.example.SystemLibraries.mail.DefaultEmailService;
import com.example.SystemLibraries.models.*;
import com.example.SystemLibraries.services.*;
import com.example.SystemLibraries.views.DescripEditionView;
import com.example.SystemLibraries.views.FavoriteView;
import com.example.SystemLibraries.views.IssuedHRView;
import com.example.SystemLibraries.views.ReservView;
import org.apache.tomcat.util.http.fileupload.impl.FileSizeLimitExceededException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.parameters.P;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.security.Principal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import static org.springframework.web.bind.annotation.RequestMethod.POST;

@Controller
@RequestMapping("/user")
public class UserController {
    String[] message = {
            "Заполните поля Имя пользователя и Email.",
            "Пароль должен быть от 8 до 50 символов.",
            "Старый пароль неверен.",
            "Заполните поле Email.",
            "Код отправлен.",
            "Заполните поле Код.",
            "Введенный код не совпадает.",
            "Такое Имя пользователя уже занято.",
            "Такой Email уже занят."
    };
    @Autowired
    private UserService userService;
    @Autowired
    private SubscriptionService subscriptionService;
    @Autowired
    private ReaderService readerService;
    @Autowired
    DefaultEmailService emailService;
    @Autowired
    EditionService editionService;
    @Autowired
    private DescripEditionService descripEditionService;
    @Autowired
    private BasketService basketService;
    @Autowired
    private ReservationService reservationService;
    @Autowired
    private IssuedHRService issuedHRService;
    @Autowired
    private FavoriteService favoriteService;
    @Autowired
    private RequestService requestService;
    @PreAuthorize("hasAuthority('USER')")
    @GetMapping("/viewRequest/{edId}")
    public String request(Model model, @PathVariable("edId") Long id, Principal principal) throws IOException {
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        List<Subscription> subscriptions = userService.getSubsList(user.getId());
        model.addAttribute("user_subsList", subscriptions);

        Edition edition = editionService.getEdition(id);
        List<Library> list = userService.getLibsByUserEmail(user.getId());

        model.addAttribute("edition", edition);
        model.addAttribute("libraries", list);
        return "user/chooseLibForRequest";
    }

    @GetMapping("/viewRequest/{edId}/{libId}")
    @PreAuthorize("hasAuthority('USER')")
    public String request(Model model, @PathVariable("edId") Long edId, @PathVariable("libId") Long libId, Principal principal) throws IOException {
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        List<Subscription> subscriptions = userService.getSubsList(user.getId());
        model.addAttribute("user_subsList", subscriptions);
        if(user.getRole() == Role.USER && userService.getLibsByUserEmail(user.getId()).stream().filter(lib ->
                lib.getId() == libId).count()>0){
            requestService.add(edId, user.getId(), libId);
        }
        return "redirect:/user/home";
    }
    @GetMapping("/reqList")
    @PreAuthorize("hasAuthority('USER')")
    public String reqList(Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        List<Subscription> subscriptions = userService.getSubsList(user.getId());
        model.addAttribute("user_subsList", subscriptions);
        model.addAttribute("user", user);
        HashMap<Library, List<Request>> map = new HashMap<>();
        List<Request> reservViews = requestService.getRequestsByUserEmail(user.getEmail());
        for(Request reservation : reservViews){
            List<Request> list;
            if (map.containsKey(reservation.getSubscription().getLibrary())){
                list = map.get(reservation.getSubscription().getLibrary());
            }else{
                list =  new ArrayList();
            }
            list.add(reservation);
            map.put(reservation.getSubscription().getLibrary(), list);
        }
        model.addAttribute("maps", map);
        return "user/requests";
    }
    @PreAuthorize("hasAuthority('USER')")
    @GetMapping("/addFavInBasket/{id}")
    public String addFavInBasket(Model model, @PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        List<Subscription> subscriptions = userService.getSubsList(user.getId());
        model.addAttribute("user_subsList", subscriptions);
        model.addAttribute("user", user);
        Basket basket = basketService.getBasket(id);
        if(user.getRole() == Role.USER && basket.getUsId() == user.getId()){
            basket = basketService.addAsBasket(basket);
            List<FavoriteView> favorites = favoriteService.getAllByUserId(user.getId());
            model.addAttribute("favorites", favorites);
        }
        return "redirect:/user/favorites";
    }
    @PreAuthorize("hasAuthority('USER')")
    @PostMapping("/addFavInBasket")
    public String addFavInBasket(Model model, @ModelAttribute EditionWithLibs favorite, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        List<Subscription> subscriptions = userService.getSubsList(user.getId());
        model.addAttribute("user_subsList", subscriptions);
        model.addAttribute("user", user);

        Basket basket = basketService.getBasket(favorite.getId());
        basket.setLibId(favorite.getSelectedLib().getId());
        basket = basketService.addAsBasket(basket);

        List<FavoriteView> favorites = favoriteService.getAllByUserId(user.getId());
        model.addAttribute("favorites", favorites);
        return "user/favorites";
    }
    @PreAuthorize("hasAuthority('USER')")
    @GetMapping("/favorites")
    public String favorites(Model model, Principal principal) throws IOException {
        User user =  userService.getUserByUsername(principal.getName());
        List<Subscription> subscriptions = userService.getSubsList(user.getId());
        model.addAttribute("user_subsList", subscriptions);
        model.addAttribute("user", user);
        List<FavoriteView> favorites = favoriteService.getAllByUserId(user.getId());
        //List<EditionWithLibs> list = getListEdWithLibs(favorites, user);
        //model.addAttribute("favorites", list);
        model.addAttribute("favorites", favorites);
        return "user/favorites";
    }
    private List<EditionWithLibs> getListEdWithLibs(List<FavoriteView> favorites, User user) throws IOException {
        List<EditionWithLibs> list = new ArrayList<>();
        for(FavoriteView favorite : favorites){
            if(favorite.getLibId() != null && favorite.getLibId() > 0){
                list.add(new EditionWithLibs(favorite,
                        descripEditionService.getForReservEd(favorite.getEdition().getId(), user.getId())));
            }else{
                list.add(new EditionWithLibs(favorite, new ArrayList<>()));
            }
        }
        return  list;
    }
    @PreAuthorize("hasAuthority('USER')")
    @GetMapping("/deleteFavorite/{id}")
    public String deleteFavorite(Model model, @PathVariable Long id, Principal principal) throws IOException {
        User user =  userService.getUserByUsername(principal.getName());
        List<Subscription> subscriptions = userService.getSubsList(user.getId());
        model.addAttribute("user_subsList", subscriptions);
        model.addAttribute("user", user);
        Basket basket = basketService.getBasket(id);
        if(user.getRole() == Role.USER && basket.getUsId() == user.getId()){
            basketService.deleteFavoriteById(id);
            List<FavoriteView> favorites = favoriteService.getAllByUserId(user.getId());
            model.addAttribute("favorites", favorites);
        }
        return "redirect:/user/favorites";
    }
    @PreAuthorize("hasAuthority('USER')")
    @GetMapping("/readyList")
    public String readyList(Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        List<Subscription> subscriptions = userService.getSubsList(user.getId());
        model.addAttribute("user_subsList", subscriptions);
        if(user.getRole() == Role.USER){
            model.addAttribute("user", user);
            HashMap<Library, List<Reservation>> map = new HashMap<>();
            List<Reservation> reservViews = reservationService.getReservsByUserEmail(user.getId()).stream().filter(reserv ->
                    reserv.getStatus().equals("бронь")).toList();
            for(Reservation reservation : reservViews){
                List<Reservation> list;
                if (map.containsKey(reservation.getSubscription().getLibrary())){
                    list = map.get(reservation.getSubscription().getLibrary());
                }else{
                    list =  new ArrayList<Reservation>();
                }
                list.add(reservation);
                map.put(reservation.getSubscription().getLibrary(), list);
            }
            model.addAttribute("maps", map);
            return "user/readyList";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('USER')")
    @GetMapping("/formedList")
    public String formedList(Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        List<Subscription> subscriptions = userService.getSubsList(user.getId());
        model.addAttribute("user_subsList", subscriptions);
        if(user.getRole() == Role.USER){
            model.addAttribute("user", user);
            HashMap<Library, List<Reservation>> map = new HashMap<>();
            List<Reservation> reservViews = reservationService.getReservsByUserEmail(user.getId()).stream().filter(reserv ->
                    reserv.getStatus().equals("оформлен")).toList();
            for(Reservation reservation : reservViews){
                List<Reservation> list;
                if (map.containsKey(reservation.getSubscription().getLibrary())){
                    list = map.get(reservation.getSubscription().getLibrary());
                }else{
                    list =  new ArrayList<Reservation>();
                }
                list.add(reservation);
                map.put(reservation.getSubscription().getLibrary(), list);
            }
            model.addAttribute("maps", map);
            return "user/formedList";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('USER')")
    @GetMapping("/delayedList")
    public String delayedList(Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        List<Subscription> subscriptions = userService.getSubsList(user.getId());
        model.addAttribute("user_subsList", subscriptions);
        if(user.getRole() == Role.USER){
            model.addAttribute("user", user);
            HashMap<Library, List<IssuedHRView>> map = new HashMap<>();
            List<IssuedHRView> hrViews = issuedHRService.getAllDelayedByUserEmail(user.getId());
            for(IssuedHRView issuedHRView : hrViews){
                List<IssuedHRView> list;
                if (map.containsKey(issuedHRView.getLibrary())){
                    list = map.get(issuedHRView.getLibrary());
                }else{
                    list =  new ArrayList();
                }
                list.add(issuedHRView);
                map.put(issuedHRView.getLibrary(), list);
            }
            model.addAttribute("maps", map);
            return "user/delayedList";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('USER')")
    @GetMapping("/issuedList")
    public String issuedList(Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        List<Subscription> subscriptions = userService.getSubsList(user.getId());
        model.addAttribute("user_subsList", subscriptions);
        if(user.getRole() == Role.USER){
            HashMap<Library, List<IssuedHRView>> map = new HashMap<>();
            List<IssuedHRView> hrViews = issuedHRService.getAllIssuedByUserEmail(user.getId());
            for(IssuedHRView issuedHRView : hrViews){
                List<IssuedHRView> list;
                if (map.containsKey(issuedHRView.getLibrary())){
                    list = map.get(issuedHRView.getLibrary());
                }else{
                    list =  new ArrayList();
                }
                list.add(issuedHRView);
                map.put(issuedHRView.getLibrary(), list);
            }
            model.addAttribute("maps", map);
            model.addAttribute("user", user);
            return "user/issuedList";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('USER')")
    @GetMapping("/viewReserv/{id}")
    public String reservation(Model model, @PathVariable Long id, Principal principal) throws IOException {
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        List<Subscription> listSubs = userService.getSubsList(user.getId());
        model.addAttribute("user_subsList", listSubs);
        if(user.getRole() == Role.USER){
            Edition edition = editionService.getEdition(id);
            List<DescripEditionView> list = descripEditionService.getForReservEd(id, user.getId());
            model.addAttribute("edition", edition);
            model.addAttribute("libraries", list);
            return "user/chooseLibForReserv";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('USER')")
    @GetMapping("/reservation/{edId}/{subsId}")
    public String reservation(Model model, @PathVariable("edId") Long edId,
                              @PathVariable("subsId") Long subsId, Principal principal) throws IOException {
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        List<Subscription> list = userService.getSubsList(user.getId());
        model.addAttribute("user_subsList", list);
        Subscription subscription = subscriptionService.getSubscription(subsId);
        if(user.getRole() == Role.USER && userService.getSubsList(user.getId()).stream().filter(subs ->
                subs.getId() == subsId).count()>0){
            List<Subscription> subscriptions = userService.getSubsList(user.getId());
            model.addAttribute("user_subsList", subscriptions);
            Edition edition = editionService.getEdition(edId);
            Reservation reservation = new Reservation();
            reservation.setEdId(edition.getId());
            reservation.setEdition(edition);
            reservation.setSubscription(subscription);
            reservation.setSubsId(subscription.getId());
            reservationService.makingReserv(reservation);
        }
        return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('USER')")
    @GetMapping("/addBasket/{id}")
    public String addBasket(Model model, @PathVariable Long id, Principal principal) throws IOException {
        User user = userService.getUserByUsername(principal.getName());
        List<Subscription> listSubs = userService.getSubsList(user.getId());
        model.addAttribute("user_subsList", listSubs);
        if(user.getRole() == Role.USER){
            List<Subscription> subscriptions = userService.getSubsList(user.getId());
            model.addAttribute("user_subsList", subscriptions);
            model.addAttribute("user", user);
            Edition edition = editionService.getEdition(id);
            Basket basket = addInBasket(edition, user);
            basket = basketService.addAsBasket(basket);
            model.addAttribute("favorite", basket);
            List<DescripEditionView> list = descripEditionService.getForViewEd(id, user.getId());
            Boolean isMayBeReserv = list.stream().filter(item -> item.isReg() &&
                    item.getCount()>0).count()>0;
            model.addAttribute("libraries", list);
            model.addAttribute("isMayBeReserv", isMayBeReserv);
            model.addAttribute("edition", edition);
            return "redirect:/user/detailsEd/" + id;
        }else
            return "redirect:/home";
    }
    private Basket addInBasket(Edition edition, User user) {
        Basket basket = basketService.getBasketByUsIdEdId(user.getId(), edition.getId());
        if(basket.getId() == null){
            basket.setEdId(edition.getId());
            basket.setEdition(edition);
            basket.setUser(user);
            basket.setUsId(user.getId());
        }
        return basket;
    }
    @PreAuthorize("hasAuthority('USER')")
    @GetMapping("/updFav/{id}")
    public String updFav(Model model, @PathVariable Long id, Principal principal) throws IOException {
        User user = userService.getUserByUsername(principal.getName());
        List<Subscription> listSubs = userService.getSubsList(user.getId());
        model.addAttribute("user_subsList", listSubs);
        if(user.getRole() == Role.USER){
            List<Subscription> subscriptions = userService.getSubsList(user.getId());
            model.addAttribute("user_subsList", subscriptions);
            model.addAttribute("user", user);
            Edition edition = editionService.getEdition(id);
            Basket favorite = basketService.getBasketByUsIdEdId(user.getId(), id);
            if(favorite != null && favorite.isFavorite()){
                favorite = basketService.deleteFavoriteById(favorite.getId());
            }else{
                if(favorite.getId() == null){
                    favorite.setEdId(id);
                    favorite.setEdition(edition);
                    favorite.setUser(user);
                    favorite.setUsId(user.getId());
                }
                favorite = basketService.addAsFavorite(favorite);
            }

            model.addAttribute("favorite", favorite);
            List<DescripEditionView> list = descripEditionService.getForViewEd(id, user.getId());
            Boolean isMayBeReserv = list.stream().filter(item -> item.isReg() &&
                    item.getCount()>0).count()>0;
            model.addAttribute("libraries", list);
            model.addAttribute("isMayBeReserv", isMayBeReserv);
            model.addAttribute("edition", edition);
            return "redirect:/user/detailsEd/" + id;
        }else
            return "redirect:/home";
    }
    @GetMapping("/detailsEd/{id}")
    public String detailsEd(Model model, @PathVariable Long id, Principal principal) throws IOException {
        User user = new User();
        if(principal != null){
            user = userService.getUserByUsername(principal.getName());
            model.addAttribute("user", user);
            List<Subscription> list = userService.getSubsList(user.getId());
            model.addAttribute("user_subsList", list);
            if(user.getRole() == Role.USER){
                Basket favorite = basketService.getBasketByUsIdEdId(user.getId(), id);
                model.addAttribute("favorite", favorite);
                List<Subscription> subscriptions = userService.getSubsList(user.getId());
                model.addAttribute("user_subsList", subscriptions);
            }
        }
        Edition edition = editionService.getEdition(id);
        List<DescripEditionView> list = descripEditionService.getForViewEd(id, user.getId());
        Boolean isMayBeReserv = list.stream().filter(item -> item.isReg() && item.getCount()>0).count()>0;
        long count = userService.getCountReservs(user);
        if(count >= 10){
            model.addAttribute("count", count);
        }
        model.addAttribute("isMayBeReserv", isMayBeReserv);
        model.addAttribute("libraries", list);
        model.addAttribute("edition", edition);
        return "user/editionDetails";
    }
    @PreAuthorize("hasAuthority('USER')")
    @GetMapping("/subscription/{id}")
    public String subscription(Model model, @PathVariable Long id, Principal principal){
        User user = userService.getUserByUsername(principal.getName());
        List<Subscription> listSubs = userService.getSubsList(user.getId());
        Subscription subscription = subscriptionService.getSubscription(id);
        model.addAttribute("user_subsList", listSubs);
        if(user.getRole() == Role.USER && listSubs.stream().filter(subs -> subs.getId() == id).count()>0){
            model.addAttribute("user", user);
            List<Subscription> subscriptions = userService.getSubsList(user.getId());
            model.addAttribute("user_subsList", subscriptions);
            List<HRDetails> hrs = new ArrayList<>();
            subscription.getHistoryReaders().forEach(hr->{
                if(!hr.isRelevance())
                    hrs.add(new HRDetails(hr));
            });
            List<ReaderDetails> readers = new ArrayList<>();
            subscription.getReaders().forEach(reader->{
                if(!user.getEmail().equals(reader.getEmail()))
                    readers.add(new ReaderDetails(reader, null));
            });
            List<Reservation> reservations = subscription.getReservations().stream().filter(reserv ->
                    reserv.getStatus().equals("бронь")).toList();
            model.addAttribute("subscriber", subscription);
            model.addAttribute("reservations", reservations);
            model.addAttribute("histories", hrs);
            model.addAttribute("readers", readers);
            model.addAttribute("reader", readerService.getByEmailAndSubs(user.getEmail(), subscription.getId()));
            //model.addAttribute("user", user);
            return "user/subscription";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('ADMIN')")
    @GetMapping("/libList")
    public String list(Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.ADMIN){
            model.addAttribute("user", user);
            List<User> list = userService.getAllUsers().stream().filter(u -> u.getRole() == Role.LIB)
                    .collect(Collectors.toList());
            model.addAttribute("users", list);
            model.addAttribute("title", "Список библиотекарей");
            //model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
            return "user/list";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('ADMIN')")
    @GetMapping("/readList")
    public String listSubs(Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.ADMIN){
            model.addAttribute("user", user);
            List<User> list = userService.getAllUsers().stream().filter(u -> u.getRole() == Role.USER).collect(Collectors.toList());
            model.addAttribute("users", list);
            model.addAttribute("title", "Список читателей");
            //model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
            return "user/list";
        }else
            return "redirect:/home";
    }

    @GetMapping("/edit")
    public String editUser(Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        if(user.getRole() == Role.USER){
            List<Subscription> subscriptions = userService.getSubsList(user.getId());
            model.addAttribute("user_subsList", subscriptions);
        }
        //model.addAttribute("user", user);
        return "user/edit";
    }
    @GetMapping("/edit-m/{id_m}")
    public String edit(Model model, @PathVariable("id_m") int id_m, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        model.addAttribute("message", message[id_m]);
        if(user.getRole() == Role.USER){
            List<Subscription> subscriptions = userService.getSubsList(user.getId());
            model.addAttribute("user_subsList", subscriptions);
        }
        //model.addAttribute("user", user);
        return "user/edit";
    }
    @PostMapping(path = "/edit")
    public String edit(@ModelAttribute User newUser, Model model, Principal principal) throws IOException {
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        User check = userService.getUserByUsername(newUser.getUsername());
        if(newUser.getUsername().length()>0){
            if((check == null || check.getId() == user.getId())){
                userService.save(newUser);
                return "redirect:/logout";
            }else{
                model.addAttribute("message", message[7]);
                if(user.getRole() == Role.USER){
                    List<Subscription> subscriptions = userService.getSubsList(user.getId());
                    model.addAttribute("user_subsList", subscriptions);
                }
                return "user/edit";
            }
        }else{
            return "redirect:/user/edit-m/" + 0;
        }
    }
    @GetMapping("/editPass-m/{id_m}")
    public String editPassM(Model model, @PathVariable("id_m") int id_m, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.USER){
            List<Subscription> subscriptions = userService.getSubsList(user.getId());
            model.addAttribute("user_subsList", subscriptions);
        }
        model.addAttribute("user", user);
        model.addAttribute("message", message[id_m]);
        //model.addAttribute("user", user);
        return "user/edit";
    }
    @GetMapping("/editPass")
    public String editPass(Model model, Principal principal){
        User user1 = userService.getUserByUsername(principal.getName());
        EditUserPass userP = new EditUserPass(user1);
        model.addAttribute("userPass", userP);
        User user = userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        if(user1.getRole() == Role.USER){
            List<Subscription> subscriptions = userService.getSubsList(userP.getId());
            model.addAttribute("user_subsList", subscriptions);
        }
        //model.addAttribute("user", user);
        return "user/editPass";
    }
    @PostMapping("/editPass")
    public String editPass(@ModelAttribute EditUserPass newUser, Model model,
                           Principal principal) throws IOException {
        User user = userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        if(newUser.getNewPassword().length()>=8 && newUser.getNewPassword().length()<=50){
            BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
            User userP = userService.getUser(newUser.getId());
            if(passwordEncoder.matches(newUser.getOldPassword(), userP.getPassword())){
                userP.setPassword(passwordEncoder.encode(newUser.getNewPassword()));
                userP = userService.save(userP);
                return "redirect:/logout";
            }else{
                if(userService.getUserByUsername(principal.getName()).getRole() == Role.USER){
                    List<Subscription> subscriptions = userService.getSubsList(newUser.getId());
                    model.addAttribute("user_subsList", subscriptions);
                }
                model.addAttribute("userPass", newUser);
                model.addAttribute("message", message[2]);
                //model.addAttribute("user", user);
                return "user/editPass";
                //return "redirect:/user/editPass-m/" + 2;
            }
        }else{
            model.addAttribute("userPass", newUser);
            model.addAttribute("message", message[1]);
            if(userService.getUserByUsername(principal.getName()).getRole() == Role.USER){
                List<Subscription> subscriptions = userService.getSubsList(newUser.getId());
                model.addAttribute("user_subsList", subscriptions);
            }
            return "user/editPass";
            //return "redirect:/user/editPass-m/" + 1;
        }
    }
    @GetMapping("/editEmail")
    public String editEmail(Model model, Principal principal){
        User user = userService.getUserByUsername(principal.getName());
        UserConfimEmail email = new UserConfimEmail(userService.getUser(user.getId()));
        if(user.getRole() == Role.USER){
            List<Subscription> subscriptions = userService.getSubsList(user.getId());
            model.addAttribute("user_subsList", subscriptions);
        }
        model.addAttribute("user", user);
        model.addAttribute("userEmail", email);
        //model.addAttribute("user", user);
        return "user/editEmail";
    }
    @RequestMapping(value="/editEmail",params="save",method=RequestMethod.POST)
        public String editEmail(@ModelAttribute UserConfimEmail newUser, Model model,
                            Principal principal) throws IOException {
        User user = userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        if(user.getRole() == Role.USER){
            List<Subscription> subscriptions = userService.getSubsList(user.getId());
            model.addAttribute("user_subsList", subscriptions);
        }
        if(newUser.getConfimCode().length()>0){
            if(newUser.getCode().equals(newUser.getConfimCode())){
                User userS = userService.getUser(newUser.getId());
                //userS.setEmail(newUser.getEmail());
                userService.save(userS, newUser);
                return "redirect:/logout";
            }else{
                model.addAttribute("userEmail", newUser);
                model.addAttribute("message", message[6]);
                //model.addAttribute("user", user);
                return "user/editEmail";
            }
        }else{
            model.addAttribute("userEmail", newUser);
            model.addAttribute("message", message[5]);
            //model.addAttribute("user", user);
            return "user/editEmail";
        }
    }

    //@PostMapping("/sendCode")
    @RequestMapping(value="/editEmail",params="send",method=RequestMethod.POST)
    public String sendCode(Model model, @ModelAttribute UserConfimEmail userConfimEmail, Principal principal){
        User user = userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        if(user.getRole() == Role.USER){
            List<Subscription> subscriptions = userService.getSubsList(userConfimEmail.getId());
            model.addAttribute("user_subsList", subscriptions);
        }
        if(userConfimEmail.getEmail() != null && userConfimEmail.getEmail().length()>0){
            if(userService.getMayBeUseEmail(userConfimEmail.getEmail())){
                String code = UUID.randomUUID().toString();
                userConfimEmail.setCode(emailService.sendCode(userConfimEmail.getEmail()));

                model.addAttribute("userEmail", userConfimEmail);
                model.addAttribute("message", message[4]);
                model.addAttribute("disableEmail", true);

            }else{
                model.addAttribute("userEmail", userConfimEmail);
                model.addAttribute("message", message[8]);
                //model.addAttribute("user", user);
            }
        }else {
            userConfimEmail.setCode(null);
            model.addAttribute("userEmail", userConfimEmail);
            model.addAttribute("message", message[3]);

        }
        return "user/editEmail";

    }
    @GetMapping("/editEmailM/{id}")
    public String editEmail(Model model, @PathVariable int id, Principal principal){
        User user = userService.getUserByUsername(principal.getName());
        UserConfimEmail email = new UserConfimEmail(userService.getUser(user.getId()));
        model.addAttribute("userEmail", email);
        model.addAttribute("message", message[id]);
        //model.addAttribute("user", user);
        return "user/editEmail";
    }
}
