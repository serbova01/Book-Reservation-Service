package com.example.SystemLibraries.services;

import com.example.SystemLibraries.models.Postponed;
import com.example.SystemLibraries.repositories.PostponedRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.util.Streamable;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class PostponedService {
    @Autowired
    private PostponedRepository postponedRepository;
    @Autowired
    private EditionService editionService;
    @Autowired
    private SubscriptionService subscriptionService;

    public Postponed save(Postponed postponed){
        postponed.setEdition(editionService.getEdition(postponed.getEdId()));
        postponed.setSubscription(subscriptionService.getSubscription(postponed.getSubsId()));
        return  postponedRepository.save(postponed);
    }
    public void deleteById(long id){
        postponedRepository.deleteById(id);
    }
    public List<Postponed> getAllPostponeds(){
        List<Postponed> postponeds = new ArrayList<>();
        Streamable.of(postponedRepository.findAll()).forEach(postponeds::add);
        return postponeds;
    }
    public List<Postponed> getAllPostponedsByLibId(@Nullable Long libId){
        List<Postponed> postponeds = new ArrayList<>();
        Streamable.of(postponedRepository.findAll()).forEach(postponed -> {
            if(libId == null || postponed.getSubscription().getLibrary().getId() == libId){
                postponeds.add(postponed);
            }
        });
        return postponeds;
    }
    public Postponed getPostponed(long id){
        return postponedRepository.findById(id).get();
    }

    public Postponed getByEditionSubs(Postponed postponed) {
        return postponedRepository.findByEdIdAndSubsId(postponed.getEdition().getId(), postponed.getSubscription().getId());
    }
}
