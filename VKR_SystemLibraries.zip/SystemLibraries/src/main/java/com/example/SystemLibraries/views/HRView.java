package com.example.SystemLibraries.views;

import com.example.SystemLibraries.models.HistoryReader;
import com.example.SystemLibraries.models.Library;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import javax.persistence.*;
import lombok.Getter;
import org.hibernate.annotations.Immutable;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.IOException;
import java.time.LocalDate;
@Entity
@Table(name = "v_hr")
@Getter
@Immutable
public class HRView {
    @Id
    private Long id;
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    private LocalDate dateIssue;
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    private LocalDate dateReturn;
    private String invNum;
    @Column(name = "catalog_id", insertable=false, updatable=false)
    private Long edId;
    @ManyToOne
    @JsonManagedReference
    private CatalogView edition;
    @Column(name = "library_id", insertable=false, updatable=false)
    private Long libId;
    @ManyToOne
    @JsonIgnore
    private Library library;

    public HRView(HistoryReader hr) throws IOException {
        this.id = hr.getId();
        this.dateIssue = hr.getDateIssue();
        this.dateReturn = hr.getDateReturn();
        this.invNum = hr.getCopyBook().getInvNumber();
        this.edId = hr.getCopyBook().getEdId();
        this.edition = new CatalogView(hr.getCopyBook().getEdition());
        this.libId = hr.getCopyBook().getDepartment().getLibId();
        this.library = hr.getCopyBook().getDepartment().getLibrary();
    }

}
