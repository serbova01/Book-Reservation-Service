package com.example.SystemLibraries.controllers;

import com.example.SystemLibraries.formModels.EditionWithImage;
import com.example.SystemLibraries.models.*;
import com.example.SystemLibraries.services.*;
import org.apache.tomcat.util.http.fileupload.impl.FileSizeLimitExceededException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.security.Principal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static org.springframework.web.bind.annotation.RequestMethod.POST;

@Controller
@RequestMapping("/edition")
public class EditionController {
    @Autowired
    private EditionService mainServer;
    @Autowired
    private BookService bookService;
    @Autowired
    private PublHouseService publHouseService;
    @Autowired
    private UserService userService;
    @Autowired
    private DescripEditionService descripEditionService;
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/list")
    public String list(Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        List<Edition> list = mainServer.getAllEditions();
        model.addAttribute("editions", list);
        //model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
        return "edition/list";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/details/{id}")
    public String details(Model model, @PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        Edition edition = mainServer.getEdition(id);
        HashMap<Library, Integer> map = new HashMap<>();
        List<CopyBook> copyBooks = new ArrayList<>();
        if(user.getRole() == Role.LIB){
            copyBooks = edition.getCopyBooks().stream().filter(copyBook ->
                    copyBook.getDepartment().getLibrary().getId() == user.getLibId()).toList();
        }else{
            copyBooks = edition.getCopyBooks();
        }
        model.addAttribute("maps", map);
        model.addAttribute("edition", edition);
        model.addAttribute("copyBooks", copyBooks);
        //model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
        return "edition/details";

    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/create")
    public String create(Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        List<PublHouse> publHouses = publHouseService.getAllPublHouses();
        List<Book> books = bookService.getAllBooks();
        model.addAttribute("publHouses", publHouses);
        model.addAttribute("books", books);
        model.addAttribute("edition", new EditionWithImage(new Edition()));
        //model.addAttribute("user", user);
        return "edition/create";

    }
    @PreAuthorize("hasAuthority('LIB')")
    @RequestMapping(path = "/create", method = RequestMethod.POST, consumes = { MediaType.MULTIPART_FORM_DATA_VALUE })
    public String create(@ModelAttribute EditionWithImage ewi, Model model) throws IOException {
        model.addAttribute("publHouses", publHouseService.getAllPublHouses());
        model.addAttribute("books", bookService.getAllBooks());
        model.addAttribute("edition", new EditionWithImage(new Edition()));
        if (ewi.isNullFields()){
            model.addAttribute("message", "Заполните обязательные поля: " +
                    "ISBN, Год издания, Цена и Количество страниц.");
            return "edition/create";
        }
        //if (ewi.getFile().getOriginalFilename().length() < 1){
        //    model.addAttribute("message", "Загрузите изображение обложки.");
        //    return "edition/create";
        //}
        try{
            Edition edition = ewi.convertToEdition(new Edition());
            //edition.setImagePath(ewi.setImage(edition));
            mainServer.save(edition);
            return "redirect:/edition/list";
        }catch (Exception ex){
            model.addAttribute("message", ex.getMessage());
            return "edition/create";
        }
        //}
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/edit/{id}")
    public String edit(Model model, @PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        List<PublHouse> publHouses = publHouseService.getAllPublHouses();
        List<Book> books = bookService.getAllBooks();
        //EditionWithImage edition = new EditionWithImage(mainServer.findEditionById(id));
        model.addAttribute("publHouses", publHouses);
        model.addAttribute("books", books);
        model.addAttribute("edition", new EditionWithImage(mainServer.getEdition(id)));
        //model.addAttribute("user", user);
        return "edition/edit";

    }
    @PreAuthorize("hasAuthority('LIB')")
    @RequestMapping(path = "/edit", method = POST, consumes = { MediaType.MULTIPART_FORM_DATA_VALUE })
    public String edit(@ModelAttribute EditionWithImage ewi, Model model) throws IOException {
        if (ewi.isNullFields()){
            model.addAttribute("message", "Заполните корректными данными обязательные поля: " +
                    "ISBN, Год издания, Цена и Количество страниц.");
            return "edition/edit/" + ewi.getId();
        }
        //if (ewi.getImagePath() == null && ewi.getImagePath().length()==0
               // && ewi.getFile().getOriginalFilename().length() < 1){
            //model.addAttribute("message", "Загрузите изображение обложки.");
            //return "edition/edit/" + ewi.getId();
            //ewi.setImagePath("/images/empty_book.png");
        //}
        try{
            Edition edition = ewi.convertToEdition(new Edition());
            //edition.setImagePath(ewi.setImage(edition));
            mainServer.save(edition);
            return "redirect:/edition/list";
        }catch (FileSizeLimitExceededException ex){
            model.addAttribute("message", ex.getMessage());
            return "edition/edit/" + ewi.getId();
        }
        //}
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id, Principal principal){
        //User user =  mainServer.findUserByLogin(principal.getName());
        mainServer.deleteById(id);
        return "redirect:/edition/list";

    }
}
