package com.example.SystemLibraries.formModels;

import com.example.SystemLibraries.models.User;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class EditUserPass {
    private Long id;
    private String oldPassword;
    private String newPassword;

    public EditUserPass(User user){
        id = user.getId();
        newPassword="";
        oldPassword="";
    }

}
