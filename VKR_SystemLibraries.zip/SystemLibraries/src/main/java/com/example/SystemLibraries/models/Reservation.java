package com.example.SystemLibraries.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import java.time.LocalDate;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Reservation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    private LocalDate dateForm;
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    private LocalDate dateReserv;
    private String status;
    @Column(name = "subscription_id", insertable=false, updatable=false)
    private Long subsId;
    @ManyToOne
    @JsonIgnore
    //@JsonManagedReference(value="reservation-subscription")
    private Subscription subscription;
    @Column(name = "edition_id", insertable=false, updatable=false)
    private Long edId;
    @ManyToOne
    @JsonIgnore
    //@JsonManagedReference(value="reservation-edition")
    private Edition edition;
    @Column(name = "copy_book_id", insertable=false, updatable=false)
    private Long copyId;
    @ManyToOne
    @JsonIgnore
    //@JsonManagedReference(value="reservation-copyBook")
    private CopyBook copyBook;

    public void setCopyBook(CopyBook copyBook) {
        this.copyBook = copyBook;
        setCopyId(copyBook.getId());
    }

    public void setSubscription(Subscription subscription) {
        this.subscription = subscription;
        setSubsId(subscription.getId());
    }

    public void setEdition(Edition edition) {
        this.edition = edition;
        setEdId(edition.getId());
    }
}
