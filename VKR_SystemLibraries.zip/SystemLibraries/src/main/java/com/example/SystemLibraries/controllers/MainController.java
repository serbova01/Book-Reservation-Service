package com.example.SystemLibraries.controllers;

import com.example.SystemLibraries.models.*;
import com.example.SystemLibraries.services.EditionService;
import com.example.SystemLibraries.services.ReaderService;
import com.example.SystemLibraries.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@Controller
public class MainController {
    @Autowired
    private EditionService mainServer;
    @Autowired
    private ReaderService readerService;
    @Autowired
    private UserService userService;

    @GetMapping("/home")
    public String list(Model model, Principal principal){
        User user = new User();
        if(principal != null){
            user = userService.getUserByUsername(principal.getName());
            model.addAttribute("user", user);
            List<Subscription> subscriptions = userService.getSubsList(user.getId());
            model.addAttribute("user_subsList", subscriptions);
        }
        if (principal == null || user.getRole() == Role.USER){
            List<Edition> editions = mainServer.getAllEditions();
            HashMap<Genre, List<Edition>> map = new HashMap<>();
            for(Edition ed : editions){
                List<Edition> list;
                if(ed.getImagePath() == null){
                    ed.setImagePath("/images/empty_book.png");
                }
                if (map.containsKey(ed.getBook().getGenre())){
                    list = map.get(ed.getBook().getGenre());
                }else{
                    list =  new ArrayList<Edition>();
                }
                list.add(ed);
                map.put(ed.getBook().getGenre(), list);
            }
            model.addAttribute("maps", map);
            return "home";
        }else{
            if(user.getRole() == Role.LIB){
                return "redirect:/reservation/formedList";
            }else
                return "redirect:/library/list";
        }
    }
    @RequestMapping(path = {"/catalog","/catalog/search"})
    public String catalog(Edition shop, Model model, String keyword, Principal principal){
        User user = new User();
        if(principal != null){
            user = userService.getUserByUsername(principal.getName());
            model.addAttribute("user", user);
            List<Subscription> subscriptions = userService.getSubsList(user.getId());
            model.addAttribute("user_subsList", subscriptions);
        }
        if (principal == null || user.getRole() == Role.USER){
            List<Edition> editions = new ArrayList<>();
            if(keyword!=null && keyword.length() >= 1 && Character.isLetterOrDigit(keyword.toCharArray()[0])) {
                editions = mainServer.getByKeyword(keyword);
            }else
                editions = mainServer.getAllEditions();
            model.addAttribute("keyword", keyword);
            model.addAttribute("editions", editions);
            return "catalog";
        }else{
            if(user.getRole() == Role.LIB){
                return "redirect:/reservation/formedList";
            }else
                return "redirect:/library/list";
        }
    }
    //@RequestMapping(path = {"/catalog/","/catalog/search"})
    public String home(Edition shop, Model model, String keyword) {
        List<Edition> list;
        if(keyword!=null && keyword.length()>0) {
            list = mainServer.getByKeyword(keyword);
        }else {
            list = mainServer.getAllEditions();
        }
        model.addAttribute("editions", list);
        return "catalog";
    }
    @GetMapping("/registration")
    public String registration(){
        return "registration";
    }
    @PostMapping("/registration")
    public String registration(@ModelAttribute User regUser, Model model){
        if (regUser.isNullFields()){
            model.addAttribute("message", "Заполните обязательные поля: Имя пользователя, Email, Пароль.");
            return "registration";
        }
        if (regUser.getPassword().length()<8 || regUser.getPassword().length()>50){
            model.addAttribute("message", "Пароль должен быть от 8 до 50 символов.");
            return "registration";
        }
        User user1 = userService.getUserByUsername(regUser.getUsername());
        if (user1 != null){
            model.addAttribute("message", "Пользователь с таким именем уже существует.");
            return "registration";
        }
        Reader reader = userService.checkByEmail(regUser);
        if (reader.getReaderId() == null || reader.getReaderId().getReader_id() == null){
            model.addAttribute("message", "Такая электронная почта не зарегистрирована.");
            return "registration";
        }
        regUser.setAuthorize(true);
        regUser.setRole(Role.USER);
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        regUser.setPassword(passwordEncoder.encode(regUser.getPassword()));
        userService.save(regUser);
        return "redirect:/login";
    }
    @GetMapping("/profileUser")
    public String profileUser(Model model, Principal principal){
        User user = userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        return "user/profileUser";
    }

}
