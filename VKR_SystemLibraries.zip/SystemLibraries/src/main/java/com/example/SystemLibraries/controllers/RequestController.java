package com.example.SystemLibraries.controllers;

import com.example.SystemLibraries.formModels.EditionInLib;
import com.example.SystemLibraries.models.*;
import com.example.SystemLibraries.services.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@Controller
@RequestMapping("/request")
public class RequestController {
    @Autowired
    private RequestService requestService;
    @Autowired
    private UserService userService;
    @Autowired
    private SubscriptionService subscriptionService;
    @Autowired
    private EditionService editionService;
    @Autowired
    private CopyBookService copyBookService;
    @Autowired
    private ReservationService reservationService;
    @Autowired
    private HistoryReaderService historyReaderService;
    private String message;
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/ourList")
    public String ourList(Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        List<Request> list = requestService.getAllFormedRequestsByLibId(user.getLibId());
        model.addAttribute("requests", list);
        //model.addAttribute("user", user);
        return "request/ourList";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/theyDeliveryList")
    public String theyDeliveryList(Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        List<Request> list = requestService.getAllDeliveredRequestsByLibId(user.getLibId());
        model.addAttribute("requests", list);
        //model.addAttribute("user", user);
        return "request/theyDelList";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/gettingBook/{id}")
    public String gettingBook(Model model, @PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        Request request = requestService.getRequest(id);
        if(request.getSubscription().getLibrary().getId() == user.getLibId()){
            if(!request.getStatus().equals("на возврат"))
                reservationService.add(request);
            else requestService.returnBookInLib(request);
        }else requestService.confimReturnBookInLib(id);
        return "redirect:/request/theyDeliveryList";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/chooseCopyBook/{id}")
    public String chooseCopyBook(Model model, @PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            model.addAttribute("user", user);
            Request request = requestService.getRequest(id);
            List<CopyBook> copies = copyBookService.getAllCopyBooksIsAvailableByLibId(user.getLibId()).stream()
                    .filter(cb -> cb.getEdition().getId() == request.getEdId()).toList();
            model.addAttribute("request", request);
            model.addAttribute("edition", new EditionInLib(request.getEdition(),
                    request.getSubscription().getLibrary().getId()));
            model.addAttribute("copies", copies);
            //model.addAttribute("user", bookService.findUserByLogin(principal.getName()));
            return "request/chooseCopyBook";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/issuedCopyBook/{idReq}/{idCB}")
    public String issuedCopyBook(Model model, @PathVariable("idReq") Long idReq, @PathVariable("idCB") Long idCB,
                                 Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            model.addAttribute("user", user);
            Request request = requestService.getRequest(idReq);
            if(request.getCopyBook() == null){
                HistoryReader historyReader = new HistoryReader();
                historyReader.setSubscription(request.getSubscription());
                historyReader.setCopyId(idCB);
                //historyReaderService.add(historyReader);
                historyReaderService.add(request, copyBookService.getCopyBook(idCB));
            }
            return "redirect:/request/list";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/reservCopyBook/{idReq}/{idCB}")
    public String reservCopyBook(Model model, @PathVariable("idReq") Long idReq, @PathVariable("idCB") Long idCB,
                                 Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            model.addAttribute("user", user);
            Request request = requestService.getRequest(idReq);
            if(request.getCopyBook() == null){
                CopyBook copyBook = copyBookService.getCopyBook(idCB);
                reservationService.add(request, copyBook);
            }
            return "redirect:/request/list";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/workList")
    public String workList(Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        List<Request> list = requestService.getAllRequests().stream().filter(req ->
                req.getSubscription().getLibrary().getId() == user.getLibId() && req.getCopyBook() != null)
                .filter(request -> request.getCopyBook().getStatusInAnotherLib().equals("забронирован")).toList();
        model.addAttribute("requests", list);
        //model.addAttribute("user", user);
        return "request/workList";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/weDeliveryList")
    public String weDeliveryList(Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        List<Request> requests = requestService.getAllDeliveredRequestsByNoLibId(user.getLibId());
        model.addAttribute("maps", getMapForLibReq(requests));
        //model.addAttribute("user", user);
        return "request/weDelList";
    }

    private HashMap<Library, List<Request>> getMapForLibReq(List<Request> requests) {
        HashMap<Library, List<Request>> map = new HashMap<>();
        for(Request request : requests){
            List<Request> list;
            Library keyLib;
            if(request.getStatus().equals("возврат"))
                keyLib = request.getCopyBook().getDepartment().getLibrary();
            else keyLib = request.getSubscription().getLibrary();
            if (map.containsKey(keyLib)){
                list = map.get(keyLib);
            }else{
                list =  new ArrayList();
            }
            list.add(request);
            map.put(keyLib, list);
        }
        return map;
    }

    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/theirList")
    public String theirList(Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        List<Request> list = requestService.getAllFormedRequestsByNoLibId(user.getLibId());
        model.addAttribute("maps", getMapForLibReq(list));
        //model.addAttribute("user", user);
        return "request/theirList";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/answerRequest/{id}")
    public String answerRequest(Model model, @PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        Request request = requestService.getRequest(id);
        List<CopyBook> copyBooks = copyBookService.getAllCopyBooksIsAvailableByLibId(user.getLibId()).stream()
                .filter(copyBook -> copyBook.getEdition().getId() == request.getEdition().getId()).toList();
        model.addAttribute("request", request);
        model.addAttribute("copyBooks", copyBooks);
        model.addAttribute("depStr", copyBooks.get(0).getDepartment().getDepStr());
        return "request/answerRequest";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/answerRequest/{reqId}/{cbId}")
    public String answerRequest(Model model, @PathVariable("reqId") Long reqId,
                                 @PathVariable("cbId") Long cbId, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        Request request = requestService.getRequest(reqId);
        request.setCopyId(cbId);
        request.setCopyBook(copyBookService.getCopyBook(cbId));
        requestService.answerToRequest(request);
        return "redirect:/request/theirList";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/editCopyBook/{id}")
    public String editCopyBook(Model model, @PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        Request request = requestService.getRequest(id);
        List<CopyBook> copyBooks = copyBookService.getAllCopyBooksIsAvailableByLibId(user.getLibId()).stream()
                .filter(copyBook -> copyBook.getEdition().getId() == request.getEdition().getId()).toList();
        model.addAttribute("request", request);
        model.addAttribute("copyBooks", copyBooks);
        model.addAttribute("depStr", copyBooks.get(0).getDepartment().getDepStr());
        return "request/editCopyBook";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/editCopyBook/{reqId}/{cbId}")
    public String editCopyBook(Model model, @PathVariable("reqId") Long reqId,
                                 @PathVariable("cbId") Long cbId, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        Request request = requestService.getRequest(reqId);
        if(request.getCopyBook()!=null){
            request.getCopyBook().setStatusInThisLib("в наличии");
            copyBookService.save(request.getCopyBook());
        }
        request.setCopyId(cbId);
        request.setCopyBook(copyBookService.getCopyBook(cbId));
        requestService.answerToRequest(request);
        return "redirect:/request/weList";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/details/{id}")
    public String details(Model model, @PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        Request request = requestService.getRequest(id);
        if(request.getSubscription().getLibrary().getId() == user.getLibId() ||
                (request.getCopyBook() != null && request.getCopyBook().getDepartment().getLibrary().getId() == user.getLibId())){
            model.addAttribute("request", request);
            //model.addAttribute("user", user);
            return "request/details";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/create")
    public String create(Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        List<Subscription> subscriptions = subscriptionService.getAllSubscriptionsByLibId(user.getLibId());
        List<Edition> editions = editionService.getAllEditions();
        Request request = new Request();
        request.setSubscription(subscriptions.get(0));
        model.addAttribute("request", request);
        model.addAttribute("subscriptions", subscriptions);
        model.addAttribute("editions", editions);
        return "request/create";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/create/{edId}/{subsId}")
    public String createChooseCB(Model model,@PathVariable("edId") Long edId,
                                 @PathVariable("subsId") Long subsId, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        Request request = new Request();
        Edition edition = editionService.getEdition(edId);
        request.setSubscription(subscriptionService.getSubscription(subsId));
        request.setEdition(edition);
        List<Subscription> subscriptions = subscriptionService.getAllSubscriptionsByLibId(user.getLibId());
        List<Edition> editions = editionService.getAllEditions();
        editions.remove(edition);

        model.addAttribute("request", request);
        model.addAttribute("subscriptions", subscriptions);
        model.addAttribute("editions", editions);
        return "request/create";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @PostMapping("/create")
    public String create(@ModelAttribute Request request, Model model){
        if(request.getEdition() != null){
            requestService.add(request);
        }
        return "redirect:/request/ourList";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/edit/{id}")
    public String edit(Model model, @PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        Request request = requestService.getRequest(id);
        if(request.getCopyBook()!= null &&
                request.getCopyBook().getDepartment().getLibrary().getId() == user.getLibId()){
            List<CopyBook> copyBooks = copyBookService.getAllCopyBooksIsAvailableByLibId(user.getLibId());
            model.addAttribute("request", request);
            model.addAttribute("copyBooks", copyBooks);
            //model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
            return "request/edit";
        }else return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @PostMapping("/edit")
    public String edit(@ModelAttribute Request request, Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        requestService.save(request);
        return "redirect:/request/details/" + request.getId();
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/deleteLib/{id}")
    public String deleteLib(@PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        Request request = requestService.getRequest(id);
        if(user.getRole() == Role.LIB && request.getSubscription().getLibrary().getId() == user.getLibId()){
            requestService.deleteById(id);
        }
        return "redirect:/home";
    }

    @PreAuthorize("hasAuthority('USER')")
    @GetMapping("/deleteUser/{id}")
    public String deleteUser(@PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        Request request = requestService.getRequest(id);
        if(user.getRole() == Role.USER &&  userService.getSubsList(user.getId()).stream().filter(subs ->
                subs.getId() == request.getSubscription().getLibrary().getId()).count()>0){
            requestService.deleteById(id);
            return "redirect:/user/reqList";
        }
        return "redirect:/home";
    }
}
