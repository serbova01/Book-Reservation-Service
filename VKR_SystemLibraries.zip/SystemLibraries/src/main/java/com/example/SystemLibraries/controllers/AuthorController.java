package com.example.SystemLibraries.controllers;

import com.example.SystemLibraries.models.*;
import com.example.SystemLibraries.services.AuthorService;
import com.example.SystemLibraries.services.BookService;
import com.example.SystemLibraries.services.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;
@Controller
@RequiredArgsConstructor
//@PreAuthorize("hasAuthority('LIB')")
@RequestMapping("/author")
public class AuthorController {
    @Autowired
    private AuthorService mainServer;
    @Autowired
    private BookService bookService;
    @Autowired
    private UserService userService;
    private String[] message ={
            "Заполните обязательные поля: Фамилия и Имя.",
            "Автор с таким ФИО уже существует."
    };

    @GetMapping("/list")
    public String list(Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            model.addAttribute("user", user);
            List<Author> list = mainServer.getAllAuthors();
            for (Author author : list){
                author.setBooks(bookService.getByAuthor(author));
            }
            model.addAttribute("authors", list);
            return "author/list";
        }else
            return "redirect:/home";
    }
    @GetMapping("/details/{id}")
    public String details(Model model, @PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            model.addAttribute("user", user);
            Author author = mainServer.getAuthor(id);
            author.setBooks(bookService.getByAuthor(author));
            model.addAttribute("author", author);
            //model.addAttribute("user", user);
            return "author/details";
        }else
            return "redirect:/home";
    }
    @GetMapping("/create")
        public String create(Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            model.addAttribute("author", new Author());
            //model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
            return "author/create";
        }else
            return "redirect:/home";
    }
    //@PreAuthorize("hasAuthority('LIB')")
    @PostMapping("/create")
    public String create(@ModelAttribute Author author, Model model){
        if(author.isNullField()){
            model.addAttribute("message", message[0]);
            return "author/create";
        }
        if(mainServer.getByFIO(author) != null){
            mainServer.save(author);
            return "redirect:/author/list";
        }else{
            model.addAttribute("message", message[1]);
            return "author/create";
        }
    }
    //@PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/edit/{id}")
    public String edit(Model model, @PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            model.addAttribute("user", user);
            model.addAttribute("author", mainServer.getAuthor(id));
            return "author/edit";
        }else
            return "redirect:/home";
    }
    //@PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/edit/{id_m}/{id}")
    public String edit(Model model, @PathVariable("id_m") int id_m, @PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            model.addAttribute("user", user);
            model.addAttribute("message", message[id_m]);
            model.addAttribute("author", mainServer.getAuthor(id));
            //model.addAttribute("user", user);
            return "author/edit";
        }else
            return "redirect:/home";
    }
    //@PreAuthorize("hasAuthority('LIB')")
    @PostMapping("/edit")
    public String edit(@ModelAttribute Author author, Model model){
        Author authorCkeck = mainServer.getByFIO(author);
        if(author.isNullField()){
            return "redirect:/author/edit/0/" + author.getId();
        }
        if (authorCkeck != null && authorCkeck.getId() != author.getId()){
            return "redirect:/author/edit/1/" + author.getId();
        }else{
            mainServer.save(author);
            return "redirect:/author/list";
        }
    }
    //@PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            Author author = mainServer.getAuthor(id);
            if(author.getBooks().isEmpty())
                mainServer.deleteById(id);
            return "redirect:/author/list";
        }else
            return "redirect:/home";
    }
}
