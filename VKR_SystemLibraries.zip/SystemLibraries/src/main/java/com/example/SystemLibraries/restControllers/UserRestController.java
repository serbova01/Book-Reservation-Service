package com.example.SystemLibraries.restControllers;

import com.example.SystemLibraries.models.Library;
import com.example.SystemLibraries.models.Reader;
import com.example.SystemLibraries.models.Subscription;
import com.example.SystemLibraries.models.User;
import com.example.SystemLibraries.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/rest/user")
public class UserRestController {
    @Autowired
    public UserService userService;
    @GetMapping("/get-all")
    public List<User> getAllUser(){
        return userService.getAllUsers();
    }
    //@RequestMapping(value = "/save", method = RequestMethod.POST,
            //consumes = "application/json;charset=UTF-8")
    //@ResponseBody
    @PostMapping("/save")
    public User save(@RequestBody User user){return userService.save(user);}
    @GetMapping("/get/{id}")
    public User getUser(@PathVariable Long id){
        return userService.getUser(id);
    }
    @PostMapping("/check")
    //@RequestMapping(value = "/check", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
    //@ResponseBody
    public User check(@RequestBody User user){
        return userService.checkByLogin(user);
    }
    @PostMapping("/check-email")
    public Reader checkByEmail(@RequestBody User user){
        return userService.checkByEmail(user);
    }
    @PostMapping("/check-username")
    public User checkByUsername(@RequestBody User username){
        return userService.getUserByUsername(username.getUsername());
    }
    @PostMapping("/check-reservs")
    public long getCountReservs(User user){return userService.getCountReservs(user);}
    @DeleteMapping("/delete/{id}")
    public void delete(@PathVariable Long id){
        userService.deleteById(id);
    }
    @GetMapping("/get-us-and-lib/{usId}/{libId}")
    public Subscription getSubsByUsIdLibId(@PathVariable Long usId, @PathVariable Long libId){
        return userService.getSubs(usId, libId);
    }
    @GetMapping("/get-us-and-libs/{usId}/{libIds}")
    public List<Subscription> getSubsByUsIdLibId(@PathVariable Long usId, @PathVariable String libIds){
        return userService.getListSubs(usId, libIds);
    }
    @GetMapping("/get-libs-by-user/{id}")
    public List<Library> getLibsByUser(@PathVariable Long id){
        return userService.getLibsByUserEmail(id);
    }
}
