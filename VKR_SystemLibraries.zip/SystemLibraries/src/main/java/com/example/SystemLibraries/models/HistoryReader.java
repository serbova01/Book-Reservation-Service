package com.example.SystemLibraries.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import java.time.LocalDate;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class HistoryReader {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    private LocalDate dateIssue;
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    private LocalDate dateReturn;
    private boolean relevance;
    @Column(name = "copy_book_id", insertable=false, updatable=false)
    private Long copyId;
    @ManyToOne
    @JsonIgnore
    //@JsonManagedReference(value="historyReader-copyBook")
    private CopyBook copyBook;
    @Column(name = "subscription_id", insertable=false, updatable=false)
    private Long subsId;
    @ManyToOne
    @JsonIgnore
    //@JsonManagedReference(value="historyReader-subscription")
    private Subscription subscription;

    public void setSubscription(Subscription subscription) {
        this.subscription = subscription;
        setSubsId(subscription.getId());
    }

    public void setCopyBook(CopyBook copyBook) {
        this.copyBook = copyBook;
        setCopyId(copyBook.getId());
    }
}
