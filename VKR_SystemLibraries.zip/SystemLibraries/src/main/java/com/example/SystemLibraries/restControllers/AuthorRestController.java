package com.example.SystemLibraries.restControllers;

import com.example.SystemLibraries.models.Author;
import com.example.SystemLibraries.services.AuthorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/rest/author")
public class AuthorRestController {
    @Autowired
    public AuthorService authorService;
    @GetMapping("/get-all")
    public List<Author> getAllAuthor(){
        return authorService.getAllAuthors();
    }
    @GetMapping("/get-all/{id}")
    public List<Author> getAllAuthor(@PathVariable Long id){
        return authorService.getAllAuthorsByLibId(id);
    }
    @PostMapping("/save")
    public Author save(@RequestBody Author author){
        return authorService.save(author);
    }
    @GetMapping("/get/{id}")
    public Author getAuthorById(@PathVariable Long id){
        return authorService.getAuthor(id);
    }
    @DeleteMapping("/delete/{id}")
    public void deleteAuthor(@PathVariable Long id){
        authorService.deleteById(id);
    }
}
