package com.example.SystemLibraries.formModels;

import com.example.SystemLibraries.models.Edition;
import lombok.Data;

@Data
public class EditionInLib {
    private Long id;
    private String bookName;
    private String authorStr;
    private String publHouseName;
    private String depStr;
    private boolean available;

    public EditionInLib(Edition edition, Long libId){
        id = edition.getId();
        bookName = edition.getBook().getName();
        authorStr = edition.getBook().getAuthorStr();
        publHouseName = edition.getPublHouse().getName();
        depStr = edition.getCopyBooks().stream().filter(copyBook ->
                copyBook.getDepartment().getLibrary().getId() == libId).toList().get(0).getDepartment().getDepStr();
        available = edition.getCopyBooks().stream().filter(copyBook ->
                copyBook.getDepartment().getLibrary().getId() == libId
                        && copyBook.getStatusInThisLib().equals("в наличии")).count()>0;
    }

}
