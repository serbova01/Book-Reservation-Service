package com.example.SystemLibraries.services;

import com.example.SystemLibraries.models.Basket;
import com.example.SystemLibraries.views.FavoriteView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.util.Streamable;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Service
public class FavoriteService {
    @Autowired
    BasketService basketService;

    public List<FavoriteView> getAllByUserId(long userId){
        List<FavoriteView> favoriteViews = new ArrayList<>();
        Streamable.of(basketService.getAllFavoritesByUserId(userId)).forEach(basket -> {
            try {
                favoriteViews.add(new FavoriteView(basket));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
        return favoriteViews;
    }
    public FavoriteView get(long id) throws IOException {
        Basket basket = basketService.getBasket(id);
        return new FavoriteView(basket);
    }
}
