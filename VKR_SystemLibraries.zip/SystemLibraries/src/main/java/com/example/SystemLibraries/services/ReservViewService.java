package com.example.SystemLibraries.services;

import com.example.SystemLibraries.models.Reservation;
import com.example.SystemLibraries.views.ReservView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.util.Streamable;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Service
public class ReservViewService {
    @Autowired
    ReservationService reservationService;
    @Autowired
    CopyBookService copyBookService;
    public List<ReservView> getAllBySubsId(long subsId){
        List<ReservView> reqViews = new ArrayList<>();
        Streamable.of(reservationService.getAllReservationsBySubsId(subsId)).forEach(reservation -> {
            long maxCopies = copyBookService.getAllCopyBooksIsAvailableByLibId(reservation.getSubscription().getLibId())
                    .stream().filter(copyBook -> copyBook.getEdId() == reservation.getEdId()).count();
            try {
                reqViews.add(new ReservView(reservation, maxCopies));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
        return reqViews;
    }
    public ReservView get(long id) throws IOException {
        Reservation reservation = reservationService.getReservation(id);
        long maxCopies = copyBookService.getAllCopyBooksIsAvailableByLibId(reservation.getSubscription().getLibId())
                .stream().filter(copyBook -> copyBook.getEdId() == reservation.getEdId()).count();
        return new ReservView(reservation, maxCopies);
    }

    public List<ReservView> getAllByUserEmail(Long id) {
        List<ReservView> reservViews = new ArrayList<>();
        Streamable.of(reservationService.getReservsByUserEmail(id)).forEach(reservation -> {
            long maxCopies = copyBookService.getAllCopyBooksIsAvailableByLibId(reservation.getSubscription().getLibId())
                    .stream().filter(copyBook -> copyBook.getEdId() == reservation.getEdId()).count();
            try {
                reservViews.add(new ReservView(reservation, maxCopies));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
        return reservViews;
    }
}
