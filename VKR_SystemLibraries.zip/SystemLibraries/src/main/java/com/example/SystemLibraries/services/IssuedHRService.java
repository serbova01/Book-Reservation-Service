package com.example.SystemLibraries.services;

import com.example.SystemLibraries.models.HistoryReader;
import com.example.SystemLibraries.models.User;
import com.example.SystemLibraries.views.IssuedHRView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.util.Streamable;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Service
public class IssuedHRService {
    //@Autowired
    //IssuedHRRepository issuedHRRepository;
    @Autowired
    HistoryReaderService hrService;
    @Autowired
    UserService userService;

    public List<IssuedHRView> getAllBySubsId(long subsId){
        List<IssuedHRView> issuedHRs = new ArrayList<>();
        Streamable.of(hrService.getAllIssuedHRBySubsId(subsId)).forEach(hr -> {
            try {
                issuedHRs.add(new IssuedHRView(hr, " "));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
        return issuedHRs;
    }
    public IssuedHRView get(long id) throws IOException {
        HistoryReader hr = hrService.getHistoryReader(id);
        return new IssuedHRView(hr, " ");
    }
    public List<IssuedHRView> getAllIssuedByUserEmail(Long usId){
        List<IssuedHRView> issuedHRs = new ArrayList<>();
        String email = userService.getUser(usId).getEmail();
        Streamable.of(hrService.getAllIssuedHRByUserEmail(email)).forEach(hr -> {
            if(hr.getDateReturn().isAfter(LocalDate.now()) || hr.getDateReturn().isEqual(LocalDate.now())){
                try {
                    issuedHRs.add(new IssuedHRView(hr, "issueds"));
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        });
        return issuedHRs;
    }
    public List<IssuedHRView> getAllDelayedByUserEmail(Long usId){
        List<IssuedHRView> issuedHRs = new ArrayList<>();
        String email = userService.getUser(usId).getEmail();
        Streamable.of(hrService.getAllIssuedHRByUserEmail(email)).forEach(hr -> {
            if(hr.getDateReturn().isBefore(LocalDate.now())){
                try {
                    issuedHRs.add(new IssuedHRView(hr, "delayeds"));
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        });
        return issuedHRs;
    }
}
