package com.example.SystemLibraries.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Reader {
    @EmbeddedId
    private ReaderId readerId;
    @Column(name = "reader_subscription_id")
    public Long subsId;
    private String lastName;
    private String firstName;
    private String secondName;
    private String email;
    private String phoneNumber;
    private String address;
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    //@JsonFormat(pattern = "yyyy-MM-dd", shape = JsonFormat.Shape.STRING)
    private LocalDate dateRegistration;
    @Column(name = "parent_reader_reader_id", insertable=false, updatable=false)
    private Long parentId;
    @ManyToOne
    @JsonIgnore
    //@JsonManagedReference
    private Reader parentReader;
    @OneToMany(mappedBy = "parentReader")
    @JsonIgnore
    //@JsonBackReference
    private List<Reader> childsReader;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Embeddable
    public static class ReaderId implements Serializable {
        public Long reader_id;
        @ManyToOne
        @JsonIgnore
        //@JsonManagedReference(value="subscription-reader")
        public Subscription subscription;

        /*public void setSubscription(Subscription subscription) {
            this.subscription = subscription;
            setSubsId(subscription.getId());
        }
        public ReaderId(Long reader_id, Subscription subscription){
            this.reader_id = reader_id;
            this.subscription = subscription;
            this.subsId = subscription.getId();
        }*/
    }
    public void setParentReader(Reader parentReader) {
        this.parentReader = parentReader;
        if(parentReader != null)
            setParentId(parentReader.getReaderId().getReader_id());
    }

    public String getFIO(){
        return firstName + " " + secondName + " " + lastName;
    }
}
