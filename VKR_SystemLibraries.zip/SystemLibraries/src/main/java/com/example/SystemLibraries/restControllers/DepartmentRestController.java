package com.example.SystemLibraries.restControllers;

import com.example.SystemLibraries.models.Department;
import com.example.SystemLibraries.services.DepartmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/rest/department")
public class DepartmentRestController {
    @Autowired
    public DepartmentService departmentService;
    @GetMapping("/get-all")
    public List<Department> getAllDepartment(){
        return departmentService.getAllDepartments();
    }
    @GetMapping("/get-all/{id}")
    public List<Department> getAllDepartment(@PathVariable Long id){
        return departmentService.getAllDepartmentsByLibId(id);
    }
    @PostMapping("/save")
    public Department save(@RequestBody Department department){
        return departmentService.save(department);
    }
    @GetMapping("/get/{id}")
    public Department getDepartmentById(@PathVariable Long id){
        return departmentService.getDepartment(id);
    }
    @DeleteMapping("/delete/{id}")
    public void delete(@PathVariable Long id){
        departmentService.deleteById(id);
    }
}
