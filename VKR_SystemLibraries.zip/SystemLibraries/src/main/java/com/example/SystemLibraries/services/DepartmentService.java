package com.example.SystemLibraries.services;

import com.example.SystemLibraries.models.Department;
import com.example.SystemLibraries.repositories.DepartmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.util.Streamable;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class DepartmentService {
    @Autowired
    private DepartmentRepository departmentRepository;
    @Autowired
    private LibraryService libraryService;
    public Department save(Department department){
        department.setLibrary(libraryService.getLibrary(department.getLibId()));
        if(department.getDepId()>0)
            department.setParent(getDepartment(department.getDepId()));
        return departmentRepository.save(department);
    }
    public  Department addAuthorDep(Department department){
        department.setShortName(setShortName(department, getAllDepartmentsByLibId(department.getLibrary().getId())));
        return departmentRepository.save(department);
    }
    public String setShortName(Department department, List<Department> departments) {
        String shortName = "";
        shortName += department.getName().toCharArray()[0];
        int count=1;
        for (Department dep: departments) {
            if(((department.getParent() == null && dep.getParent() == department.getParent()) ||
                    (department.getParent() != null && dep.getParent() != null)) && dep.getShortName().contains(shortName)){
                count++;
            }
        }
        return shortName.concat(String.valueOf(count));
    }
    public void deleteById(long id){
        departmentRepository.deleteById(id);
    }
    public List<Department> getAllDepartments(){
        List<Department> departments = new ArrayList<>();
        Streamable.of(departmentRepository.findAll()).forEach(departments::add);
        return departments;
    }
    public List<Department> getAllDepartmentsByLibId(@Nullable Long libId){
        List<Department> departments = new ArrayList<>();
        Streamable.of(departmentRepository.findAll()).forEach(department ->{
            if ( libId == null || department.getLibrary().getId() == libId)
                departments.add(department);
        });
        return departments;
    }
    public Department getDepartment(long id){
        return departmentRepository.findById(id).get();
    }

    public List<Department> getDepParentsByLibId(@Nullable Long libId) {
        return getAllDepartments().stream().filter(dep -> dep.getParent() == null &&
                (libId == null || dep.getLibrary().getId() == libId) ).toList();
    }

    public Department getByNameAndLibrary(Department department) {
        return departmentRepository.findByNameAndLibId(department.getName(),
                department.getLibrary().getId());
    }
    public Department getByNameAndLibrary(String name, Long libId) {
        return departmentRepository.findByNameAndLibId(name,libId);
    }
}
