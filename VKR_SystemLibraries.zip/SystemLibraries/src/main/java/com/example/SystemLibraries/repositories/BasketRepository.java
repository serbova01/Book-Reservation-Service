package com.example.SystemLibraries.repositories;

import com.example.SystemLibraries.models.Basket;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BasketRepository extends JpaRepository<Basket, Long> {
    List<Basket> findByUsId(Long usId);
    Basket findByEdIdAndLibIdAndUsId(Long edId, Long libId, Long usId);
    List<Basket> findByEdId(Long edId);
    List<Basket> findByLibId(Long libId);
}
