package com.example.SystemLibraries.restControllers;

import com.example.SystemLibraries.models.*;
import com.example.SystemLibraries.services.ReservViewService;
import com.example.SystemLibraries.services.ReservationService;
import com.example.SystemLibraries.views.ReservView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/rest/reservation")
public class ReservationRestController {
    @Autowired
    public ReservationService reservationService;
    @Autowired
    public ReservViewService reservViewService;
    @GetMapping("/get-all")
    public List<Reservation> getAllReservation(){
        return reservationService.getAllReservations();
    }
    @GetMapping("/get-all/{id}")
    public List<Reservation> getAllReservation(@PathVariable Long id){
        return reservationService.getAllReservationsByLibId(id);
    }
    @GetMapping("/get-all-subs/{id}")
    public List<ReservView> getAllReservationBySubsId(@PathVariable Long id){
        return reservViewService.getAllBySubsId(id);
    }
    @GetMapping("/get-all-user/{id}")
    public List<ReservView> getAllReservationByUserId(@PathVariable Long id){
        return reservViewService.getAllByUserEmail(id);
    }
    @PostMapping("/save")
    public Reservation save(@RequestBody Reservation reservation){
        return reservationService.save(reservation);
    }
    @PostMapping("/add-to-reader")
    public Reservation addToReader(@RequestBody Reservation reservation){
        return reservationService.makingReserv(reservation);
    }
    @PostMapping("/add-to-reader-basket")
    public Reservation addToReaderBasket(@RequestBody Basket reservation){
        return reservationService.makingReserv(reservation);
    }
    @GetMapping("/add-to-reader-basket/{ids}")
    public Reservation addToReaderBasket(@PathVariable String ids) throws IOException {
        return reservationService.makingReservList(ids);
    }
    @GetMapping("/get/{id}")
    public Reservation getReservationById(@PathVariable Long id){
        return reservationService.getReservation(id);
    }
    @GetMapping("/delete/{id}")
    public Reservation delete(@PathVariable Long id){
        return reservationService.deleteById(id);
    }
    @GetMapping("/add")
    public void add(@RequestBody Reservation reservation){
        reservationService.add(reservation);
    }
    @GetMapping("/add-of-request")
    public void add(@RequestBody Request request){
        reservationService.add(request);
    }
    @GetMapping("/add-of-postponed")
    public void add(@RequestBody Postponed postponed, @RequestBody CopyBook copyBook){
        reservationService.add(postponed, copyBook);
    }
    @GetMapping("/reserv-delivered-book")
    public void reservDeliveredBook(@RequestBody Request request){
        reservationService.reservDeliveredBook(request);
    }
}
