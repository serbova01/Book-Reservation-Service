package com.example.SystemLibraries.services;

import com.example.SystemLibraries.models.Basket;
import com.example.SystemLibraries.models.Library;
import com.example.SystemLibraries.repositories.BasketRepository;
import com.example.SystemLibraries.views.BasketView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.util.Streamable;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Service
public class BasketService {
    @Autowired
    private BasketRepository basketRepository;
    @Autowired
    private EditionService editionService;
    @Autowired
    private UserService userService;
    @Autowired
    private LibraryService libraryService;
    @Autowired
    private ReaderService readerService;
    @Autowired
    private CopyBookService copyBookService;
    public Basket save(Basket basket){
        if(basket.getEdition() == null && basket.getEdId() != null){
            basket.setEdition(editionService.getEdition(basket.getEdId()));
        }
        basket.setUser(userService.getUser(basket.getUsId()));
        if(basket.getLibId() != null && basket.getLibId()>0){
            basket.setLibrary(libraryService.getLibrary(basket.getLibId()));
        }
        Basket bByEdLibUsIds = getByEdLibUs(basket.getEdId(), basket.getLibId(), basket.getUsId());
        if(bByEdLibUsIds != null && bByEdLibUsIds.getId() != basket.getId()){
            bByEdLibUsIds.setCount(bByEdLibUsIds.getCount() + basket.getCount());
            if(basket.getId()>0)
                deleteById(basket.getId());
            return basketRepository.save(bByEdLibUsIds);
        }
        return  basketRepository.save(basket);
    }
    public Basket addAsBasket(Basket basket){
        if(basket.getEdition() == null && basket.getEdId() != null){
            basket.setEdition(editionService.getEdition(basket.getEdId()));
        }
        basket.setUser(userService.getUser(basket.getUsId()));
        if(basket.getLibId() != null && basket.getLibId()>0){
            basket.setLibrary(libraryService.getLibrary(basket.getLibId()));
        }
        basket.setCount(1);
        List<Basket> findBasket = getBasketByUsId(basket.getUsId()).stream().filter(b ->
                b.getEdId() == basket.getEdId() && b.getLibId() == basket.getLibId()).toList();
        if(!findBasket.isEmpty()){
            findBasket.get(0).setCount(findBasket.get(0).getCount()+1);
            return basketRepository.save(findBasket.get(0));
        }
        return  basketRepository.save(basket);
    }
    public Basket addAsFavorite(Basket basket){
        if(basket.getEdition() == null && basket.getEdId() != null){
            basket.setEdition(editionService.getEdition(basket.getEdId()));
        }
        basket.setUser(userService.getUser(basket.getUsId()));
        if(basket.getLibId() != null){
            basket.setLibrary(libraryService.getLibrary(basket.getLibId()));
        }
        basket.setFavorite(true);
        Basket finalBasket = basket;
        List<Basket> baskets = getBasketByUsId(basket.getUsId()).stream().filter(b ->
                b.getEdId() == finalBasket.getEdId() && b.getLibId() == finalBasket.getLibId()).toList();
        if(!baskets.isEmpty()){
            baskets.get(0).setFavorite(true);
            basket = save(baskets.get(0));
        }else{
            basket.setCount(0);
            save(basket);
        }
        return basket;
    }
    public void deleteById(long id){
        basketRepository.deleteById(id);
    }
    public List<Basket> getAlsoBasketsByUserId(long userId){
        List<Basket> baskets = new ArrayList<>();
        Streamable.of(basketRepository.findAll()).forEach(basket->{
            if (basket.getUser().getId() == userId && (basket.getCount()>0 ||
                    (basket.getLibId() != null && basket.getLibId() > 0)))
                baskets.add(basket);
        });
        return baskets;
    }
    public List<Basket> getAllFavoritesByUserId(long userId){
        List<Basket> baskets = new ArrayList<>();
        Streamable.of(getBasketByUsId(userId)).forEach(basket->{
            if (basket.isFavorite() &&
                    (baskets.isEmpty() || baskets.stream().filter(b -> b.getEdId() == basket.getEdId()).count() == 0)){
                baskets.add(basket);
            }
        });
        return baskets;
    }
    public Basket getBasket(long id){
        return basketRepository.findById(id).get();
    }
    public Basket deleteFavoriteById(long id){
        Basket basket = getBasket(id);
        Basket finalBasket = basket;
        List<Basket> baskets = getBasketByUsId(basket.getUsId()).stream().filter(b ->
                b.getEdId() == finalBasket.getEdId()).toList();
        for(Basket b : baskets){
            if (b.getCount()>0){
                b.setFavorite(false);
                save(b);
                if(b.getId() == basket.getId())
                    basket = basketRepository.findById(id).get();
            } else{
                if(b.getId() == basket.getId())
                    basket = new Basket();
                deleteById(b.getId());
            }
        }
        return basket;
    }
    public BasketView deleteBasketById(long id){
        Basket basket = basketRepository.findById(id).get();
        if (basket.isFavorite()){
            Basket copy = new Basket();
            copy.setId(basket.getId());
            copy.setFavorite(basket.isFavorite());
            copy.setUsId(basket.getUsId());
            copy.setEdId(basket.getEdId());
            //basket.setCount(0);
            //basket.setLibId(0L);
            deleteById(basket.getId());
            save(copy);
        } else
            deleteById(basket.getId());
        return new BasketView();
    }

    public Basket deleteBaskets(String strIdsBasket) throws IOException {
        List<Long> list = getListIds(strIdsBasket);
        for(Long id:list){
            deleteBasketById(id);
        }
        return new Basket();
    }

    private List<Long> getListIds(String ids) {
        List<Long> list = new ArrayList<>();
        List<String> arr = new ArrayList<>();
        for (String s : ids.split(", ")){
            list.add(Long.parseLong(s, 10));
        }
        return list;
    }

    public List<Library> getAllByEditionAndUser(long edId, long userId) {
        List<Library> libraries = new ArrayList<>();
        Streamable.of(readerService.getAllSubsByReaderId(readerService.getReaderByEmail(
                userService.getUser(userId).getEmail()).stream().findFirst().get().getReaderId().reader_id)).forEach(subscription->{
            if (copyBookService.getAllCopyBooksIsAvailableByLibId(subscription.getLibId()).stream().filter(copyBook ->
                    copyBook.getEdId() == edId).count()>0)
                libraries.add(subscription.getLibrary());
        });
        return libraries;
    }
    public List<Basket> getBasketByUsId(Long usId) {
        return basketRepository.findByUsId(usId);
    }
    public Basket getByEdLibUs(Long edId, Long libId, Long usId) {
        return basketRepository.findByEdIdAndLibIdAndUsId(edId, libId, usId);
        //return basketRepository.findEditionAndLibraryAndUser(editionService.getEdition(edId),
        //        libraryService.getLibrary(libId), userService.getUser(usId));
    }

    public Basket getBasketByUsIdEdId(Long usId, Long edId) {
        List<Basket> b = getBasketByUsId(usId).stream().filter(basket -> basket.getEdId() == edId).toList();
        if (!b.isEmpty()){
            return b.get(0);
        }
        return new Basket();
    }
}
