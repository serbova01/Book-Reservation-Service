package com.example.SystemLibraries.models;

import com.example.SystemLibraries.views.DescripEditionView;
import com.example.SystemLibraries.views.HRView;
import com.example.SystemLibraries.views.ReqView;
import com.example.SystemLibraries.views.ReservView;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Library implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String cityNumber;
    private String email;
    private String address;
    private double latitude;
    private double longitude;
    @OneToMany(mappedBy = "library")
    @JsonIgnore
    //@JsonBackReference(value="user-library")
    private List<User> users;
    @OneToMany(mappedBy = "library")
    @JsonIgnore
    //@JsonBackReference(value="department-library")
    private List<Department> departments;
    @OneToMany(mappedBy = "library")
    @JsonIgnore
    //@JsonBackReference(value="basket-library")
    private List<Basket> baskets;
    @OneToMany(mappedBy = "library")
    @JsonIgnore
    //@JsonBackReference(value="subscription-library")
    private List<Subscription> subscriptions;
    @OneToMany(mappedBy = "library")
    @JsonIgnore
    private List<HRView> hrViewList;
    @OneToMany(mappedBy = "library")
    @JsonIgnore
    private List<DescripEditionView> descEdViewList;
    @OneToMany(mappedBy = "library")
    @JsonIgnore
    private List<ReservView> reservViewList;
    @OneToMany(mappedBy = "library")
    @JsonIgnore
    private List<ReqView> reqViewsList;

    public boolean isNullFields() {
        return name == null || name.length() == 0 || address == null || address.length() == 0 ||
                ((cityNumber == null || cityNumber.length() == 0) && (email == null || email.length() == 0));
    }
}
