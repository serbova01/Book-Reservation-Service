package com.example.SystemLibraries.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Postponed {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "subscription_id", insertable=false, updatable=false)
    private Long subsId;
    @ManyToOne
    @JsonIgnore
    //@JsonManagedReference(value="postponed-subscription")
    private Subscription subscription;
    @Column(name = "edition_id", insertable=false, updatable=false)
    private Long edId;
    @ManyToOne
    @JsonIgnore
    //@JsonManagedReference(value="postponed-edition")
    private Edition edition;

    public void setSubscription(Subscription subscription) {
        this.subscription = subscription;
        setSubsId(subscription.getId());
    }

    public void setEdition(Edition edition) {
        this.edition = edition;
        setEdId(edition.getId());
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Boolean getAvailable() {
        return edition.getCopyBooks().stream().filter(copyBook ->
                copyBook.getDepartment().getLibrary().getId() == subscription.getLibrary().getId() &&
                copyBook.getStatusInThisLib().equals("в наличии")).count()>0;
    }

    public void setSubsId(Long subsId) {
        this.subsId = subsId;
    }

    public void setEdId(Long edId) {
        this.edId = edId;
    }
}
