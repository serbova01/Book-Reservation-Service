package com.example.SystemLibraries.services;

import com.example.SystemLibraries.models.Reader;
import com.example.SystemLibraries.models.Subscription;
import com.example.SystemLibraries.repositories.ReaderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.util.Streamable;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ReaderService {
    @Autowired
    private ReaderRepository readerRepository;
    @Autowired
    private SubscriptionService subscriptionService;

    public Reader save(Reader reader){
        //reader.getReaderId().setSubscription(subscriptionService.getSubscription(reader.getReaderId().getSubsId()));
        if(reader.getReaderId().getSubscription() != null){
            reader.setSubsId(reader.getReaderId().getSubscription().getId());
        }else{
            if(reader.getSubsId() != null && reader.getSubsId() > 0){
                reader.getReaderId().setSubscription(subscriptionService.getSubscription(reader.getSubsId()));
            }
        }
        if(reader.getEmail()!= null){
            List<Reader> readers = getReader(reader.getReaderId().reader_id).stream().filter(read ->
                    !read.getReaderId().equals(reader.getReaderId())).toList();
            for(Reader r : readers){
                r.setEmail(reader.getEmail());
                readerRepository.save(r);
            }
        }
        return readerRepository.save(reader);
    }
    public Reader add(Reader reader){
        Reader reader1 = new Reader();
        reader1.setReaderId(reader.getReaderId());
        reader1.setAddress(reader.getAddress());
        reader1.setEmail(reader.getEmail());
        reader1.setDateRegistration(LocalDate.now());
        reader1.setPhoneNumber(reader.getPhoneNumber());
        reader1.setSecondName(reader.getSecondName());
        reader1.setFirstName(reader.getFirstName());
        reader1.setLastName(reader.getLastName());
        reader1.setSubsId(reader.getSubsId());
        return readerRepository.save(reader1);
    }
    //public void deleteByReaderId(long id){
    //    readerRepository.deleteById();
    //}
    public List<Reader> getAllReaders(){
        List<Reader> readers = new ArrayList<>();
        Streamable.of(readerRepository.findAll()).forEach(readers::add);
        return readers;
    }
    public List<Reader> getAllReadersByLibId(@Nullable Long libId){
        List<Reader> readers = new ArrayList<>();
        Streamable.of(readerRepository.findAll()).forEach(reader ->{
            if (libId == null || reader.getReaderId().getSubscription().getLibrary().getId() == libId)
                readers.add(reader);
        });
        return readers;
    }
    public List<Subscription> getAllSubsByReaderId(long readerId){
        List<Subscription> subscriptions = new ArrayList<>();
        Streamable.of(readerRepository.findAll()).forEach(reader ->{
            if (reader.getReaderId().getReader_id() == readerId){
                subscriptions.add(reader.getReaderId().getSubscription());
            }
        });
        return subscriptions;
    }
    public List<Reader> getAllReadersBySubsId(long subsId){
        List<Reader> readers = new ArrayList<>();
        Streamable.of(readerRepository.findAll()).forEach(reader ->{
            if (reader.getReaderId().getSubscription().getId() == subsId)
                readers.add(reader);
        });
        return readers;
    }
    public List<Reader> getReader(long id){
        return Streamable.of(readerRepository.findAll()).filter(reader ->
                reader.getReaderId().getReader_id() == id).stream().collect(Collectors.toList());
    }
    public List<Reader> getReaderByEmail(String email){
        if(email.length()>0)
            return readerRepository.findByEmail(email);
        else
            return new ArrayList<>();
    }
    public Reader findByPhoneNumber(String phoneNumber){
        return Streamable.of(readerRepository.findAll()).filter(reader ->
                reader.getPhoneNumber().equals(phoneNumber)).stream().findFirst().get();
    }

    public Reader getReaderByWhileId(Long id, Subscription subs) {
        return readerRepository.findByReaderId(new Reader.ReaderId(id,subs));
    }
    public Reader changeNewSubsByReader(Reader reader, Subscription newSubscription){
        Subscription subscription = subscriptionService.add(newSubscription);
        Reader newReader = new Reader(new Reader.ReaderId(reader.getReaderId().getReader_id(), subscription),
                subscription.getId(), reader.getLastName(), reader.getFirstName(), reader.getSecondName(), reader.getEmail(),
                reader.getPhoneNumber(), reader.getAddress(), reader.getDateRegistration(), reader.getParentId(),
                reader.getParentReader(), reader.getChildsReader());
        deleteByReaderId(reader.getReaderId().getReader_id(), reader.getSubsId());
        return readerRepository.save(newReader);
    }

    public void deleteAllById(Long id){
        for(Reader reader : getReader(id)){
            readerRepository.delete(reader);
        }
    }
    public void deleteByReaderId(Long id, Long idSubs){
        readerRepository.delete(getReaderByWhileId(id, subscriptionService.getSubscription(idSubs)));
    }

    public List<Reader> getByPhoneNumber(String phoneNumber) {
        return readerRepository.findByPhoneNumber(phoneNumber);
    }

    public List<Reader> getReadersByUser() {
        List<Reader> users = new ArrayList<>();
        Streamable.of(readerRepository.findAll()).forEach(reader ->{
            if (!reader.getEmail().equals(null) || reader.getEmail().length()>0)
                users.add(reader);
        });
        return users;
    }

    public Long getNewId() {
        Long id = -1L;
        for(Reader reader : getAllReaders()){
            if(reader.getReaderId().getReader_id() > id){
                id = reader.getReaderId().getReader_id();
            }
        }
        return id+1;
    }

    public Reader getByEmailAndSubs(String email, Long subsId){
        return readerRepository.findByEmailAndSubsId(email, subsId);
    }
}
