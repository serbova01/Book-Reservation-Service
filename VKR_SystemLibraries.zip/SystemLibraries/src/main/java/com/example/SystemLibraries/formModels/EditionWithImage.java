package com.example.SystemLibraries.formModels;

import com.example.SystemLibraries.models.Book;
import com.example.SystemLibraries.models.Edition;
import com.example.SystemLibraries.models.PublHouse;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.tomcat.util.http.fileupload.impl.FileSizeLimitExceededException;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
@Getter
@Setter
@NoArgsConstructor
public class EditionWithImage {

    private Long id;
    private String ISBN;
    private String discription;
    private String imagePath;
    private int year;
    private int countPage;
    private float price;
    private Book book;
    private PublHouse publHouse;

    private MultipartFile file;

    public boolean isNullFields() {
        return ISBN == null || ISBN.length() == 0;
    }

    public EditionWithImage(Edition edition) {
        id = edition.getId();
        ISBN = edition.getISBN();
        price = edition.getPrice();
        year = edition.getYear();
        countPage = edition.getCountPage();
        discription = edition.getDiscription();
        imagePath = edition.getImagePath();
        book = edition.getBook();
        publHouse = edition.getPublHouse();
    }

    public Edition convertToEdition(Edition edition) throws IOException {
        edition.setId(id);
        edition.setBook(book);
        edition.setDiscription(discription);
        edition.setISBN(ISBN);
        edition.setCountPage(countPage);
        edition.setPrice(price);
        edition.setYear(year);
        edition.setPublHouse(publHouse);
        edition.setImagePath(setImage(edition));
        return edition;
    }

    private String setImage(Edition edition) throws IOException,FileSizeLimitExceededException {
        StringBuilder fileNames = new StringBuilder();
        Path resourceDirectory = Paths.get("images");
        Path fileNameAndPath = Paths.get(resourceDirectory.toAbsolutePath().toString(), file.getOriginalFilename());
        fileNames.append(file.getOriginalFilename());
        if (edition.getImagePath() != null){
            File file1 = new File(String.format(fileNameAndPath.toAbsolutePath().toString()  + edition.getImagePath()));
            if (!file1.exists()){
                Files.write(fileNameAndPath, file.getBytes());
            }else{
                return edition.getImagePath();
            }
        }else{
            Files.write(fileNameAndPath, file.getBytes());
        }
        //edition.setImageName(file.getName());
        edition.setImagePath("/images/" + fileNames.toString());
        return edition.getImagePath();
    }
}
