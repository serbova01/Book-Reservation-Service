package com.example.SystemLibraries.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Request {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String status;
    @Column(name = "subscription_id", insertable=false, updatable=false)
    private Long subsId;
    @ManyToOne
    @JsonIgnore
    //@JsonManagedReference(value="request-subscription")
    private Subscription subscription;
    @Column(name = "edition_id", insertable=false, updatable=false)
    private Long edId;
    @ManyToOne
    @JsonIgnore
    //@JsonManagedReference(value="request-edition")
    private Edition edition;
    @Column(name = "copy_book_id", insertable=false, updatable=false)
    private Long copyId;
    @ManyToOne
    @JsonIgnore
    //@JsonManagedReference(value="request-copyBook")
    private CopyBook copyBook;

    public void setSubscription(Subscription subscription) {
        this.subscription = subscription;
        setSubsId(subscription.getId());
    }

    public void setCopyBook(CopyBook copyBook) {
        this.copyBook = copyBook;
        if(copyBook != null)
            setCopyId(copyBook.getId());
    }

    public void setEdition(Edition edition) {
        this.edition = edition;
        setEdId(edition.getId());
    }
    public Boolean getIsAvailable() {
        return edition.getCopyBooks().stream().filter(copyBook ->
                copyBook.getDepartment().getLibrary().getId() == subscription.getLibrary().getId() &&
                        copyBook.getStatusInThisLib().equals("в наличии")).count()>0;
    }
}
