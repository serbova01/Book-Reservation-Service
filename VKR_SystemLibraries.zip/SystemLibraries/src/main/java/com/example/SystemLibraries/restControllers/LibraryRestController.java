package com.example.SystemLibraries.restControllers;

import com.example.SystemLibraries.models.Library;
import com.example.SystemLibraries.services.LibraryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/rest")
public class LibraryRestController {
    @Autowired
    public LibraryService libraryService;
    @GetMapping("/library/get-all")
    public List<Library> getAllLibrary(){
        return libraryService.getAllLibraries();
    }

    @PostMapping("/library/save")
    public Library save(@RequestBody Library library){
        return libraryService.save(library);
    }
    @GetMapping("/library/get/{id}")
    public Library getLibraryById(@PathVariable Long id){
        return libraryService.getLibrary(id);
    }
    @DeleteMapping("/library/delete/{id}")
    public void deleteLibrary(@PathVariable Long id){
        libraryService.deleteById(id);
    }
}
