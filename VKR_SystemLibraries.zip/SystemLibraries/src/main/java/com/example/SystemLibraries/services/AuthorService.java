package com.example.SystemLibraries.services;

import com.example.SystemLibraries.models.Author;
import com.example.SystemLibraries.repositories.AuthorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.util.Streamable;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class AuthorService {
    @Autowired
    private AuthorRepository authorRepository;
    @Autowired
    private BookService bookService;

    public Author save(Author author){
        return  authorRepository.save(author);
    }
    public void deleteById(long id){
        authorRepository.deleteById(id);
    }
    public List<Author> getAllAuthors(){
        List<Author> authors = new ArrayList<>();
        Streamable.of(authorRepository.findAll()).forEach(author ->{
            //author.setBooks(bookService.getByAuthor(author));
            authors.add(author);
        });
        return authors;
    }
    public List<Author> getAllAuthorsByLibId(@Nullable Long libId){
        List<Author> authors = new ArrayList<>();
        Streamable.of(authorRepository.findAll()).forEach(author -> {
            if (libId == null || author.getBooks().stream().filter(book ->
                    book.getEditions().stream().filter(edition ->
                            edition.getCopyBooks().stream().filter(copyBook ->
                                    copyBook.getDepartment().getLibrary().getId() == libId)
                                    .count() > 0).count() > 0).count() > 0){
                author.setBooks(bookService.getByAuthor(author));
                authors.add(author);
            }


        });
        return authors;
    }
    public Author getAuthor(long id){
        Author author = authorRepository.findById(id).get();
        return author;
    }

    public Author getByFIO(Author author) {
        Author checkAuthor =
                authorRepository.findByFirstnameAndSecondnameAndLastname(author.getFirstname(),
                        author.getSecondname(), author.getLastname());
        return author;
    }
}
