package com.example.SystemLibraries.controllers;

import com.example.SystemLibraries.models.*;
import com.example.SystemLibraries.services.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.annotation.security.RolesAllowed;
import java.security.Principal;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/book")
public class BookController {
    @Autowired
    private BookService bookService;
    @Autowired
    private GenreService genreService;
    @Autowired
    private AuthorService authorService;
    @Autowired
    private CycleService cycleService;
    @Autowired
    private UserService userService;
    private String[] message={
            "Заполните обязательные поля: Название.",
            "Произведение с таким названием и списком авторов уже существует."
    };
    @GetMapping("/list")
    public String list(Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            model.addAttribute("user", user);
            List<Book> list = bookService.getAllBooks();
            model.addAttribute("books", list);
            //model.addAttribute("user", user);
            return "book/list";
        }else
            return "redirect:/home";
    }
    @GetMapping("/details/{id}")
    public String details(Model model, @PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            model.addAttribute("user", user);
            Book book = bookService.getBook(id);
            model.addAttribute("book", book);
            //model.addAttribute("user", user);
            return "book/details";
        }else
            return "redirect:/home";
    }
    @GetMapping("/create")
    public String create(Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            model.addAttribute("user", user);
            List<Cycle> cycles = cycleService.getAllCycles();
            List<Genre> genres = genreService.getAllGenres();
            model.addAttribute("book", new Book());
            model.addAttribute("cycles", cycles);
            model.addAttribute("genres", genres);
            //model.addAttribute("user", user);
            return "book/create";
        }else
            return "redirect:/home";
    }
    @PostMapping("/create")
    public String create(@ModelAttribute Book book, Model model){
        //if(mainServer.findBookByNameAndAuthors(book) == null){
        if (book.isNullFields()){
            model.addAttribute("message", message[0]);
            model.addAttribute("book", book);
            return "book/create";
        }
        bookService.save(book);
        return "redirect:/book/addAuthors/" + book.getId();
    }
    @GetMapping("/addAuthors/{id}")
    public String addAuthors(Model model, @PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            model.addAttribute("user", user);
            Book book = bookService.getBook(id);
            List<Author> authors = authorService.getAllAuthors();
            authors = authors.stream().filter(a -> !book.getAuthors().contains(a)).collect(Collectors.toList());
            model.addAttribute("book", book);
            model.addAttribute("authors", authors);
            //model.addAttribute("user", bookService.findUserByLogin(principal.getName()));
            return "book/addAuthors";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/addListAuthors/{idBook}/{idAuthor}")
    public String addAuthors(Model model, @PathVariable("idBook") Long idBook, @PathVariable("idAuthor") Long idAuthor, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            Book book = bookService.getBook(idBook);
            bookService.addAuthor(idBook, authorService.getAuthor(idAuthor));
            return "redirect:/book/addAuthors/" + book.getId();
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/deleteListAuthors/{idBook}/{idAuthor}")
    public String deleteAuthors(Model model, @PathVariable("idBook") Long idBook, @PathVariable("idAuthor") Long idAuthor, Principal principal){
        //User user =  bookService.findUserByLogin(principal.getName());
        Book book = bookService.getBook(idBook);
        bookService.deleteAuthor(idBook, authorService.getAuthor(idAuthor));
        List<Author> authors = authorService.getAllAuthors();
        model.addAttribute("book", book);
        model.addAttribute("authors", authors);
        //model.addAttribute("user", bookService.findUserByLogin(principal.getName()));
        return "redirect:/book/addAuthors/" + book.getId();

    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/edit/{id}")
    public String edit(Model model, @PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        Book book = bookService.getBook(id);
        Cycle[] cycles = cycleService.getAllCycles().toArray(new Cycle[0]);
        model.addAttribute("book", book);
        //model.addAttribute("cycles", cycleService.getAllCycles());
        model.addAttribute("genres", genreService.getAllGenres());
        model.addAttribute("cycles", cycles);
        //model.addAttribute("user", bookService.findUserByLogin(principal.getName()));
        return "book/edit";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/edit-m/{id_m}/{id}")
    public String edit(Model model, @PathVariable Long id, @PathVariable("id_m") Long id_m, Principal principal){
        //User user =  mainServer.findUserByLogin(principal.getName());
        if(id_m == 1)
            model.addAttribute("message", message[0]);
        else
            model.addAttribute("message", message[1]);
        Cycle[] cycles = cycleService.getAllCycles().toArray(new Cycle[0]);
        Book book = bookService.getBook(id);
        model.addAttribute("book", book);
        //model.addAttribute("cycles", cycleService.getAllCycles());
        model.addAttribute("genres", genreService.getAllGenres());
        model.addAttribute("cycles", cycles);
        //model.addAttribute("user", user);
        return "book/edit";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @PostMapping("/edit")
    public String edit(@ModelAttribute Book book, Model model){
        Book bookCheck = bookService.getByNameAndAuthors(book);
        if (book.isNullFields()){
            return "redirect:/book/edit-m/1/" + book.getId();
        }
        if (bookCheck != null && bookCheck.getId() != book.getId()){
            return "redirect:/book/edit-m/2/" + book.getId();
        }else{
            bookService.save(book);
            return "redirect:/book/list";
        }
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        bookService.deleteById(id);
        return "redirect:/book/list";
    }
}
