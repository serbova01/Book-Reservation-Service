package com.example.SystemLibraries.restControllers;

import com.example.SystemLibraries.models.Book;
import com.example.SystemLibraries.services.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/rest/book")
public class BookRestController {
    @Autowired
    public BookService bookService;
    @GetMapping("/get-all")
    public List<Book> getAllBook(){
        return bookService.getAllBooks();
    }
    @GetMapping("/get-all/{id}")
    public List<Book> getAllBook(@PathVariable Long id){
        return bookService.getAllBooksByLibId(id);
    }
    @PostMapping("/save")
    public Book save(@RequestBody Book book){
        return bookService.save(book);
    }
    @GetMapping("/get/{id}")
    public Book getBookById(@PathVariable Long id){
        return bookService.getBook(id);
    }
    @DeleteMapping("/delete/{id}")
    public void deleteBook(@PathVariable Long id){
        bookService.deleteById(id);
    }
}
