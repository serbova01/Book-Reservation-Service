package com.example.SystemLibraries.config;

public class AuthResponse {
    private Long id;
    private String username;
    private String accessToken;

    public AuthResponse() { }

    public AuthResponse(String email, String accessToken) {
        this.username = email;
        this.accessToken = accessToken;
    }

    public AuthResponse(Long id, String email, String accessToken) {
        this.id = id;
        this.username = email;
        this.accessToken = accessToken;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String userName) {
        this.username = userName;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }
}
