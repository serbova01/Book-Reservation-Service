package com.example.SystemLibraries.formModels;

import com.example.SystemLibraries.models.Reservation;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.web.bind.annotation.GetMapping;

@Getter
@Setter
public class ConfimReservAlert {
    private String editionname;
    private String libraryName;
    private Long edId;
    private Long subsId;


    public ConfimReservAlert(Reservation reservation) {
        edId = reservation.getEdId();
        subsId = reservation.getSubsId();
        editionname = reservation.getEdition().getBook().getName();
        libraryName = reservation.getSubscription().getLibrary().getName();
    }

    public Reservation convertToReservation() {
        Reservation reservation = new Reservation();
        reservation.setSubsId(subsId);
        reservation.setEdId(edId);
        return reservation;
    }
}
