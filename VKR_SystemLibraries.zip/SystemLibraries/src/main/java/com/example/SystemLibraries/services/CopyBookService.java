package com.example.SystemLibraries.services;

import com.example.SystemLibraries.models.*;
import com.example.SystemLibraries.repositories.CopyBookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.util.Streamable;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CopyBookService {
    @Autowired
    private CopyBookRepository copyBookRepository;
    @Autowired
    private EditionService editionService;
    @Autowired
    private DepartmentService departmentService;
    public CopyBook save(CopyBook copyBook){
        copyBook.setDepartment(departmentService.getDepartment(copyBook.getDepId()));
        copyBook.setEdition(editionService.getEdition(copyBook.getEdId()));
        return  copyBookRepository.save(copyBook);
    }
    public CopyBook saveWithAnDep(CopyBook copyBook, Library library){
        Book book = copyBook.getEdition().getBook();
        Department department = new Department();
        Department checkDep = departmentService.getByNameAndLibrary(book.getAuthors().get(0).getFirstname(), library.getId());
        if(checkDep == null){
            department.setParent(departmentService.getByNameAndLibrary(book.getGenre().getName(), library.getId()));
            department.setLibrary(library);
            department.setName(book.getAuthors().get(0).getFirstname());
            department = departmentService.addAuthorDep(department);
        }else
            department = checkDep;
        copyBook.setDepartment(department);
        return  copyBookRepository.save(copyBook);
    }
    public void deleteById(long id){
        copyBookRepository.deleteById(id);
    }
    public List<CopyBook> getAllCopyBooks(){
        List<CopyBook> copyBooks = new ArrayList<>();
        Streamable.of(copyBookRepository.findAll()).forEach(copyBooks::add);
        return copyBooks;
    }
    public List<CopyBook> getAllCopyBooksIsAvailableByLibId(@Nullable Long libId){
        List<CopyBook> copyBooks = new ArrayList<>();
        Streamable.of(copyBookRepository.findAll()).forEach(copyBook -> {
            if((libId == null || copyBook.getDepartment().getLibrary().getId() == libId)
                    && copyBook.getStatusInThisLib().equals("в наличии"))
                copyBooks.add(copyBook);
        });
        return copyBooks;
    }
    public CopyBook getCopyBook(long id){
        return copyBookRepository.findById(id).get();
    }
    public CopyBook writeOffCopyBook(long id){
        CopyBook copyBook = getCopyBook(id);
        copyBook.setStatusInThisLib("списано");
        return  copyBookRepository.save(copyBook);
    }
    public List<CopyBook> getIssuedCopyBooksByLibId(@Nullable Long libId){
        List<CopyBook> copyBooks = new ArrayList<>();
        Streamable.of(copyBookRepository.findAll()).forEach(copyBook -> {
            if((libId == null || copyBook.getDepartment().getLibrary().getId() == libId)
                    && (copyBook.getStatusInThisLib().equals("выдан") ||
                    (copyBook.getStatusInAnotherLib() != null && copyBook.getStatusInAnotherLib().equals("выдан")) ))
                copyBooks.add(copyBook);
        });
        return copyBooks;
    }
    public List<CopyBook> getReservedCopyBooksByLibId(@Nullable Long libId){
        List<CopyBook> copyBooks = new ArrayList<>();
        Streamable.of(copyBookRepository.findAll()).forEach(copyBook -> {
            if(libId == null || (copyBook.getDepartment().getLibrary().getId() == libId
                    && copyBook.getStatusInThisLib().equals("забронирован")))
                copyBooks.add(copyBook);
        });
        return copyBooks;
    }

    public List<CopyBook> getByInvNumber(String invNumber) {
        return copyBookRepository.findByInvNumber(invNumber);
    }
    public CopyBook getByInvNumberInLib(String invNumber, Long libId) {
        List<CopyBook> list = copyBookRepository.findByInvNumber(invNumber).stream().filter(copyBook ->
                copyBook.getDepartment().getLibrary().getId() == libId).toList();
        if(list.isEmpty())
            return null;
        return list.get(0);
    }

    public List<CopyBook> getAllWrittenOffByLibId(@Nullable Long libId) {
        List<CopyBook> copyBooks = new ArrayList<>();
        Streamable.of(copyBookRepository.findAll()).forEach(copyBook -> {
            if((libId == null || copyBook.getDepartment().getLibrary().getId() == libId)
                    && (copyBook.getStatusInThisLib().equals("списано")))
                copyBooks.add(copyBook);
        });
        return copyBooks;
    }
}
