package com.example.SystemLibraries.services;

import com.example.SystemLibraries.models.Edition;
import com.example.SystemLibraries.views.CatalogView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.util.Streamable;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Service
public class CatalogService {
    @Autowired
    private EditionService editionService;
    @Autowired
    private BookService bookService;
    @Autowired
    private GenreService genreService;
    @Autowired
    private CycleService cycleService;
    @Autowired
    private PublHouseService publHouseService;

    public List<CatalogView> getAll(){
        List<CatalogView> catalog = new ArrayList<>();
        Streamable.of(editionService.getAllEditions()).forEach(edition -> {
            CatalogView catalogView = null;
            try {
                catalogView = new CatalogView(edition);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            catalog.add(catalogView);
        });
        return catalog;
    }
    public CatalogView get(long id) throws IOException {
        Edition edition = editionService.getEdition(id);
        CatalogView catalogView = new CatalogView(edition);
        return catalogView;
    }
}
