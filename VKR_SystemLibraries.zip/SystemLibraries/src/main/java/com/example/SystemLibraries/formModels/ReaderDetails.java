package com.example.SystemLibraries.formModels;

import com.example.SystemLibraries.models.Reader;
import com.example.SystemLibraries.models.Subscription;
import lombok.*;

import java.time.LocalDate;
@AllArgsConstructor
@NoArgsConstructor
public class ReaderDetails {
    private Long reader_id;
    private Subscription subscription;
    private String lastName;
    private String firstName;
    private String secondName;
    private String email;
    private String phoneNumber;
    private String street;
    private String house;
    private String flat;
    private LocalDate dateRegistration;
    private boolean isChild;
    private Reader parent;

    public ReaderDetails(Reader reader){
        reader_id = reader.getReaderId().getReader_id();
        subscription = reader.getReaderId().getSubscription();
        firstName = reader.getFirstName();
        secondName = reader.getSecondName();
        lastName = reader.getLastName();
        email = reader.getEmail();
        phoneNumber = reader.getPhoneNumber();
        String[] address = reader.getAddress().split(", ");
        street = address[0];
        house = address[1];
        if(address.length>2)
            flat = address[2];
        dateRegistration = reader.getDateRegistration();
        isChild =reader.getParentReader() != null;
        parent = reader.getParentReader();
    }

    public boolean isNullFields() {
        return firstName == null || firstName.length() == 0 || secondName == null || secondName.length() == 0 ||
                ((phoneNumber == null || phoneNumber.length() == 0) && (email == null || email.length() == 0)) ||
                street == null || street.length() == 0 || house == null || house.length() == 0;
    }

    public Reader convertToReader(Reader reader) {
        reader.setEmail(email);
        reader.setAddress(street + ", " + house +
                ((flat != null && flat.length()>0)? (", " + flat) : ""));
        reader.setDateRegistration(dateRegistration);
        reader.setLastName(lastName);
        reader.setFirstName(firstName);
        reader.setSecondName(secondName);
        reader.getReaderId().setSubscription(subscription);
        reader.setSubsId(subscription.getId());
        reader.setPhoneNumber(phoneNumber);
        return reader;
    }

    public Reader getParent() {
        return parent;
    }

    public void setParent(Reader parent) {
        this.parent = parent;
    }

    public String getFIO(){
        return firstName + " " + secondName + " " + lastName;
    }
    public String getAddress(){
        return street + ", " + house + ((flat != null && flat.length()>0) ? (", " + flat) : "");
    }

    public Long getReader_id() {
        return reader_id;
    }

    public void setReader_id(Long reader_id) {
        this.reader_id = reader_id;
    }

    public Subscription getSubscription() {
        return subscription;
    }

    public void setSubscription(Subscription subscription) {
        this.subscription = subscription;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getSecondName() {
        return secondName;
    }

    public void setSecondName(String secondName) {
        this.secondName = secondName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getHouse() {
        return house;
    }

    public void setHouse(String house) {
        this.house = house;
    }

    public String getFlat() {
        return flat;
    }

    public void setFlat(String flat) {
        this.flat = flat;
    }

    public LocalDate getDateRegistration() {
        return dateRegistration;
    }

    public void setDateRegistration(LocalDate dateRegistration) {
        this.dateRegistration = dateRegistration;
    }

    public Boolean getIsChild(){
        return isChild;
    }

    public boolean isChild() {
        return isChild;
    }

    public void setIsChild(boolean child) {
        isChild = child;
    }

    public void setChild(boolean child) {
        isChild = child;
    }
}
