package com.example.SystemLibraries.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class CopyBook {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String invNumber;
    private String statusInThisLib;
    private String statusInAnotherLib;
    private String BBK;
    @Column(name = "department_id", insertable=false, updatable=false)
    private Long depId;
    @ManyToOne
    @JsonIgnore
    //@JsonManagedReference(value="department-copybook")
    private Department department;
    @Column(name = "edition_id", insertable=false, updatable=false)
    private Long edId;
    @ManyToOne
    @JsonIgnore
    //@JsonManagedReference(value="edition-copybook")
    private Edition edition;

    @OneToMany(mappedBy = "copyBook")
    @JsonIgnore
    //@JsonBackReference(value="reservation-copybook")
    private List<Reservation> reservations;
    @OneToMany(mappedBy = "copyBook")
    @JsonIgnore
    //@JsonBackReference(value="request-copybook")
    private List<Request> requests;
    @OneToMany(mappedBy = "copyBook")
    @JsonIgnore
    //@JsonBackReference(value="historyReader-copybook")
    private List<HistoryReader> historyReaders;

    public void setDepartment(Department department) {
        this.department = department;
        setDepId(department.getId());
    }

    public void setEdition(Edition edition) {
        this.edition = edition;
        setEdId(edition.getId());
    }

    public String getName(){
        return invNumber + " " + edition.getBook().getName();
    }
}
