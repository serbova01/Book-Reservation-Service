package com.example.SystemLibraries.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.lang.Nullable;

import javax.persistence.*;
import java.util.List;

@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Book{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String authorStr;
    @ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinTable(name = "book_author",
            joinColumns = @JoinColumn(name = "books_id", referencedColumnName = "id"),
            inverseJoinColumns = @JoinColumn(name = "authors_id", referencedColumnName = "id"))
    //@JsonBackReference(value="author-book")
    @JsonIgnore
    private List<Author> authors;
    @Column(name = "cycle_id", insertable=false, updatable=false)
    private Long cId;
    @ManyToOne
    @JsonIgnore
    //@JsonManagedReference(value="book-cycle")
    @Nullable
    private Cycle cycle;
    @Column(name = "genre_id", insertable=false, updatable=false)
    private Long gId;
    @ManyToOne
    @JsonIgnore
    //@JsonManagedReference(value="book-genre")
    private Genre genre;
    @OneToMany(mappedBy = "book")
    @JsonIgnore
    //@JsonBackReference(value="edition-book")
    private List<Edition> editions;

    public String getAuthorStr() {
        String str = "";
        for (Author author: authors) {
            str+= author.getSecondname().toCharArray()[0] + ".";
            if (author.getLastname() != null && author.getLastname().length() > 1){
                str +=  author.getLastname().toCharArray()[0] + ".";
            }
            str += " " +author.getFirstname() + ", ";
        }
        if (authors.size()>0)
            str = str.subSequence(0, str.length()-2).toString();
        return str;
    }

    public void setCycle(@Nullable Cycle cycle) {
        this.cycle = cycle;
        if (cycle != null){
            setCId(cycle.getId());
        }
    }

    public void setGenre(Genre genre) {
        this.genre = genre;
        setGId(genre.getId());
    }

    public boolean isNullFields() {
        return name == null || name.length() == 0 || genre == null;
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public List<Author> getAuthors() {
        return authors;
    }

    public Long getCId() {
        return cId;
    }

    @Nullable
    public Cycle getCycle() {
        return cycle;
    }

    public Long getGId() {
        return gId;
    }

    public Genre getGenre() {
        return genre;
    }

    public List<Edition> getEditions() {
        return editions;
    }
}
