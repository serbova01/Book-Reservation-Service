package com.example.SystemLibraries.restControllers;

import com.example.SystemLibraries.models.Cycle;
import com.example.SystemLibraries.services.CycleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/rest/cycle")
public class CycleRestController {
    @Autowired
    public CycleService cycleService;
    @GetMapping("/get-all")
    public List<Cycle> getAllCycle(){
        return cycleService.getAllCycles();
    }
    @GetMapping("/get-all/{id}")
    public List<Cycle> getAllCycle(@PathVariable Long id){
        return cycleService.getAllCyclesByLibId(id);
    }
    @PostMapping("/save")
    public Cycle save(@RequestBody Cycle author){
        return cycleService.save(author);
    }
    @GetMapping("/get/{id}")
    public Cycle getCycleById(@PathVariable Long id){
        return cycleService.getCycle(id);
    }
    @DeleteMapping("/delete/{id}")
    public void delete(@PathVariable Long id){
        cycleService.deleteById(id);
    }
}
