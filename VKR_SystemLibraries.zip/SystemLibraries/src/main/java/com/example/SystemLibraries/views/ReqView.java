package com.example.SystemLibraries.views;

import com.example.SystemLibraries.models.Library;
import com.example.SystemLibraries.models.Request;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import javax.persistence.*;
import lombok.Getter;
import org.hibernate.annotations.Immutable;

import java.io.IOException;

@Entity
@Table(name = "v_req")
@Getter
@Immutable
public class ReqView {
    @Id
    private Long id;
    private String status;
    private Long usId;
    private Long edId;
    @ManyToOne
    @JsonManagedReference
    private CatalogView edition;
    private Long libId;
    private String libName;
    private String libAddress;
    @ManyToOne
    @JsonManagedReference
    private Library library;
    public ReqView(Request request) throws IOException {
        id = request.getId();
        status = request.getStatus();
        libId = request.getSubscription().getLibId();
        libName = request.getSubscription().getLibrary().getName();
        edId = request.getEdId();
        edition = new CatalogView(request.getEdition());
        libAddress = request.getSubscription().getLibrary().getAddress();
        library = request.getSubscription().getLibrary();
        usId = 0L;
    }
    public ReqView(Request request, Long usId) throws IOException {
        id = request.getId();
        status = request.getStatus();
        libId = request.getSubscription().getLibId();
        libName = request.getSubscription().getLibrary().getName();
        edId = request.getEdId();
        edition = new CatalogView(request.getEdition());
        libAddress = request.getSubscription().getLibrary().getAddress();
        this.usId = usId;
    }
}
