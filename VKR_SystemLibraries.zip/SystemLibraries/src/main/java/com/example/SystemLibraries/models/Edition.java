package com.example.SystemLibraries.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;

@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Edition {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String ISBN;
    private String discription;
    private String imagePath;
    private int year;
    private int countPage;
    private float price;
    @Column(name = "book_id", insertable=false, updatable=false)
    private Long bId;
    @ManyToOne
    @JsonIgnore
    //@JsonManagedReference(value="edition-book")
    private Book book;
    @Column(name = "publ_house_id", insertable=false, updatable=false)
    private Long publHId;
    @ManyToOne
    @JsonIgnore
    //@JsonManagedReference(value="edition-publHouse")
    private PublHouse publHouse;

    @OneToMany(mappedBy = "edition")
    @JsonIgnore
    //@JsonBackReference(value="copyBook-edition")
    private List<CopyBook> copyBooks;
    @OneToMany(mappedBy = "edition")
    @JsonIgnore
    //@JsonBackReference(value="basket-edition")
    private List<Basket> baskets;
    @OneToMany(mappedBy = "edition")
    @JsonIgnore
    //@JsonBackReference(value="reservation-edition")
    private List<Reservation> reservations;
    @OneToMany(mappedBy = "edition")
    @JsonIgnore
    //@JsonBackReference(value="request-edition")
    private List<Request> requests;
    @OneToMany(mappedBy = "edition")
    @JsonIgnore
    //@JsonBackReference(value="postponed-edition")
    private List<Postponed> postponeds;

    public void setBook(Book book) {
        this.book = book;
        setBId(book.getId());
    }

    public void setPublHouse(PublHouse publHouse) {
        this.publHouse = publHouse;
        setPublHId(publHouse.getId());
    }

    public boolean isNullFields() {
        return ISBN == null || ISBN.length() == 0;
    }
    public String getName(){
        return ISBN + " " + book.getName() + " " + publHouse.getName();
    }

    public String toText(){
        return book.getName() + "\n" + book.getAuthorStr() + "\n" + publHouse.getName();
    }

    public void setImagePath(String imagePath) {
        if(imagePath == null){
            this.imagePath = "/images/empty_book.png";
        }else
            this.imagePath = imagePath;
    }

    public List<CopyBook> getAvailableInLibCopies(Long libId){
        return copyBooks.stream().filter(copyBook -> copyBook.getDepartment().getLibrary().getId() == libId &&
                copyBook.getStatusInThisLib().equals("в наличии")).toList();
    }

    public Long getId() {
        return id;
    }

    public String getISBN() {
        return ISBN;
    }

    public String getDiscription() {
        return discription;
    }

    public String getImagePath() {
        if(imagePath == null)
            return "/images/empty_book.png";
        return imagePath;
    }

    public int getYear() {
        return year;
    }

    public int getCountPage() {
        return countPage;
    }

    public float getPrice() {
        return price;
    }

    public Long getBId() {
        return bId;
    }

    public Book getBook() {
        return book;
    }

    public Long getPublHId() {
        return publHId;
    }

    public PublHouse getPublHouse() {
        return publHouse;
    }

    public List<CopyBook> getCopyBooks() {
        return copyBooks;
    }

    public List<Basket> getBaskets() {
        return baskets;
    }

    public List<Reservation> getReservations() {
        return reservations;
    }

    public List<Request> getRequests() {
        return requests;
    }

    public List<Postponed> getPostponeds() {
        return postponeds;
    }

}
