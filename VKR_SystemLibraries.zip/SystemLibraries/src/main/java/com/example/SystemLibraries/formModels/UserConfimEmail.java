package com.example.SystemLibraries.formModels;

import com.example.SystemLibraries.models.User;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class UserConfimEmail {
    private Long id;
    private String email;
    private String code;
    private String confimCode;

    public UserConfimEmail(User user){
        id = user.getId();
    }
}
