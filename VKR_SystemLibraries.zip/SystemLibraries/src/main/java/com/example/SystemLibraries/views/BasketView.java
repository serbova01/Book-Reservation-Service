package com.example.SystemLibraries.views;

import com.example.SystemLibraries.models.Basket;
import com.example.SystemLibraries.models.Library;
import com.example.SystemLibraries.models.Subscription;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Immutable;

import javax.persistence.*;
import java.io.IOException;

@Table(name = "v_basket")
@Getter
@NoArgsConstructor
@Immutable
public class BasketView {
    @Id
    private Long id;
    private boolean favorite;
    private int count;
    private long maxCountCopies;
    private Long libId;
    private Long subsId;
    private Long edId;
    private Long usId;
    @ManyToOne
    @JsonManagedReference
    private CatalogView edition;
    @ManyToOne
    @JsonManagedReference
    private Library library;

    public BasketView(Basket basket, Subscription subscription, long maxCountCopies) throws IOException {
        id = basket.getId();
        favorite = basket.isFavorite();
        count = basket.getCount();
        this.maxCountCopies = maxCountCopies;
        libId = basket.getLibId();
        library = basket.getLibrary();
        subsId = subscription.getId();
        edId = basket.getEdId();
        edition = new CatalogView(basket.getEdition());
        usId = basket.getUsId();
    }
}
