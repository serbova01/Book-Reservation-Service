package com.example.SystemLibraries.formModels;

import com.example.SystemLibraries.models.Basket;
import com.example.SystemLibraries.models.Edition;
import com.example.SystemLibraries.models.Library;
import com.example.SystemLibraries.views.DescripEditionView;
import com.example.SystemLibraries.views.FavoriteView;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.IOException;
import java.util.List;
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class EditionWithLibs {
    private Long id;
    private Long edId;
    private String bookName;
    private String authorStr;
    private String publHouseName;
    private String imageName;
    List<DescripEditionView> libraries;
    DescripEditionView selectedLib;

    public EditionWithLibs(FavoriteView favorite, List<DescripEditionView> list) throws IOException {
        id = favorite.getId();
        edId = favorite.getEdition().getId();
        bookName = favorite.getEdition().getBookName();
        authorStr = favorite.getEdition().getBookAuthorStr();
        imageName = favorite.getEdition().getImageName();
        publHouseName = favorite.getEdition().getPublHouseName();
        libraries = list;
        Library emptyLib = new Library();
        emptyLib.setId(0L);
        emptyLib.setName("[Добавить без указания библиотеки.]");
        selectedLib = new DescripEditionView(favorite.getEdId(), 0L, emptyLib, 0L, false);
        libraries.add(selectedLib);
    }
}
