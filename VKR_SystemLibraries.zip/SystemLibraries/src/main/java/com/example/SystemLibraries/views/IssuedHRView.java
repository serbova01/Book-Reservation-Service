package com.example.SystemLibraries.views;

import com.example.SystemLibraries.models.HistoryReader;
import com.example.SystemLibraries.models.Library;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import javax.persistence.*;
import lombok.Getter;
import org.hibernate.annotations.Immutable;

import java.io.IOException;
import java.time.temporal.ChronoUnit;

@Entity
@Table(name = "v_issue_hr")

@Immutable
public class IssuedHRView {
    @Id
    private Long id;
    private String dateIssueStr;
    private String dateReturnStr;
    private String invNum;
    private boolean isCanBeExtended;
    private String type;
    private Long libId;
    @ManyToOne
    @JsonManagedReference
    private Library library;
    private Long edId;
    @ManyToOne
    @JsonManagedReference
    private CatalogView edition;

    public IssuedHRView(HistoryReader hr, String type) throws IOException {
        this.id = hr.getId();
        this.dateIssueStr = hr.getDateIssue().toString();
        this.dateReturnStr = hr.getDateReturn().toString();
        this.edId = hr.getCopyBook().getEdId();
        edition = new CatalogView(hr.getCopyBook().getEdition());
        this.invNum = hr.getCopyBook().getInvNumber();
        this.type = type;
        this.libId = hr.getSubscription().getLibId();
        library = hr.getSubscription().getLibrary();
        //this.libName = hr.getSubscription().getLibrary().getName();
        //libAddress = hr.getSubscription().getLibrary().getAddress();
        isCanBeExtended = ChronoUnit.MONTHS.between(hr.getDateIssue(), hr.getDateReturn()) < 5;
    }

    public Long getId() {
        return id;
    }

    public String getDateIssueStr() {
        return dateIssueStr;
    }

    public String getDateReturnStr() {
        return dateReturnStr;
    }

    public String getInvNum() {
        return invNum;
    }

    public boolean isCanBeExtended() {
        return isCanBeExtended;
    }
    public boolean getIsCanBeExtended() {
        return isCanBeExtended;
    }

    public String getType() {
        return type;
    }

    public Long getLibId() {
        return libId;
    }

    public Library getLibrary() {
        return library;
    }

    public Long getEdId() {
        return edId;
    }

    public CatalogView getEdition() {
        return edition;
    }
}
