package com.example.SystemLibraries.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Department {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String shortName;
    @Column(name = "library_id", insertable=false, updatable=false)
    private Long libId;
    @ManyToOne
    @JsonIgnore
    //@JsonManagedReference(value="department-library")
    private Library library;
    @Column(name = "parent_id", insertable=false, updatable=false)
    private Long depId;
    @ManyToOne
    @JsonIgnore
    //@JsonManagedReference
    private Department parent;
    @OneToMany(mappedBy = "parent")
    @JsonIgnore
    //@JsonBackReference
    private List<Department> departments;
    @OneToMany(mappedBy = "department")
    @JsonIgnore
    //@JsonBackReference(value="copyBook-department")
    private List<CopyBook> copyBooks;

    public void setParent(Department parent) {
        this.parent = parent;
    }

    public void setLibrary(Library library) {
        this.library = library;
        setLibId(library.getId());
    }
    public String getDepStr(){
        if(parent == null)
            return shortName;
        return parent.shortName + " " + shortName;
    }
}
