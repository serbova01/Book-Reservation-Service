package com.example.SystemLibraries.services;

import com.example.SystemLibraries.models.*;
import com.example.SystemLibraries.repositories.ReservationRepository;
import com.example.SystemLibraries.views.BasketView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.util.Streamable;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Service
public class ReservationService {
    @Autowired
    private ReservationRepository reservationRepository;
    @Autowired
    private CopyBookService copyBookService;
    @Autowired
    private RequestService requestService;
    @Autowired
    private EditionService editionService;
    @Autowired
    private SubscriptionService subscriptionService;
    @Autowired
    private ReaderService readerService;
    @Autowired
    private PostponedService postponedService;
    @Autowired
    private BasketService basketService;
    @Autowired
    private UserService userService;

    public Reservation save(Reservation reservation){
        reservation.setEdition(editionService.getEdition(reservation.getEdId()));
        reservation.setSubscription(subscriptionService.getSubscription(reservation.getSubsId()));
        reservation.setCopyBook(copyBookService.getCopyBook(reservation.getCopyId()));
        return  reservationRepository.save(reservation);
    }
    public Reservation deleteById(long id){
        Reservation reservation = getReservation(id);
        if(reservation.getSubscription().getLibrary().getId() ==
                reservation.getCopyBook().getDepartment().getLibrary().getId()){
            reservation.getCopyBook().setStatusInThisLib("в наличии");
            copyBookService.save(reservation.getCopyBook());
        }else{
            Request request = requestService.getAllRequests().stream().filter(req -> req.getCopyBook() != null &&
                    req.getCopyBook().getId() == reservation.getCopyBook().getId()).findFirst().get();
            requestService.returnBookInLib(request);
        }
        reservationRepository.deleteById(id);
        return new Reservation();
    }
    public List<Reservation> getAllReservations(){
        List<Reservation> reservations = new ArrayList<>();
        Streamable.of(reservationRepository.findAll()).forEach(reservations::add);
        return reservations;
    }
    public List<Reservation> getAllReservationsByLibId(@Nullable Long libId){
        List<Reservation> reservations = new ArrayList<>();
        Streamable.of(reservationRepository.findAll()).forEach(reservation ->{
            if(libId == null || reservation.getSubscription().getLibrary().getId() == libId)
                reservations.add(reservation);
        });
        return reservations;
    }
    public Reservation getReservation(long id){
        return reservationRepository.findById(id).get();
    }
    public Reservation makingReserv(Reservation reservation) {
        reservation.setEdition(editionService.getEdition(reservation.getEdId()));
        reservation.setSubscription(subscriptionService.getSubscription(reservation.getSubsId()));
        List<CopyBook> copiesBook = reservation.getEdition().getCopyBooks().stream().filter(copy ->
                copy.getStatusInThisLib().equals("в наличии")).toList();
        if(!copiesBook.isEmpty()){
            CopyBook copyBook = copiesBook.get(0);
            copyBook.setStatusInThisLib("оформлен на бронь");
            copyBookService.save(copyBook);
            reservation.setCopyBook(copyBook);
            reservation.setDateForm(LocalDate.now());
            reservation.setStatus("оформлен");
            return reservationRepository.save(reservation);
        }
        return new Reservation();
    }
    public Reservation makingReserv(Basket basketView) {
        Reservation reservation = new Reservation();
        reservation.setEdition(editionService.getEdition(basketView.getEdId()));
        reservation.setSubscription(userService.getSubs(basketView.getUsId(), basketView.getLibId()));
        reservation.setDateForm(LocalDate.now());
        reservation.setStatus("оформлен");
        List<CopyBook> copiesBook = reservation.getEdition().getCopyBooks().stream().filter(copy ->
                copy.getStatusInThisLib().equals("в наличии")).toList();
        basketService.deleteBasketById(basketView.getId());
        if(!copiesBook.isEmpty()){
            int lenght = (copiesBook.size() < basketView.getCount())?copiesBook.size():basketView.getCount();
            for(int i=0; i<lenght; i++){
                CopyBook copyBook = copiesBook.get(i);
                copyBook.setStatusInThisLib("оформлен на бронь");
                copyBookService.save(copyBook);
                reservation.setCopyBook(copyBook);
                reservationRepository.save(reservation);
            }
            return reservation;
        }
        return new Reservation();
    }

    public Reservation makingReservList(String strIdsBasket) throws IOException {
        List<BasketView> basketViews = new ArrayList<>();
        List<Long> list = getListIds(strIdsBasket);
        for(Long id:list){
            makingReserv(basketService.getBasket(id));
        }
        return new Reservation();
    }

    private List<Long> getListIds(String ids) {
        List<Long> list = new ArrayList<>();
        List<String> arr = new ArrayList<>();
        for (String s : ids.split(", ")){
            list.add(Long.parseLong(s, 10));
        }
        return list;
    }
    // бронирование по заявке о бронировании
    public void add(Reservation reservation){
        reservation.setEdition(editionService.getEdition(reservation.getEdId()));
        reservation.setSubscription(subscriptionService.getSubscription(reservation.getSubsId()));
        reservation.setCopyBook(copyBookService.getCopyBook(reservation.getCopyId()));
        reservation.getCopyBook().setStatusInThisLib("забронирован");
        copyBookService.save(reservation.getCopyBook());
        reservation.setDateReserv(LocalDate.now());
        reservation.setStatus("бронь");
        reservationRepository.save(reservation);
    }
    // бронирование по заявке на заказ книги из другой билиотеки
    public void add(Request request){
        request.getCopyBook().setStatusInAnotherLib("забронирован");
        copyBookService.save(request.getCopyBook());
        request.setStatus("доставлен");
        requestService.save(request);

        Reservation reservation = new Reservation();
        reservation.setDateReserv(LocalDate.now());
        reservation.setDateForm(LocalDate.now());
        reservation.setEdition(request.getEdition());
        reservation.setSubscription(request.getSubscription());
        reservation.setCopyBook(request.getCopyBook());
        reservation.setStatus("бронь");
        reservationRepository.save(reservation);
    }
    // бронирование оформеленной заявки из текущей библиотеки
    public void add(Request request, CopyBook copyBook){
        copyBook.setStatusInAnotherLib("забронирован");
        copyBookService.save(copyBook);

        Reservation reservation = new Reservation();
        reservation.setDateReserv(LocalDate.now());
        reservation.setDateForm(LocalDate.now());
        reservation.setEdition(request.getEdition());
        reservation.setSubscription(request.getSubscription());
        reservation.setCopyBook(copyBook);
        reservation.setStatus("бронь");
        reservationRepository.save(reservation);
        requestService.deleteById(request.getId());
    }
    public void reservDeliveredBook(Request request){
        add(request);
        request.setStatus("доставлено");
        requestService.save(request);
    }
    // бронирование отложенной книги
    public void add(Postponed postponed, CopyBook copyBook){
        copyBook.setStatusInThisLib("забронирован");
        copyBookService.save(copyBook);
        Reservation reservation = new Reservation();
        reservation.setDateReserv(LocalDate.now());
        reservation.setDateForm(LocalDate.now());
        reservation.setEdition(postponed.getEdition());
        reservation.setSubscription(postponed.getSubscription());
        reservation.setCopyBook(copyBook);
        reservation.setStatus("бронь");
        reservationRepository.save(reservation);
        postponedService.deleteById(postponed.getId());
    }

    public List<Reservation> getAllReservationsBySubsId(long subsId) {
        List<Reservation> reservations = new ArrayList<>();
        Streamable.of(reservationRepository.findAll()).forEach(reservation ->{
            if(reservation.getSubsId() == subsId)
                reservations.add(reservation);
        });
        return reservations;
    }

    public List<Reservation> getReservsByUserEmail(Long id) {
        List<Reservation> reservations = new ArrayList<>();
        String email = userService.getUser(id).getEmail();
        Streamable.of(reservationRepository.findAll()).forEach(reservation -> {
            Subscription subscription = userService.getSubs(id, reservation.getSubscription().getLibId());
            //Reader reader = readerService.getReaderByEmail(email).stream().filter(reader1 ->
            //        reader1.getSubsId() == reservation.getSubsId()).findFirst().get();
            //if (reservation.getSubsId() == reader.getReaderId().getSubsId())
            if(subscription != null)
                reservations.add(reservation);
        });
        return reservations;
    }

    public List<Reservation> getFormedReservsByLibId(@Nullable Long libId) {
        List<Reservation> reservations = new ArrayList<>();
        Streamable.of(reservationRepository.findAll()).forEach(reservation ->{
            if((libId == null || reservation.getSubscription().getLibrary().getId() == libId) &&
                reservation.getStatus().equals("оформлен"))
                reservations.add(reservation);
        });
        return reservations;
    }

    public List<Reservation> getReadyReservsByLibId(@Nullable Long libId) {
        List<Reservation> reservations = new ArrayList<>();
        Streamable.of(reservationRepository.findAll()).forEach(reservation ->{
            if((libId == null || reservation.getSubscription().getLibrary().getId() == libId) &&
                    reservation.getStatus().equals("бронь"))
                reservations.add(reservation);
        });
        return reservations;
    }
}
