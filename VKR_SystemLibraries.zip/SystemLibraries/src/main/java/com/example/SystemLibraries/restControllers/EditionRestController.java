package com.example.SystemLibraries.restControllers;

import com.example.SystemLibraries.models.Edition;
import com.example.SystemLibraries.services.CatalogService;
import com.example.SystemLibraries.services.DescripEditionService;
import com.example.SystemLibraries.services.EditionService;
import com.example.SystemLibraries.views.CatalogView;
import com.example.SystemLibraries.views.DescripEditionView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/rest/edition")
public class EditionRestController {
    @Autowired
    public EditionService editionService;
    @Autowired
    public CatalogService catalogService;
    @Autowired
    public DescripEditionService descripEdService;
    @GetMapping(value = "/catalog/get-all")
    public List<CatalogView> getAllCatalog(){
        return catalogService.getAll();
    }
    @GetMapping(value = "/catalog/get/{edId}/{id}")
    public List<DescripEditionView> getDescripEdition(@PathVariable Long edId, @PathVariable Long id) throws IOException {
        return descripEdService.getForViewEd(edId, id);
    }
    @GetMapping(value = "/catalog/get-for-reserv/{edId}/{id}")
    public List<DescripEditionView> getEdForReserv(@PathVariable Long edId, @PathVariable Long id) throws IOException {
        return descripEdService.getForReservEd(edId, id);
    }
    @GetMapping("/catalog/get/{id}")
    public CatalogView getCatalogById(@PathVariable Long id) throws IOException {
        return catalogService.get(id);
    }
    @GetMapping("/get-all")
    public List<Edition> getAllEdition(){
        return editionService.getAllEditions();
    }
    @GetMapping("/get-all/{id}")
    public List<Edition> getAllEdition(@PathVariable Long id){
        return editionService.getEditionsByLibId(id);
    }
    @PostMapping("/save")
    public Edition save(@RequestBody Edition author){
        return editionService.save(author);
    }
    @GetMapping("/get/{id}")
    public Edition getEditionById(@PathVariable Long id){
        return editionService.getEdition(id);
    }
    @GetMapping("/catalogCards/{id}")
    public List<String> getCatalogCardsByLibId(@PathVariable Long id){
        return editionService.getCatalogCardsByLibId(id);
    }
    @DeleteMapping("/delete/{id}")
    public void delete(@PathVariable Long id){
        editionService.deleteById(id);
    }
}
