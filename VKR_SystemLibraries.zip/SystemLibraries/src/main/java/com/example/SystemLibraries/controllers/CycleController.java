package com.example.SystemLibraries.controllers;

import com.example.SystemLibraries.models.*;
import com.example.SystemLibraries.services.CycleService;
import com.example.SystemLibraries.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;

@Controller
@RequestMapping("/cycle")
public class CycleController {
    @Autowired
    private CycleService mainServer;
    @Autowired
    private UserService userService;
    private String message;
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/list")
    public String list(Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            model.addAttribute("user", user);
            List<Cycle> list = mainServer.getAllCycles();
            model.addAttribute("cycles", list);
            //model.addAttribute("user", user);
            return "cycle/list";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/details/{id}")
    public String details(Model model, @PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            model.addAttribute("user", user);
            Cycle cycle = mainServer.getCycle(id);
            model.addAttribute("cycle", cycle);
            //model.addAttribute("user", user);
            return "cycle/details";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/create")
    public String create(Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            model.addAttribute("user", user);
            model.addAttribute("cycle", new Cycle());
            //model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
            return "cycle/create";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @PostMapping("/create")
    public String create(@ModelAttribute Cycle cycle, Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        if (cycle.getName() == null || cycle.getName().trim().length() < 2){
            model.addAttribute("message", "Заполните обязательное поле: Название.");
            return "cycle/create";
        }
        if(mainServer.getByName(cycle.getName()) == null){
            mainServer.save(cycle);
            return "redirect:/cycle/list";
        }else{
            model.addAttribute("message", "Цикл с таким названием уже существует.");
            return "cycle/create";
        }
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/edit/{id}")
    public String edit(Model model, @PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            model.addAttribute("user", user);
            model.addAttribute("cycle", mainServer.getCycle(id));
            if(message != null){
                model.addAttribute("message", message);
            }
            //model.addAttribute("user", user);
            return "cycle/edit";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @PostMapping("/edit")
    public String edit(@ModelAttribute Cycle cycle, Model model, Principal principal){
        Cycle cycleCheck = mainServer.getByName(cycle.getName());
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        if (cycle.getName() == null || cycle.getName().trim().length() < 2){
            message = "Заполните обязательное поле: Название.";
            return "cycle/edit/" + cycle.getId();
        }
        if (cycleCheck != null && cycleCheck.getId() != cycle.getId()){
            model.addAttribute("cycle", cycle);
            //model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
            message = "Цикл с таким названием уже существует.";
            return "cycle/edit/" + cycle.getId();
        }else{
            mainServer.save(cycle);
            message = null;
            return "redirect:/cycle/list";
        }
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            mainServer.deleteById(id);
            return "redirect:/cycle/list";
        }else
            return "redirect:/home";
    }
}
