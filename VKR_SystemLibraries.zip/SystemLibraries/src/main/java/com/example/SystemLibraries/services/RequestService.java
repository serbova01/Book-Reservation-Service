package com.example.SystemLibraries.services;

import com.example.SystemLibraries.models.CopyBook;
import com.example.SystemLibraries.models.Reader;
import com.example.SystemLibraries.models.Request;
import com.example.SystemLibraries.repositories.RequestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.util.Streamable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class RequestService {
    @Autowired
    private RequestRepository requestRepository;
    @Autowired
    private CopyBookService copyBookService;
    @Autowired
    private EditionService editionService;
    @Autowired
    private SubscriptionService subscriptionService;
    @Autowired
    private ReaderService readerService;
    @Autowired
    private UserService userService;

    public Request save(Request request){
        request.setEdition(editionService.getEdition(request.getEdId()));
        request.setSubscription(subscriptionService.getSubscription(request.getSubsId()));
        if(request.getCopyId() != null && request.getCopyId()>0)
            request.setCopyBook(copyBookService.getCopyBook(request.getCopyId()));
        return  requestRepository.save(request);
    }
    public Request add(Request request){
        request.setEdition(editionService.getEdition(request.getEdId()));
        request.setSubscription(subscriptionService.getSubscription(request.getSubsId()));
        request.setStatus("оформлен");
        return  requestRepository.save(request);
    }
    public Request add(Long edId, Long usId, Long libId){
        Request request = new Request();
        request.setEdition(editionService.getEdition(edId));
        request.setSubscription(userService.getSubs(usId, libId));
        request.setStatus("оформлен");
        return  requestRepository.save(request);
    }
    public Request deleteById(long id){
        Request request = getRequest(id);
        if(request.getCopyBook() == null){
            requestRepository.deleteById(id);
        }else{
            if(!request.getStatus().equals("доставлен")){
                request.getCopyBook().setStatusInThisLib("доставляется");
                request.getCopyBook().setStatusInAnotherLib("возврат");
                copyBookService.save(request.getCopyBook());
                request.setStatus("на возврат");
                save(request);
            }
        }
        return new Request();
    }
    //возврат книги по заявке в свою библиотеку
    public void confimReturnBookInLib(long id){
        Request request = requestRepository.findById(id).get();
        request.getCopyBook().setStatusInThisLib("в наличии");
        request.getCopyBook().setStatusInAnotherLib(null);
        copyBookService.save(request.getCopyBook());
        requestRepository.deleteById(id);
    }
    public List<Request> getAllRequests(){
        List<Request> requests = new ArrayList<>();
        Streamable.of(requestRepository.findAll()).forEach(requests::add);
        return requests;
    }
    // заявки, оформленые через данную библиотеку
    public List<Request> getAllFormedRequestsByLibId(long libId){
        List<Request> requests = new ArrayList<>();
        Streamable.of(requestRepository.findAll()).forEach(request -> {
            if (request.getSubscription().getLibrary().getId() == libId && request.getCopyBook() == null)
                requests.add(request);
        });
        return requests;
    }
    // заявки, оформленые в других библиотеках, но экземпляры нужных книг есть в наличии в данной библиотеке
    public List<Request> getAllFormedRequestsByNoLibId(long libId){
        List<Request> requests = new ArrayList<>();
         Streamable.of(requestRepository.findAll()).forEach(request -> {
             List<CopyBook> copyBooks =
                     copyBookService.getAllCopyBooksIsAvailableByLibId(libId).stream().filter(copyBook ->
                             copyBook.getEdition().getId() == request.getEdition().getId()).toList();
            if (request.getSubscription().getLibrary().getId() != libId &&
                    request.getStatus().equals("оформлен") && copyBooks.size() > 0)
                requests.add(request);
        });
        return requests;
    }
    // заявки, доставляемые данной библиотекой
    public List<Request> getAllDeliveredRequestsByNoLibId(long libId){
        List<Request> requests = new ArrayList<>();
        Streamable.of(requestRepository.findAll()).forEach(request -> {
            if (request.getCopyBook() != null && ((request.getCopyBook().getDepartment().getLibrary().getId() == libId &&
                    request.getStatus().equals("доставляется")) ||
                    (request.getSubscription().getLibrary().getId() == libId &&
                            request.getStatus().equals("возврат"))))
                requests.add(request);
        });
        return requests;
    }
    // заявки, доставляемые или возвращаемые в данную библиотеку
    public List<Request> getAllDeliveredRequestsByLibId(long libId){
        List<Request> requests = new ArrayList<>();
        Streamable.of(requestRepository.findAll()).forEach(request -> {
            if (request.getCopyBook() != null && ((request.getSubscription().getLibrary().getId() == libId &&
                    request.getStatus().equals("доставляется")) ||
                    (request.getCopyBook().getDepartment().getLibrary().getId() == libId &&
                            request.getStatus().equals("возврат"))))
                requests.add(request);
        });
        return requests;
    }
    public Request answerToRequest(long id){
        Request request = getRequest(id);
        request.setStatus("доставляется");
        request.getCopyBook().setStatusInThisLib("оформлен для заказ");
        request.getCopyBook().setStatusInAnotherLib("доставляется");
        copyBookService.save(request.getCopyBook());
        return  requestRepository.save(request);
    }
    public Request answerToRequest(Request request){
        request.setStatus("доставляется");
        request.getCopyBook().setStatusInThisLib("оформлен для заказ");
        request.getCopyBook().setStatusInAnotherLib("доставляется");
        copyBookService.save(request.getCopyBook());
        return save(request);
    }
    public Request getRequest(long id){
        return requestRepository.findById(id).get();
    }

    public List<Request> getRequestsBySubsId(long subsId) {
        List<Request> requests = new ArrayList<>();
        Streamable.of(requestRepository.findAll()).forEach(request -> {
            if (request.getSubsId() == subsId && (request.getStatus().equals("оформлен") ||
                    request.getStatus().equals("доставляется")))
                requests.add(request);
        });
        return requests;
    }

    public List<Request> getRequestsByUserEmail(String email) {
        List<Request> requests = new ArrayList<>();
        Streamable.of(requestRepository.findAll()).forEach(request -> {
            List<Reader> readers  = readerService.getReaderByEmail(email).stream().filter(reader1 ->
                    reader1.getSubsId() == request.getSubsId() && (request.getStatus().equals("оформлен") ||
                            request.getStatus().equals("доставляется"))).toList();
            if(!readers.isEmpty())
                requests.add(request);
        });
        return requests;
    }

    public void returnBookInLib(Request request) {
        request.getCopyBook().setStatusInThisLib("доставляется");
        request.getCopyBook().setStatusInAnotherLib("возврат");
        copyBookService.save(request.getCopyBook());
        request.setStatus("возврат");
        save(request);
    }
}
