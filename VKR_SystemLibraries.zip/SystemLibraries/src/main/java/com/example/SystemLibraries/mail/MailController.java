package com.example.SystemLibraries.mail;

import com.example.SystemLibraries.models.CodeConfim;
import com.example.SystemLibraries.models.Genre;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/mail")
public class MailController {
    @Autowired
    DefaultEmailService emailService;
    @GetMapping(value = "/send-code")
    public CodeConfim sendSimpleEmail(@RequestBody CodeConfim codeConfim) {
        String code = UUID.randomUUID().toString();
        emailService.sendCode(codeConfim.getEmail());
        codeConfim.setCode(code);
        return codeConfim;
    }
}
