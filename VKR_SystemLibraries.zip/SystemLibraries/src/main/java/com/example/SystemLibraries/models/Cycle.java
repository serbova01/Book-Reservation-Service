package com.example.SystemLibraries.models;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.List;

@Entity
public class Cycle {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    @OneToMany(mappedBy = "cycle")
    @JsonIgnore
    //@JsonBackReference(value="book-cycle")
    private List<Book> books;

    @Override
    public String toString() {
        return "Cycle{" +
                "id=" + id +
                ", name='" + name +
                '}';
    }

    public String getAuthors(){
        String authorStr = "";
        if(!books.isEmpty()){
            return books.get(0).getAuthorStr();
        }
        return authorStr;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Book> getBooks() {
        return books;
    }

    public void setBooks(List<Book> books) {
        this.books = books;
    }
}
