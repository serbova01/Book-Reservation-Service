package com.example.SystemLibraries.restControllers;

import com.example.SystemLibraries.models.CopyBook;
import com.example.SystemLibraries.services.CopyBookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/rest/copyBook")
public class CopyBookRestController {
    @Autowired
    public CopyBookService copyBookService;
    @GetMapping("/get-all")
    public List<CopyBook> getAllCopyBook(){
        return copyBookService.getAllCopyBooks();
    }
    @GetMapping("/get-all/{id}")
    public List<CopyBook> getAllCopyBookIsAvailable(@PathVariable Long id){
        return copyBookService.getAllCopyBooksIsAvailableByLibId(id);
    }
    @PostMapping("/save")
    public CopyBook save(@RequestBody CopyBook copyBook){
        return copyBookService.save(copyBook);
    }
    @GetMapping("/get/{id}")
    public CopyBook getCopyBookById(@PathVariable Long id){
        return copyBookService.getCopyBook(id);
    }
    @DeleteMapping("/delete/{id}")
    public void delete(@PathVariable Long id){
        copyBookService.deleteById(id);
    }
    @GetMapping("/writeOff/{id}")
    public void writeOff(@PathVariable long id){
        copyBookService.writeOffCopyBook(id);
    }
}
