package com.example.SystemLibraries.views;

import com.example.SystemLibraries.models.Library;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import javax.persistence.*;
import lombok.Getter;
import org.hibernate.annotations.Immutable;

import java.io.IOException;
@Entity
@Table(name = "v_decrip_edition")
@Getter
@Immutable
public class DescripEditionView {
    @Id
    private Long id;
    private Long subsId;
    @ManyToOne
    @JsonManagedReference
    private Library library;
    private long count;
    private boolean reg;

    public DescripEditionView(long id, long subsId, Library library, long count, boolean reg) throws IOException {
        this.id = id;
        this.subsId = subsId;
        this.library = library;
        this.count = count;
        this.reg = reg;
    }
}
