package com.example.SystemLibraries.repositories;

import com.example.SystemLibraries.models.PublHouse;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PublHouseRepository extends JpaRepository<PublHouse, Long> {
    PublHouse findByName(String name);
}
