package com.example.SystemLibraries.services;

import com.example.SystemLibraries.models.PublHouse;
import com.example.SystemLibraries.repositories.PublHouseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.util.Streamable;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class PublHouseService {
    @Autowired
    private PublHouseRepository publHouseRepository;

    public PublHouse save(PublHouse publHouse){
        publHouse.setShortNameCity(setShortCity(publHouse.getCity()));
        return  publHouseRepository.save(publHouse);
    }
    public String setShortCity(String city) {
        return city.split("(?=[A-Z])").toString();
    }
    public void deleteById(long id){
        publHouseRepository.deleteById(id);
    }
    public List<PublHouse> getAllPublHouses(){
        List<PublHouse> publHouses = new ArrayList<>();
        Streamable.of(publHouseRepository.findAll()).forEach(publHouses::add);
        return publHouses;
    }
    public List<PublHouse> getAllPublHousesByLibId(@Nullable Long libId){
        List<PublHouse> publHouses = new ArrayList<>();
        Streamable.of(publHouseRepository.findAll()).forEach(publHouse -> {
            if (libId == null || publHouse.getEditions().stream().filter(edition ->
                    edition.getCopyBooks().stream().filter(copyBook ->
                            copyBook.getDepartment().getLibrary().getId() == libId).count()>0).count()>0)
                publHouses.add(publHouse);
        });
        return publHouses;
    }
    public PublHouse getPublHouse(long id){
        return publHouseRepository.findById(id).get();
    }

    public PublHouse getByName(String name) {
        return publHouseRepository.findByName(name);
    }
}
