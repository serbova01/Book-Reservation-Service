package com.example.SystemLibraries.controllers;

import com.example.SystemLibraries.formModels.ReaderDetails;
import com.example.SystemLibraries.models.*;
import com.example.SystemLibraries.services.LibraryService;
import com.example.SystemLibraries.services.ReaderService;
import com.example.SystemLibraries.services.SubscriptionService;
import com.example.SystemLibraries.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@Controller
@RequestMapping("/reader")
public class ReaderController {

    String[] messages = {
            "Заполните обязательные поля: Фамилия, Имя, Номер телефона (или Email), Улица, Дом.",
            "Данный электронный адрес уже используется в системе."
    };
    @Autowired
    private ReaderService readerService;
    @Autowired
    private SubscriptionService subscriptionService;
    @Autowired
    private LibraryService libraryService;
    @Autowired
    private UserService userService;
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/list")
    public String list(Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        if(user.getRole() == Role.LIB){
            List<Reader> list = readerService.getAllReadersByLibId(user.getLibId());
            model.addAttribute("readers", list);
            return "reader/list";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/create")
    public String createGet(Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        if(user.getRole() == Role.LIB){
            model.addAttribute("reader", new ReaderDetails());
            model.addAttribute("subscribers", subscriptionService.getAllSubscriptions());
            //model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
            return "reader/create";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @PostMapping("/create")
    public String createPost(@ModelAttribute ReaderDetails reader, Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        if (reader.isNullFields()){
            model.addAttribute("message", messages[0]);
            return "reader/create";
        }
        Reader newReader = reader.convertToReader(new Reader());
        newReader.getReaderId().setReader_id(readerService.getNewId());
        readerService.add(newReader);
        if(reader.isChild()){
            List<Reader> list = readerService.getAllReadersBySubsId(reader.getSubscription().getId()).stream().filter(subs ->
                    subs.getParentId() == null || subs.getParentId() > 0).toList();
            return "redirect:/reader/addParent/" + reader.getSubscription().getId() + "/" + newReader.getReaderId().getReader_id();
        }else{
            return "redirect:/subscriber/details/" + reader.getSubscription().getId();
        }

    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/create/{idSubs}")
    public String createInSubsGet(Model model, @PathVariable("idSubs") Long idSubs, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        Subscription subscription = subscriptionService.getSubscription(idSubs);
        if(user.getRole() == Role.LIB && subscription.getLibId() == user.getLibId()){
            ReaderDetails reader = new ReaderDetails();
            reader.setSubscription(subscriptionService.getSubscription(idSubs));
            model.addAttribute("reader", reader);
            //model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
            return "reader/create";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @PostMapping("/create/{idSubs}")
    public String createInSubsPost(@ModelAttribute ReaderDetails reader, @PathVariable("idSubs") Long idSubs, Model model,
                                   Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        Subscription subscription = subscriptionService.getSubscription(idSubs);
        if(user.getRole() == Role.LIB && subscription.getLibId() == user.getLibId()){
            model.addAttribute("user", user);
            if (reader.isNullFields()){
                model.addAttribute("message", messages[1]);
                return "reader/create";
            }
            if(reader.isChild()){
                List<Reader> list = readerService.getAllReadersBySubsId(idSubs).stream().filter(subs ->
                        subs.getParentId() == null || subs.getParentId() > 0).toList();
                model.addAttribute("reader", reader);
                model.addAttribute("parents", list);
                return "reader/addParent/" + idSubs + "/" + reader.getReader_id();
            }else{
                Reader newReader = reader.convertToReader(new Reader());
                readerService.save(newReader);
                model.addAttribute("subscriber", subscription);
                return "redirect:/subscriber/edit/" + idSubs;
            }
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/addParent/{idSubs}/{id}")
    public String addParentGet(Model model, @PathVariable("idSubs") Long idSubs,
                               @PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        Subscription subscription = subscriptionService.getSubscription(idSubs);
        if(user.getRole() == Role.LIB && subscription.getLibId() == user.getLibId()){
            List<Reader> readers = readerService.getAllReadersBySubsId(idSubs).stream().filter(subs ->
                    subs.getParentReader() == null).toList();
            ReaderDetails reader = new ReaderDetails(readerService.getReaderByWhileId(id,
                    subscriptionService.getSubscription(idSubs)),null);
            model.addAttribute("reader", reader);
            model.addAttribute("parents", readers);
            return "reader/addParent";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/addParent/{idSubs}/{id}/{idP}")
    public String addParentPost(@PathVariable("idSubs") Long idSubs, @PathVariable("idP") Long idP,
                                @PathVariable Long id, Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        Subscription subscription = subscriptionService.getSubscription(idSubs);
        List<Subscription> readers = readerService.getAllSubsByReaderId(idP);
        if(user.getRole() == Role.LIB && subscription.getLibId() == user.getLibId() && readers.stream().filter(subs ->
                subs.getId() == subscription.getId()).count() > 0){
            Reader newReader = readerService.getReaderByWhileId(id, subscription);
            newReader.setParentReader(readerService.getReaderByWhileId(idP, subscription));
            readerService.save(newReader);
            return "redirect:/subscriber/list";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/details/{idSubs}/{id}")
    public String details(Model model, @PathVariable Long id, @PathVariable("idSubs") Long idSub, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        Subscription subscription = subscriptionService.getSubscription(idSub);
        if((user.getRole() == Role.LIB && subscription.getLibId() == user.getLibId()) || (user.getRole() == Role.USER &&
                userService.getSubsList(user.getId()).stream().filter(subs -> subs.getId() == idSub).count()>0)){
            Reader reader=readerService.getReaderByWhileId(id, subscriptionService.getSubscription(idSub));
            if(user.getRole() == Role.LIB || reader.getEmail().equals(user.getEmail())){
                List<Subscription> subscriptions = readerService.getAllSubsByReaderId(id);
                model.addAttribute("reader", reader);
                model.addAttribute("subscribers", subscriptions);
                if(user.getRole() == Role.USER){
                    List<Subscription> list = userService.getSubsList(user.getId());
                    model.addAttribute("user_subsList", list);
                }
                return "reader/details";
            }
        }
        return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/create-subs/{idSubs}/{id}")
    public String changeSubs(Model model, @PathVariable Long id, @PathVariable("idSubs") Long idSub, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        Subscription subscription = subscriptionService.getSubscription(idSub);
        if(user.getRole() == Role.LIB && subscription.getLibId() == user.getLibId()){
            Reader reader=readerService.getReaderByWhileId(id, subscriptionService.getSubscription(idSub));
            Subscription newSubs = new Subscription();
            subscription.setLibrary(libraryService.getLibrary(user.getLibId()));
            reader = readerService.changeNewSubsByReader(reader, newSubs);
            model.addAttribute("reader", reader);
            return "redirect:/subscriber/details/" + reader.getSubsId();
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB') || hasAuthority('USER')")
    @GetMapping("/edit/{idSubs}/{id}")
    public String edit(Model model, @PathVariable Long id, @PathVariable("idSubs") Long idSub, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        Subscription subscription = subscriptionService.getSubscription(idSub);
        if((user.getRole() == Role.LIB && subscription.getLibId() == user.getLibId()) || (user.getRole() == Role.USER &&
                userService.getReadersById(user.getId()).stream().filter(reader ->
                        reader.getReaderId().getReader_id() == id).count()>0)){
            Reader reader = readerService.getReaderByWhileId(id, subscription);
            Boolean flag = reader.getParentReader() == null && reader.getChildsReader().size() == 0;
            model.addAttribute("reader", new ReaderDetails(reader, null));
            model.addAttribute("flag", flag);
            if(user.getRole() == Role.USER){
                List<Subscription> subscriptions = userService.getSubsList(user.getId());
                model.addAttribute("user_subsList", subscriptions);
            }
            //model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
            return "reader/edit";
        }else{
            return "redirect:/home";
        }
    }
    @PreAuthorize("hasAuthority('LIB') || hasAuthority('USER')")
    @PostMapping("/edit")
    public String edit(@ModelAttribute ReaderDetails readerDetails, Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        if (readerDetails.isNullFields()){
            model.addAttribute("message", messages[0]);
            model.addAttribute("reader", readerDetails);
            return "reader/edit";
        }
        Reader reader = readerService.getReaderByWhileId(readerDetails.getReader_id(), readerDetails.getSubscription());
        if(!reader.getEmail().equals(readerDetails.getEmail()) && (userService.getByEmail(readerDetails.getEmail()) != null
            || readerService.getReaderByEmail(readerDetails.getEmail()) != null)){
            model.addAttribute("message", messages[1]);
            model.addAttribute("reader", readerDetails);
            return "reader/edit";
        }
        reader = readerDetails.convertToReader(reader);
        readerService.save(reader);
        if(user.getRole() == Role.LIB)
            return "redirect:/subscriber/details/" + readerDetails.getSubscription().getId();
        else{
            return "redirect:/user/subscription/" + readerDetails.getSubscription().getId();
        }
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/delete-all/{id}")
    public String deleteAllById(@PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            readerService.deleteAllById(id);
            return "redirect:/reader/list";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/delete/{idSubs}/{id}")
    public String delete(@PathVariable Long id, @PathVariable("idSubs") Long idSub, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        Subscription subscription = subscriptionService.getSubscription(idSub);
        if(user.getRole() == Role.LIB && subscription.getLibId() == user.getLibId()){
            readerService.deleteByReaderId(id, idSub);
            return "redirect:/subscriber/list";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/chooseReaderAnotherLib/{idSubs}")
    public String listAllReader(Model model, @PathVariable("idSubs") Long idSub, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        Subscription subscription = subscriptionService.getSubscription(idSub);
        if(user.getRole() == Role.LIB && subscription.getLibId() == user.getLibId()){
            model.addAttribute("user", user);
            List<Reader> readers = readerService.getAllReaders().stream().filter(reader ->
                    reader.getReaderId().getSubscription().getLibrary().getId() != subscription.getLibrary().getId()).toList();
            HashMap<Library, List<Reader>> map = new HashMap<>();
            for(Reader reader : readers){
                List<Reader> list;
                if (map.containsKey(reader.getReaderId().getSubscription().getLibrary())){
                    list = map.get(reader.getReaderId().getSubscription().getLibrary());
                }else{
                    list =  new ArrayList<Reader>();
                }
                list.add(reader);
                map.put(reader.getReaderId().getSubscription().getLibrary(), list);
            }
            model.addAttribute("subscriber", subscriptionService.getSubscription(idSub));
            model.addAttribute("maps", map);
            //model.addAttribute("user", user);
            return "reader/chooseReaderAnotherLib";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/chooseReaderAnotherLib/{idSubs}/{idAnSubs}/{id}")
    public String createReaderAnotherLib(Model model, @PathVariable("idSubs") Long idSub,
                                         @PathVariable("idAnSubs") Long idAnSubs, @PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        Subscription subscription = subscriptionService.getSubscription(idSub);
        if(user.getRole() == Role.LIB && subscription.getLibId() == user.getLibId()){
            model.addAttribute("user", user);
            Subscription anSubs = subscriptionService.getSubscription(idAnSubs);
            Reader reader = readerService.getReaderByWhileId(id, anSubs);
            reader.getReaderId().setSubscription(subscriptionService.getSubscription(idSub));
            reader.setSubsId(idSub);
            reader = readerService.add(reader);
            return "redirect:/reader/details/" + idSub + "/" + id;
        }else
            return "redirect:/home";
    }
}
