package com.example.SystemLibraries.controllers;

import com.example.SystemLibraries.formModels.CopyBookEdit;
import com.example.SystemLibraries.formModels.EditionInLib;
import com.example.SystemLibraries.models.*;
import com.example.SystemLibraries.services.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;

@Controller
@RequestMapping("/postponed")
public class PostponedController {
    @Autowired
    private PostponedService postponedService;
    @Autowired
    private SubscriptionService subscriptionService;
    @Autowired
    private EditionService editionService;
    @Autowired
    private HistoryReaderService historyReaderService;
    @Autowired
    private CopyBookService copyBookService;
    @Autowired
    private ReservationService reservationService;
    @Autowired
    private UserService userService;
    private String[] message = {
            "Этому Абонементу такая книга уже отложена.",
            "Выберете абонемент и книгу."
    };

    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/list")
    public String list(Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            model.addAttribute("user", user);
            List<Postponed> list = postponedService.getAllPostponedsByLibId(user.getLibId());
            model.addAttribute("postponeds", list);
            //model.addAttribute("user", user);
            return "postponed/list";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/chooseCopyBook/{id}")
    public String chooseCopyBook(Model model, @PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            model.addAttribute("user", user);
            Postponed postponed = postponedService.getPostponed(id);
            List<CopyBook> copies = copyBookService.getAllCopyBooksIsAvailableByLibId(user.getLibId()).stream()
                    .filter(cb -> cb.getEdition().getId() == postponed.getEdId()).toList();
            model.addAttribute("postponed", postponed);
            model.addAttribute("edition", new EditionInLib(postponed.getEdition(),
                    postponed.getSubscription().getLibrary().getId()));
            model.addAttribute("copies", copies);
            //model.addAttribute("user", bookService.findUserByLogin(principal.getName()));
            return "postponed/chooseCopyBook";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/issuedCopyBook/{idPost}/{idCB}")
    public String issuedCopyBook(Model model, @PathVariable("idPost") Long idPost, @PathVariable("idCB") Long idCB, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            model.addAttribute("user", user);
            Postponed postponed = postponedService.getPostponed(idPost);
            HistoryReader historyReader = new HistoryReader();
            historyReader.setSubscription(postponed.getSubscription());
            historyReader.setCopyId(idCB);
            historyReaderService.add(historyReader);
            postponedService.deleteById(postponed.getId());
            return "redirect:/postponed/list";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/reservCopyBook/{idPost}/{idCB}")
    public String reservCopyBook(Model model, @PathVariable("idPost") Long idPost, @PathVariable("idCB") Long idCB, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            model.addAttribute("user", user);
            Postponed postponed = postponedService.getPostponed(idPost);
            CopyBook copyBook = copyBookService.getCopyBook(idCB);
            reservationService.add(postponed, copyBook);
            return "redirect:/postponed/list";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @RequestMapping(path = {"/create", "/create/search"})
    public String create(Model model, Principal principal, String keyword){
        User user =  userService.getUserByUsername(principal.getName());
        List<Edition> editions;
        if(keyword!=null && keyword.length() >= 1 && Character.isLetterOrDigit(keyword.toCharArray()[0])) {
            editions = editionService.getByKeyword(keyword).stream().filter(edition ->
                    edition.getCopyBooks().stream().filter(copyBook ->
                            copyBook.getDepartment().getLibrary().getId() == user.getLibId()).count()>0).toList();
        }else
            editions = editionService.getEditionsByLibId(user.getLibId());
        model.addAttribute("user", user);
        model.addAttribute("postponed", new Postponed());
        model.addAttribute("subscribers", subscriptionService.getAllSubscriptionsByLibId(user.getLibId()));
        model.addAttribute("editions", editions);
        model.addAttribute("keyword", keyword);
        //model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
        return "postponed/create";
    }
    @GetMapping("/chooseEd/{id}")
    public String create(Model model, @PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            model.addAttribute("user", user);
            //User user =  copyBookService.findUserByLogin(principal.getName());
            List<Edition> editions = editionService.getEditionsByLibId(user.getLibId());
            Edition edition = editionService.getEdition(id);
            editions.remove(edition);
            Postponed postponed = new Postponed();
            postponed.setEdition(edition);
            model.addAttribute("editions", editions);
            model.addAttribute("postponed", postponed);
            model.addAttribute("subscribers", subscriptionService.getAllSubscriptionsByLibId(user.getLibId()));
            //model.addAttribute("user", user);
            return "postponed/create";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @PostMapping("/create")
    public String create(@ModelAttribute Postponed postponed, Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        model.addAttribute("postponed", postponed);
        model.addAttribute("subscribers", subscriptionService.getAllSubscriptionsByLibId(user.getLibId()));
        model.addAttribute("editions", editionService.getEditionsByLibId(user.getLibId()));
        if(postponed.getSubscription() == null || postponed.getEdition() == null){
            model.addAttribute("message", message[1]);
            return "postponed/create";
        }else{
            if(postponedService.getByEditionSubs(postponed) != null){
                model.addAttribute("message", message[0]);
                return "postponed/create";
            }else{
                postponedService.save(postponed);
                return "redirect:/postponed/list";
            }
        }
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/add/{idSubs}/{idEd}")
    public String create(Model model, @PathVariable("idSubs") Long idSubs, @PathVariable("idEd") Long idEd, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            Postponed postponed = new Postponed();
            postponed.setSubscription(subscriptionService.getSubscription(idSubs));
            postponed.setEdition(editionService.getEdition(idEd));
            postponedService.save(postponed);
            return "redirect:/subscriber/issueBook/" + idSubs;
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            postponedService.deleteById(id);
            return "redirect:/postponed/list";
        }else
            return "redirect:/home";
    }
}
