package com.example.SystemLibraries.controllers;

import com.example.SystemLibraries.models.*;
import com.example.SystemLibraries.services.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/reservation")
public class ReservationController {
    @Autowired
    private ReservationService reservationService;
    @Autowired
    private SubscriptionService subscriptionService;
    @Autowired
    private EditionService editionService;
    @Autowired
    private CopyBookService copyBookService;
    @Autowired
    private UserService userService;
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/formedList")
    public String formedList(Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        List<Reservation> list = reservationService.getFormedReservsByLibId(user.getLibId());
        model.addAttribute("reservations", list);
        //model.addAttribute("user", user);
        return "reservation/formedList";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/readyList")
    public String readyList(Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        List<Reservation> list = reservationService.getReadyReservsByLibId(user.getLibId());
        model.addAttribute("reservations", list);
        //model.addAttribute("user", user);
        return "reservation/readyList";
    }
    @PreAuthorize("hasAuthority('LIB')")
    //@GetMapping("/create")
    @RequestMapping(path = {"/create", "/create/search"})
    public String makingReserv(Model model, Principal principal, String keyword){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);

        List<CopyBook> copyBooks = new ArrayList<>();
        List<Edition> editions = new ArrayList<>();
        if(keyword!=null && keyword.length() >= 1 && Character.isLetterOrDigit(keyword.toCharArray()[0])) {
            editions = editionService.getByKeyword(keyword);
        }else
            editions = editionService.getEditionsByLibId(user.getLibId());
        for (CopyBook copyBook : copyBookService.getAllCopyBooksIsAvailableByLibId(user.getLibId())){
            if(editions.stream().filter(edition -> edition.getId() == copyBook.getEdition().getId()).count()>0)
                copyBooks.add(copyBook);
        }

        List<Subscription> subscriptions = subscriptionService.getAllSubscriptionsByLibId(user.getLibId());
        Reservation reservation = new Reservation();
        reservation.setSubscription(subscriptions.get(0));
        model.addAttribute("keyword", keyword);
        model.addAttribute("reservation", reservation);
        model.addAttribute("subscribers", subscriptions);
        model.addAttribute("copyBooks", copyBooks);
        //model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
        return "reservation/create";
        //Библиотекарь
        //return "redirect:/subscriber/list";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/create/{cbId}/{subsId}")
    public String makingReserv(@PathVariable("cbId") Long cbId, @PathVariable("subsId") Long subsId, Model model,
                               Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);

        CopyBook copyBook = copyBookService.getCopyBook(cbId);
        Reservation reservation = new Reservation();
        reservation.setSubscription(subscriptionService.getSubscription(subsId));
        reservation.setCopyBook(copyBook);
        reservation.setEdition(copyBook.getEdition());

        List<CopyBook> copyBooks = copyBookService.getAllCopyBooksIsAvailableByLibId(user.getLibId());
        copyBooks.remove(copyBook);
        model.addAttribute("reservation", reservation);
        model.addAttribute("subscribers", subscriptionService.getAllSubscriptionsByLibId(user.getLibId()));
        model.addAttribute("copyBooks", copyBooks);

        return "reservation/create";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @PostMapping("/create")
    public String makingReserv(@ModelAttribute Reservation reservation, Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(reservation.getCopyBook() != null){
            reservation.setEdition(reservation.getCopyBook().getEdition());
            reservation.setDateForm(LocalDate.now());
            model.addAttribute("user", user);
            reservationService.add(reservation);
            return "redirect:/reservation/readyList";
        }else
            return "redirect:/reservation/create";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/details/{id}")
    public String details(@PathVariable Long id, Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        Reservation reservation = reservationService.getReservation(id);
        model.addAttribute("user", user);
        model.addAttribute("reservation", reservation);
        return "reservation/details";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/editCopyBook/{id}")
    public String chooseCopyBook(Model model, @PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        Reservation reservation = reservationService.getReservation(id);
        List<CopyBook> copyBooks = copyBookService.getAllCopyBooksIsAvailableByLibId(user.getLibId()).stream()
                .filter(copyBook -> copyBook.getEdition().getId() == reservation.getEdition().getId()).toList();
        model.addAttribute("reservation", reservation);
        model.addAttribute("copyBooks", copyBooks);
        model.addAttribute("depStr", copyBooks.get(0).getDepartment().getDepStr());
        return "reservation/editCopyBook";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/chooseCopyBook/{reqId}/{cbId}")
    public String chooseCopyBook(Model model, @PathVariable("reqId") Long reqId,
                                 @PathVariable("cbId") Long cbId, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        Reservation reservation = reservationService.getReservation(reqId);
        CopyBook copyBook = copyBookService.getCopyBook(cbId);

        String status = reservation.getCopyBook().getStatusInThisLib();
        reservation.getCopyBook().setStatusInThisLib("в наличии");
        copyBookService.save(reservation.getCopyBook());

        reservation.setCopyId(cbId);
        reservation.setCopyBook(copyBook);
        copyBook.setStatusInThisLib(status);
        copyBookService.save(copyBook);
        reservationService.save(reservation);
        return "redirect:/reservation/details/" + reservation.getId();
    }

    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/edit/{id}")
    public String edit(Model model, @PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        Reservation reservation = reservationService.getReservation(id);
        if(reservation.getSubscription().getLibrary().getId() == user.getLibId()){
            List<CopyBook> copyBooks = copyBookService.getAllCopyBooksIsAvailableByLibId(user.getLibId());
            model.addAttribute("reservation", reservation);
            model.addAttribute("copyBooks", copyBooks);
            //model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
            return "reservation/edit";
        }else return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @PostMapping("/edit")
    public String edit(@ModelAttribute Reservation reservation, Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        reservationService.save(reservation);
        return "redirect:/reservation/details/" + reservation.getId();
    }
    @PreAuthorize("hasAuthority('USER') || hasAuthority('LIB')")
    @GetMapping("/deleteForm/{id}")
    public String deleteForm(Model model, @PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        reservationService.deleteById(id);
        if(user.getRole() == Role.LIB)
            return "redirect:/reservation/formedList";
        else
            return "redirect:/user/formedList";
    }
    @PreAuthorize("hasAuthority('USER') || hasAuthority('LIB')")
    @GetMapping("/deleteReserv/{id}")
    public String deleteReserv(Model model, @PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        reservationService.deleteById(id);
        if(user.getRole() == Role.LIB)
            return "redirect:/reservation/readyList";
        else
            return "redirect:/user/readyList";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/add/{id}")
    public String reservAdd(Model model, @PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        reservationService.add(reservationService.getReservation(id));
        return "redirect:/reservation/formedList";
    }
}
