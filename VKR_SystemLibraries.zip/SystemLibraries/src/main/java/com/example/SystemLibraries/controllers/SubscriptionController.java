package com.example.SystemLibraries.controllers;

import com.example.SystemLibraries.formModels.EditionInLib;
import com.example.SystemLibraries.formModels.HRDetails;
import com.example.SystemLibraries.formModels.ReaderDetails;
import com.example.SystemLibraries.models.*;
import com.example.SystemLibraries.services.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.security.Principal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/subscriber")
public class SubscriptionController {

    String[] message ={
            "Актуальный номер должен быть отличен от 0.",
            "Данный номер занят другим абонементом."
    };
    @Autowired
    private SubscriptionService subscriptionService;
    @Autowired
    private LibraryService libraryService;
    @Autowired
    private EditionService editionService;
    @Autowired
    private HistoryReaderService historyReaderService;
    @Autowired
    private ReservationService reservationService;
    @Autowired
    private CopyBookService copyBookService;
    @Autowired
    private UserService userService;
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/list")
    public String list(Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            model.addAttribute("user", user);
            List<Subscription> list = subscriptionService.getAllSubscriptionsByLibId(user.getLibId());
            model.addAttribute("subscribers", list);
            //model.addAttribute("user", user);
            return "subscriber/list";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/create")
    public String createGet(Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            Subscription subscription = new Subscription();
            subscription.setLibrary(user.getLibrary());
            subscriptionService.add(subscription);
            return "redirect:/subscriber/list";
        }else
            return "redirect:/home";
    }
    /*@PreAuthorize("hasAuthority('LIB')")
    @PostMapping("/create")
    public String create(@ModelAttribute Subscription subscription, Model model){
        subscriptionService.add(subscription);
        return "redirect:/subscriber/list";
    }*/
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/details/{id}")
    public String details(Model model, @PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        Subscription subscription = subscriptionService.getSubscription(id);
        if(user.getRole() == Role.LIB && subscription.getLibId() == user.getLibId()){
            model.addAttribute("user", user);
            List<HRDetails> hrs = new ArrayList<>();
            List<ReaderDetails> readers = new ArrayList<>();
            subscription.getHistoryReaders().forEach(hr->hrs.add(new HRDetails(hr)));
            subscription.getReaders().forEach(reader->
                    readers.add(new ReaderDetails(reader, userService.getByEmail(reader.getEmail()))));
            List<Reservation> reservations = subscription.getReservations().stream().filter(reserv ->
                    reserv.getStatus().equals("бронь")).toList();
            model.addAttribute("subscriber", subscription);
            model.addAttribute("reservations", reservations);
            model.addAttribute("histories", hrs);
            model.addAttribute("readers", readers);
            return "subscriber/details";
        }else
            return "redirect:/home";

    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/edit/{id}")
    public String edit(Model model, @PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        Subscription subscription = subscriptionService.getSubscription(id);
        if(user.getRole() == Role.LIB && subscription.getLibId() == user.getLibId()){
            model.addAttribute("user", user);
            model.addAttribute("subscriber", subscription);
            //model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
            return "subscriber/edit";
        }else{
            return "redirect:/home";
        }

    }
    @PreAuthorize("hasAuthority('LIB')")
    @PostMapping("/edit")
    public String edit(@ModelAttribute Subscription subscription, Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        if (subscription.getActualNumber() == 0){
            model.addAttribute("message", message[0]);
            return "subscriber/edit";
        }
        Subscription checkSubs = subscriptionService.getByActualNumber(subscription);
        if(checkSubs!= null){
            model.addAttribute("message", message[1]);
            return "subscriber/edit";
        }
        subscriptionService.save(subscription);
        return "redirect:/subscriber/list";
    }
    @GetMapping("/delete/{id}")
    public String deleteById(@PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        Subscription subscription = subscriptionService.getSubscription(id);
        if(user.getRole() == Role.LIB && subscription.getLibId() == user.getLibId()){
            subscriptionService.deleteById(id);
            return "redirect:/subscriber/list";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    //@GetMapping("/issueBook/{idSubs}")
    @RequestMapping(path = {"/issueBook/{idSubs}","/issueBook/{idSubs}/search"})
    public String issuedBook(Model model, @PathVariable("idSubs") Long id, Principal principal, String keyword){
        User user =  userService.getUserByUsername(principal.getName());
        Subscription subscription = subscriptionService.getSubscription(id);
        if(user.getRole() == Role.LIB && subscription.getLibId() == user.getLibId()){
            model.addAttribute("user", user);
            List<Edition> editions = new ArrayList<>();
            if(keyword!=null && keyword.length() >= 1 && Character.isLetterOrDigit(keyword.toCharArray()[0])) {
                editions = editionService.getByKeyword(keyword);
                editions = editions.stream().filter(edition -> edition.getCopyBooks().stream()
                        .filter(copyBook -> copyBook.getStatusInThisLib().equals("в наличии") &&
                                copyBook.getDepartment().getLibrary().getId() == subscription.getLibrary().getId())
                        .count() > 0).toList();
            }else
                editions = editionService.getEditionsByLibId(subscription.getLibrary().getId())
                    .stream().filter(edition -> edition.getCopyBooks().stream().filter(copyBook ->
                                    copyBook.getDepartment().getLibrary().getId() == subscription.getLibrary().getId())
                            .count()>0).toList();
            List<EditionInLib> list = new ArrayList<>();
            for(Edition edition : editions){
                list.add(new EditionInLib(edition, subscription.getLibrary().getId()));
            }
            model.addAttribute("keyword", keyword);
            model.addAttribute("subscriber", subscription);
            model.addAttribute("editions", list);
            return "subscriber/issueBook";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/chooseCopyBook/{idSubs}/{idEd}")
    public String chooseCopyBook(Model model, @PathVariable("idSubs") Long idSubs, @PathVariable("idEd") Long idEd,
                                 Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        Subscription subscription = subscriptionService.getSubscription(idSubs);
        if(user.getRole() == Role.LIB && subscription.getLibId() == user.getLibId()){
            model.addAttribute("user", user);
            Edition edition = editionService.getEdition(idEd);
            List<CopyBook> copies = edition.getCopyBooks().stream().filter(cb->
                    cb.getStatusInThisLib().equals("в наличии")).toList();
            model.addAttribute("subscriber", subscription);
            model.addAttribute("edition", new EditionInLib(edition, subscription.getLibrary().getId()));
            model.addAttribute("copies", copies);
            //model.addAttribute("user", bookService.findUserByLogin(principal.getName()));
            return "subscriber/chooseCopyBook";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/issuedCopyBook/{idSubs}/{idCB}")
    public String issuedCopyBook(Model model, @PathVariable("idSubs") Long idSubs, @PathVariable("idCB") Long idCB, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        Subscription subscription = subscriptionService.getSubscription(idSubs);
        CopyBook copyBook = copyBookService.getCopyBook(idCB);
        if(user.getRole() == Role.LIB && subscription.getLibId() == user.getLibId() &&
                copyBook.getDepartment().getLibId() == user.getLibId()){
            model.addAttribute("user", user);
            HistoryReader historyReader = new HistoryReader();
            historyReader.setSubsId(idSubs);
            historyReader.setCopyId(idCB);
            historyReader.setCopyBook(copyBook);
            historyReaderService.add(historyReader);
            return "redirect:/subscriber/issueBook/" + idSubs;
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB') || hasAuthority('USER')")
    @GetMapping("/prolongBook/{idSubs}/{idHR}")
    public String prolongBook(Model model, @PathVariable("idSubs") Long idSubs, @PathVariable("idHR") Long idHR,
                              Principal principal) throws IOException {
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        Subscription subscription = subscriptionService.getSubscription(idSubs);
        HistoryReader historyReader = historyReaderService.getHistoryReader(idHR);
        if((user.getRole() == Role.LIB && subscription.getLibId() == user.getLibId() &&
                historyReader.getSubsId() == subscription.getId()) || (user.getRole() == Role.USER &&
                userService.getSubsList(user.getId()).stream().filter(subs -> subs.getId() == idSubs).count()>0)){
            historyReaderService.prolongHR(idHR);
            if(user.getRole() == Role.LIB)
                return "redirect:/subscriber/details/" + idSubs;
            else
                return "redirect:/user/subscription/" + idSubs;
        }else {
            return "redirect:/home";
        }
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/returnedBook/{idHR}")
    public String returnedBook( @PathVariable("idHR") Long idHR, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        HistoryReader hr = historyReaderService.getHistoryReader(idHR);
        if(user.getRole() == Role.LIB && hr.getSubscription().getLibId() == user.getLibId()){
            historyReaderService.returnedBook(idHR);
            return "redirect:/subscriber/details/" + hr.getSubscription().getId();
        }else return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/deleteReserv/{idSubs}/{idR}")
    public String deleteReserv(@PathVariable("idSubs") Long idSubs, @PathVariable("idR") Long idR, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        Subscription subscription = subscriptionService.getSubscription(idSubs);
        Reservation reservation = reservationService.getReservation(idR);
        if(user.getRole() == Role.LIB && subscription.getLibId() == user.getLibId() &&
                reservation.getSubscription().getId() == subscription.getId()){
            reservationService.deleteById(idR);
            return "redirect:/subscriber/details/" + idSubs;
        }else return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/issueReserv/{idSubs}/{idR}")
    public String issueReserv(@PathVariable("idSubs") Long idSubs, @PathVariable("idR") Long idR, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        Subscription subscription = subscriptionService.getSubscription(idSubs);
        Reservation reservation = reservationService.getReservation(idR);
        if(user.getRole() == Role.LIB && subscription.getLibId() == user.getLibId() &&
                reservation.getSubscription().getId() == subscription.getId()){
            historyReaderService.add(reservationService.getReservation(idR));
            return "redirect:/subscriber/details/" + idSubs;
        }else return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/reservBook/{idSubs}/{idEd}")
    public String reservBook(@PathVariable("idSubs") Long idSubs, @PathVariable("idEd") Long idEd, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        Subscription subscription = subscriptionService.getSubscription(idSubs);
        if(user.getRole() == Role.LIB && subscription.getLibId() == user.getLibId()){
            Reservation reservation = new Reservation();
            reservation.setSubscription(subscription);
            Edition edition = editionService.getEdition(idEd);
            reservation.setEdition(edition);
            reservation.setCopyBook(edition.getAvailableInLibCopies(subscription.getLibrary().getId()).get(0));
            reservation.setDateForm(LocalDate.now());
            reservationService.add(reservation);
            return "redirect:/subscriber/issueBook/" + idSubs;
        }else return "redirect:/home";
    }
}
