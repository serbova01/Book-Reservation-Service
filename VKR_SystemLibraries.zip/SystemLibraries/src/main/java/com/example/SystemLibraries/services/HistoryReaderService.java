package com.example.SystemLibraries.services;


import com.example.SystemLibraries.models.*;
import com.example.SystemLibraries.repositories.HistoryReaderRepository;
import com.example.SystemLibraries.views.IssuedHRView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.util.Streamable;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Service
public class HistoryReaderService {
    @Autowired
    private HistoryReaderRepository historyReaderRepository;
    @Autowired
    private CopyBookService copyBookService;
    @Autowired
    private ReservationService reservationService;
    @Autowired
    private PostponedService postponedService;
    @Autowired
    private RequestService requestService;
    @Autowired
    private ReaderService readerService;
    @Autowired
    private SubscriptionService subscriptionService;

    public HistoryReader save(HistoryReader historyReader){
        historyReader.setCopyBook(copyBookService.getCopyBook(historyReader.getCopyId()));
        historyReader.setSubscription(subscriptionService.getSubscription(historyReader.getSubsId()));
        if(historyReader.isRelevance() && historyReader.getCopyBook().getStatusInThisLib().equals("в наличии")){
            historyReader.getCopyBook().setStatusInThisLib("выдан");
            CopyBook copyBook = copyBookService.getCopyBook(getHistoryReader(historyReader.getId()).getCopyBook().getId());
            copyBook.setStatusInThisLib("в наличии");
            copyBookService.save(historyReader.getCopyBook());
            copyBookService.save(copyBook);
        }else {
            if(historyReader.getCopyBook().getStatusInThisLib().equals("выдан")){
                historyReader.getCopyBook().setStatusInThisLib("в наличии");
                copyBookService.save(historyReader.getCopyBook());
            }
        }
        return  historyReaderRepository.save(historyReader);
    }
    public void deleteById(long id){
        historyReaderRepository.deleteById(id);
    }
    public List<HistoryReader> getAllHistoryReaders(){
        List<HistoryReader> historyReaders = new ArrayList<>();
        Streamable.of(historyReaderRepository.findAll()).forEach(historyReaders::add);
        return historyReaders;
    }
    public List<HistoryReader> getAllHistoryReadersByLibId(@Nullable Long libId){
        List<HistoryReader> historyReaders = new ArrayList<>();
        Streamable.of(historyReaderRepository.findAll()).forEach(historyReader -> {
            if( libId == null || historyReader.getSubscription().getLibrary().getId() == libId)
                historyReaders.add(historyReader);
        });
        return historyReaders;
    }
    public HistoryReader getHistoryReader(long id){
        return historyReaderRepository.findById(id).get();
    }
    public HistoryReader returnedBook(long id){
        HistoryReader historyReader = historyReaderRepository.findById(id).get();
        long libId = historyReader.getSubscription().getLibrary().getId();
        historyReader.setRelevance(false);
        if (historyReader.getSubscription().getLibrary().getId() ==
                historyReader.getCopyBook().getDepartment().getLibrary().getId()){
            // возврат книги из библиотеки абонемента
            historyReader.getCopyBook().setStatusInThisLib("в наличии");
            List<Postponed> postponeds = postponedService.getAllPostponedsByLibId(libId).stream().filter(p ->
                    p.getEdition().getId() == historyReader.getCopyBook().getEdition().getId()).toList();
            if (postponeds.size()>0){
                Postponed postponed = postponeds.get(0);
                if (postponed != null){
                    reservationService.add(postponed, historyReader.getCopyBook());
                    postponedService.deleteById(postponed.getId());
                }
            }
            else{
                List<Request> requests = requestService.getAllFormedRequestsByLibId(libId).stream().filter(r ->
                        r.getEdition().getId() == historyReader.getCopyBook().getEdition().getId()).toList();
                if (requests.size() > 0){
                    Request request = requests.get(0);
                    if(request != null){
                        request.setCopyBook(historyReader.getCopyBook());
                        reservationService.add(request);
                        requestService.deleteById(request.getId());
                    }
                }else
                    copyBookService.save(historyReader.getCopyBook());
            }
        }else{
            // возврат книги из другой библиотеки
            Request request = requestService.getAllRequests().stream().filter(req ->
                    req.getCopyBook().getId() == historyReader.getCopyBook().getId()).findFirst().get();
            requestService.returnBookInLib(request);
        }
        //изменение количества выданных книг
        Subscription subscription = subscriptionService.getSubscription(historyReader.getSubsId());
        subscription.setCur_count_issueds(getAllIssuedHRBySubsId(historyReader.getSubsId()).size());
        subscriptionService.save(subscription);
        return historyReaderRepository.save(historyReader);
    }

    public HistoryReader add(HistoryReader historyReader){
        historyReader.setRelevance(true);
        historyReader.setDateIssue(LocalDate.now());
        historyReader.setDateReturn(LocalDate.now().plusMonths(1));
        historyReader.setCopyBook(copyBookService.getCopyBook(historyReader.getCopyId()));
        historyReader.getCopyBook().setStatusInThisLib("выдан");
        copyBookService.save(historyReader.getCopyBook());
        //изменение количества выданных книг
        historyReader.setSubscription(subscriptionService.getSubscription(historyReader.getSubsId()));
        Subscription subscription = subscriptionService.getSubscription(historyReader.getSubsId());
        subscription.setCur_count_issueds(getAllIssuedHRBySubsId(historyReader.getSubsId()).size());
        subscriptionService.save(subscription);
        return historyReaderRepository.save(historyReader);
    }

    public HistoryReader add(Reservation reservation){
        HistoryReader historyReader = new HistoryReader();
        historyReader.setRelevance(true);
        historyReader.setDateIssue(LocalDate.now());
        historyReader.setDateReturn(LocalDate.now().plusMonths(1));
        historyReader.setCopyBook(reservation.getCopyBook());
        if(reservation.getSubscription().getLibrary().getId() ==
                reservation.getCopyBook().getDepartment().getLibrary().getId()){
            historyReader.getCopyBook().setStatusInThisLib("выдан");
        }else{
            historyReader.getCopyBook().setStatusInAnotherLib("выдан");
        }
        copyBookService.save(historyReader.getCopyBook());
        //изменение количества выданных книг
        historyReader.setSubscription(reservation.getSubscription());
        reservationService.deleteById(reservation.getId());
        return historyReaderRepository.save(historyReader);
    }
    public HistoryReader add(Request request, CopyBook copyBook){
        copyBook.setStatusInThisLib("выдана");
        copyBookService.save(copyBook);
        HistoryReader historyReader = new HistoryReader();
        historyReader.setRelevance(true);
        historyReader.setDateIssue(LocalDate.now());
        historyReader.setDateReturn(LocalDate.now().plusMonths(1));
        historyReader.setCopyBook(copyBook);
        //изменение количества выданных книг
        historyReader.setSubscription(request.getSubscription());
        requestService.deleteById(request.getId());
        return historyReaderRepository.save(historyReader);
    }
    public List<HistoryReader> getAllHistoryReaderBySubsId(Long id) {
        List<HistoryReader> historyReaders = new ArrayList<>();
        Streamable.of(historyReaderRepository.findAll()).forEach(historyReader -> {
            if(historyReader.getSubscription().getId() == id)
                historyReaders.add(historyReader);
        });
        return historyReaders;
    }
    public List<IssuedHRView> getAllNoIssuedHRBySubsId(Long id) {
        List<IssuedHRView> historyReaders = new ArrayList<>();
        Streamable.of(historyReaderRepository.findAll()).forEach(historyReader -> {
            if(historyReader.getSubscription().getId() == id &&
                    (!historyReader.getCopyBook().getStatusInThisLib().equals("выдан") &&
                            (historyReader.getCopyBook().getStatusInAnotherLib() == null||
                            !historyReader.getCopyBook().getStatusInAnotherLib().equals("выдан")))) {
                try {
                    historyReaders.add(new IssuedHRView(historyReader, "hr"));
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        });
        return historyReaders;
    }
    public List<HistoryReader> getAllIssuedHRBySubsId(Long id) {
        List<HistoryReader> historyReaders = new ArrayList<>();
        Streamable.of(historyReaderRepository.findAll()).forEach(historyReader -> {
            if(historyReader.getSubscription().getId() == id &&
                    (historyReader.getCopyBook().getStatusInThisLib().equals("выдан") ||
                            (historyReader.getCopyBook().getStatusInAnotherLib() == null ||
                            historyReader.getCopyBook().getStatusInAnotherLib().equals("выдан"))))
                historyReaders.add(historyReader);
        });
        return historyReaders;
    }

    public List<HistoryReader> getAllIssuedHRByUserEmail(String email) {
        List<HistoryReader> historyReaders = new ArrayList<>();
        Streamable.of(historyReaderRepository.findAll()).forEach(historyReader -> {
            List<Reader> readers = readerService.getReaderByEmail(email).stream().filter(reader1 ->
                    reader1.getSubsId() == historyReader.getSubsId()).toList();
            //if (historyReader.getSubsId() == reader.getReaderId().getSubsId())
            if(!readers.isEmpty() && historyReader.isRelevance())
                historyReaders.add(historyReader);
        });
        return historyReaders;
    }

    public IssuedHRView prolongHR(Long id) throws IOException {
        HistoryReader hr = getHistoryReader(id);
        hr.setDateReturn(hr.getDateReturn().plusMonths(1));
        save(hr);

        String type = "";
        if(hr.getDateReturn().isBefore(LocalDate.now()))
            type = "delayeds";
        else type = "issueds";
        return new IssuedHRView(hr, type);
    }
    public HistoryReader extendBook(Long id) {
        HistoryReader hr = getHistoryReader(id);
        hr.setDateReturn(hr.getDateReturn().plusMonths(1));
        hr.getCopyBook().setStatusInThisLib("выдан");
        copyBookService.save(hr.getCopyBook());
        return historyReaderRepository.save(hr);
    }

    public IssuedHRView prolongListHR(String ids) throws IOException {
        List<Long> list = getListIds(ids);
        for (Long hr : list){
            prolongHR(hr);
        }
        return new IssuedHRView(getHistoryReader(list.get(0)), "");
    }

    private List<Long> getListIds(String ids) {
        List<Long> list = new ArrayList<>();
        List<String> arr = new ArrayList<>();
        for (String s : ids.split(", ")){
            list.add(Long.parseLong(s, 10));
        }
        return list;
    }

    public List<HistoryReader> getAllIssuedsHR(Long libId) {
        List<HistoryReader> historyReaders = new ArrayList<>();
        Streamable.of(historyReaderRepository.findAll()).forEach(historyReader -> {
            if(historyReader.isRelevance() && (libId == 0 ||
                    historyReader.getSubscription().getLibrary().getId() == libId))
                historyReaders.add(historyReader);
        });
        return historyReaders;
    }

    public List<HistoryReader> getAllReturnedHR(Long libId) {
        List<HistoryReader> historyReaders = new ArrayList<>();
        Streamable.of(historyReaderRepository.findAll()).forEach(historyReader -> {
            if(!historyReader.isRelevance() && (libId == 0 ||
                    historyReader.getSubscription().getLibrary().getId() == libId))
                historyReaders.add(historyReader);
        });
        return historyReaders;
    }

    public List<HistoryReader> getAllDelayedHR(Long libId) {
        List<HistoryReader> historyReaders = new ArrayList<>();
        Streamable.of(historyReaderRepository.findAll()).forEach(historyReader -> {
            if(historyReader.isRelevance() && historyReader.getDateReturn().isBefore(LocalDate.now()) &&
                    (libId == 0 || historyReader.getSubscription().getLibrary().getId() == libId))
                historyReaders.add(historyReader);
        });
        return historyReaders;
    }
}
