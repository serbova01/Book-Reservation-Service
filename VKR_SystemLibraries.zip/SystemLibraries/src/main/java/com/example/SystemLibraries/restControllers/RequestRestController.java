package com.example.SystemLibraries.restControllers;

import com.example.SystemLibraries.models.Request;
import com.example.SystemLibraries.services.ReqViewService;
import com.example.SystemLibraries.services.RequestService;
import com.example.SystemLibraries.views.ReqView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/rest/request")
public class RequestRestController {
    @Autowired
    public RequestService requestService;
    @Autowired
    public ReqViewService reqViewService;
    @GetMapping("/get-all")
    public List<Request> getAllRequest(){
        return requestService.getAllRequests();
    }
    @GetMapping("/get-all-formed-lib/{id}")
    public List<Request> getAllFormedRequestByLibId(@PathVariable Long id){
        return requestService.getAllFormedRequestsByLibId(id);
    }
    @GetMapping("/get-all-formed-no-lib/{id}")
    public List<Request> getAllFormedRequestByNoLibId(@PathVariable Long id){
        return requestService.getAllFormedRequestsByNoLibId(id);
    }
    @GetMapping("/get-all-delivered-lib/{id}")
    public List<Request> getAllDeliveredRequestsByLibId(@PathVariable Long id){
        return requestService.getAllDeliveredRequestsByLibId(id);
    }
    @GetMapping("/get-all-delivered-no-lib/{id}")
    public List<Request> getAllDeliveredRequestsByNoLibId(@PathVariable Long id){
        return requestService.getAllDeliveredRequestsByNoLibId(id);
    }
    @GetMapping("/get-all-subs/{id}")
    public List<ReqView> getAllBySubsId(@PathVariable Long id){
        return reqViewService.getAllBySubsId(id);
    }
    @GetMapping("/get-all-user/{id}")
    public List<ReqView> getAllByUserEmail(@PathVariable Long id){
        return reqViewService.getAllByUserEmail(id);
    }
    @PostMapping("/save")
    public Request save(@RequestBody Request request){
        return requestService.save(request);
    }
    @GetMapping("/get/{id}")
    public Request getRequestById(@PathVariable Long id){
        return requestService.getRequest(id);
    }
    @GetMapping("/answer-to/{id}")
    public void answerToRequest(@PathVariable Long id){
        requestService.answerToRequest(id);
    }
    @GetMapping("/return-book/{id}")
    public void returnBook(@PathVariable Long id){
        requestService.confimReturnBookInLib(id);
    }
    @PostMapping("/add/{id}")
    public Request add(@PathVariable Long id, @RequestBody ReqView request){
        return reqViewService.add(id, request);
    }
    @PostMapping("/add")
    public Request add(@RequestBody ReqView request){
        return reqViewService.add(request);
    }
    @PostMapping("/add/{edId}/{usId}/{libId}")
    public Request add(@PathVariable Long edId, @PathVariable Long usId, @PathVariable Long libId){
        return requestService.add(edId, usId, libId);
    }
    @GetMapping("/delete/{id}")
    public Request delete(@PathVariable Long id){
        return requestService.deleteById(id);
    }
}
