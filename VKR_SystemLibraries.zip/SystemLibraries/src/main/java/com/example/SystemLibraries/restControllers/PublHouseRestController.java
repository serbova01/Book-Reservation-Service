package com.example.SystemLibraries.restControllers;

import com.example.SystemLibraries.models.PublHouse;
import com.example.SystemLibraries.services.PublHouseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/rest/publHouse")
public class PublHouseRestController {
    @Autowired
    public PublHouseService publHouseService;
    @GetMapping("/get-all")
    public List<PublHouse> getAllPublHouse(){
        return publHouseService.getAllPublHouses();
    }
    @GetMapping("/get-all/{id}")
    public List<PublHouse> getAllPublHouse(@PathVariable Long id){
        return publHouseService.getAllPublHousesByLibId(id);
    }
    @PostMapping("/save")
    public PublHouse save(@RequestBody PublHouse publHouse){
        return publHouseService.save(publHouse);
    }
    @GetMapping("/get/{id}")
    public PublHouse getPublHouseById(@PathVariable Long id){
        return publHouseService.getPublHouse(id);
    }
    @DeleteMapping("/delete/{id}")
    public void delete(@PathVariable Long id){
        publHouseService.deleteById(id);
    }
}
