package com.example.SystemLibraries.services;

import com.example.SystemLibraries.models.Cycle;
import com.example.SystemLibraries.repositories.CycleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.util.Streamable;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CycleService {
    @Autowired
    private CycleRepository cycleRepository;

    public Cycle save(Cycle cycle){
        return  cycleRepository.save(cycle);
    }
    public void deleteById(long id){
        cycleRepository.deleteById(id);
    }
    public List<Cycle> getAllCycles(){
        List<Cycle> cycles = new ArrayList<>();
        Streamable.of(cycleRepository.findAll()).forEach(cycles::add);
        return cycles;
    }
    public List<Cycle> getAllCyclesByLibId(@Nullable Long libId){
        List<Cycle> cycles = new ArrayList<>();
        Streamable.of(cycleRepository.findAll()).forEach(cycle -> {
            if(libId == null || cycle.getBooks().stream().filter(book ->
                    book.getEditions().stream().filter(edition ->
                            edition.getCopyBooks().stream().filter(copyBook ->
                                    copyBook.getDepartment().getLibrary().getId() == libId)
                                    .count() > 0).count() > 0).count() > 0)
                cycles.add(cycle);
        });
        return cycles;
    }
    public Cycle getCycle(@Nullable long id){
        return cycleRepository.findById(id).get();
    }

    public Cycle getByName(String name) {
        return cycleRepository.findByName(name);
    }
}
