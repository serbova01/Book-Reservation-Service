package com.example.SystemLibraries.services;

import com.example.SystemLibraries.models.Subscription;
import com.example.SystemLibraries.repositories.SubscriptionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.util.Streamable;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class SubscriptionService {
    @Autowired
    private SubscriptionRepository subscriptionRepository;
    //@Autowired
    //private ReaderService readerService;
    @Autowired
    private LibraryService libraryService;

    public Subscription save(Subscription subscription){
        subscription.setLibrary(libraryService.getLibrary(subscription.getLibId()));
        if(!subscription.getNumbersList().contains(subscription.getActualNumber())){
            subscription.setNumbers(subscription.getNumbers() + ", " + subscription.getActualNumber());
        }
        return  subscriptionRepository.save(subscription);
    }

    public void deleteById(long id){
        subscriptionRepository.deleteById(id);
    }
    public List<Subscription> getAllSubscriptions(){
        List<Subscription> subscriptions = new ArrayList<>();
        Streamable.of(subscriptionRepository.findAll()).forEach(subscriptions::add);
        return subscriptions;
    }
    public List<Subscription> getAllSubscriptionsByLibId(@Nullable Long libId){
        List<Subscription> subscriptions = new ArrayList<>();
        Streamable.of(subscriptionRepository.findAll()).forEach(subscription ->{
            if(libId == null || subscription.getLibrary().getId() == libId)
                subscriptions.add(subscription);
        });
        return subscriptions;
    }
    public Subscription getSubscription(long id){
        return subscriptionRepository.findById(id).get();
    }
    public Subscription add(Subscription subscription){
        List<Subscription> subscriptions = getAllSubscriptionsByLibId(subscription.getLibrary().getId());
        int number = getMaxInListNumbersInLib(subscriptions);
        subscription.setNumbers(String.valueOf(number));
        subscription.setActualNumber(number);
        return save(subscription);
    }

    public int getMaxInListNumbersInLib(List<Subscription> subscriptions) {
        int max = -1;
        for(Subscription subscription : subscriptions){
            for (int i : subscription.getNumbersList()){
                if(i>max)
                    max = i;
            }
        }
        return max+1;
    }

    public Subscription getByActualNumber(Subscription subscription) {
        List<Subscription> subscriptions = subscriptionRepository.findByActualNumber(subscription.getActualNumber());
        if(!subscriptions.isEmpty() && subscriptions.stream().filter(subs -> subs.getId() != subscription.getId()).count() > 0)
            return subscriptions.get(0);
        else {
            for(Subscription subs : getAllSubscriptionsByLibId(subscription.getLibrary().getId())){
                if(subs.getId() != subscription.getId() &&
                        subs.getNumbersList().contains(subscription.getActualNumber()))
                    return subs;
            }
            return null;
        }
    }
    public Subscription getByActualNumberAndLibId(int actualNumber, Long libId) {
        List<Subscription> subscriptions = subscriptionRepository.findByActualNumber(actualNumber);
        if(!subscriptions.isEmpty()){
            subscriptions = subscriptions.stream().filter(subs -> subs.getLibrary().getId() == libId).toList();
            if(!subscriptions.isEmpty())
                return subscriptions.get(0);
        }
        return null;
    }
}
