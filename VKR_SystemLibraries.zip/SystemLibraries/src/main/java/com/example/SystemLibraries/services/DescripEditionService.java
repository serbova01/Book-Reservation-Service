package com.example.SystemLibraries.services;

import com.example.SystemLibraries.models.*;
import com.example.SystemLibraries.views.DescripEditionView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


@Service
public class DescripEditionService {
    @Autowired
    private EditionService editionService;
    @Autowired
    private LibraryService libraryService;
    @Autowired
    private CopyBookService copyBookService;
    @Autowired
    private UserService userService;
    @Autowired
    private IssuedHRService issuedHRService;
    public List<DescripEditionView> getForViewEd(Long edId, Long usId) throws IOException {
        long id = 0;
        List<Reader> readers = new ArrayList<>();
        List<DescripEditionView> list = new ArrayList<>();
        if(usId != null && usId > 0)
            readers = userService.getReadersById(usId);
        for (Library library : libraryService.getAllLibraries()){
            if(library.getDepartments().stream().filter(department ->
                    department.getCopyBooks().stream().filter(copyBook ->
                            copyBook.getEdId() == edId).count() > 0).count() > 0){
                long count = editionService.getCountInLib(library.getId(), edId);
                boolean reg = false;
                long subsId = 0L;
                long countDelayeds = 0;
                if(!readers.isEmpty()){
                    reg = readers.stream().filter(reader ->
                            reader.getReaderId().getSubscription().getLibId() == library.getId()).count() > 0;
                    if(reg){
                        subsId = readers.stream().filter(reader ->
                                        reader.getReaderId().getSubscription().getLibId() == library.getId()).toList()
                                .get(0).getSubsId();
                    }
                    countDelayeds = issuedHRService.getAllDelayedByUserEmail(usId).size();
                }
                list.add(new DescripEditionView(id, subsId, library, count, reg,
                        countDelayeds));
                id++;
            }
        }
        return list;
    }
    public List<DescripEditionView> getForReservEd(Long edId, Long usId) throws IOException {
        long id = 0;
        List<Reader> readers = new ArrayList<>();
        List<DescripEditionView> list = new ArrayList<>();
        if(usId != null && usId > 0)
            readers = userService.getReadersById(usId);
        for (Library library : libraryService.getAllLibraries()){
            if(library.getDepartments().stream().filter(department ->
                    department.getCopyBooks().stream().filter(copyBook ->
                            copyBook.getEdId() == edId).count() > 0).count() > 0){
                long count = editionService.getCountInLib(library.getId(), edId);
                long subsId = 0L;
                if(!readers.isEmpty() && readers.stream().filter(reader ->
                        reader.getReaderId().getSubscription().getLibId() == library.getId()).count()>0 &&
                        count > 0){
                    subsId = readers.stream().filter(reader ->
                                    reader.getReaderId().getSubscription().getLibId() == library.getId()).toList()
                            .get(0).getSubsId();
                    list.add(new DescripEditionView(id, subsId, library, count, true,
                            issuedHRService.getAllDelayedByUserEmail(usId).stream().filter(item ->
                                    item.getLibrary().getId() == library.getId()).count()));
                    id++;
                }
            }
        }
        return list;
    }
}
