package com.example.SystemLibraries.repositories;

import com.example.SystemLibraries.models.Reader;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ReaderRepository extends JpaRepository<Reader, Reader.ReaderId> {
    Reader findByReaderId(Reader.ReaderId readerId);

    List<Reader> findByEmail(String email);
    List<Reader> findByPhoneNumber(String phoneNumber);
    Reader findByEmailAndSubsId(String email, Long subsId);
}
