package com.example.SystemLibraries.restControllers;

import com.example.SystemLibraries.models.Basket;
import com.example.SystemLibraries.models.Library;
import com.example.SystemLibraries.services.BasketService;
import com.example.SystemLibraries.services.BasketViewService;
import com.example.SystemLibraries.services.FavoriteService;
import com.example.SystemLibraries.views.BasketView;
import com.example.SystemLibraries.views.FavoriteView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;

@RestController
    @RequestMapping("/rest/basket")
public class BasketRestController {
    @Autowired
    public BasketService basketService;
    @Autowired
    public FavoriteService favoriteService;
    @Autowired
    public BasketViewService basketViewService;
    @GetMapping("/get-all-basket/{id}")
    public List<BasketView> getAllBasketByUserId(@PathVariable Long id) throws IOException {
        return basketViewService.getAll(id);
    }
    @GetMapping("/get-all-basket-by-ids/{ids}")
    public List<BasketView> getAllBasketByListIds(@PathVariable String ids) throws IOException {
        return basketViewService.getListBasketByIds(ids);
    }
    @GetMapping("/get-all-favorite/{id}")
    public List<FavoriteView> getAllFavoriteByUserId(@PathVariable Long id){
        return favoriteService.getAllByUserId(id);
    }
    @PostMapping("/save")
    public Basket save(@RequestBody Basket basket){
        return basketService.save(basket);
    }
    @PostMapping("/view/save")
    public BasketView saveView(@RequestBody Basket basket) throws IOException {
        return basketViewService.save(basket);
    }
    @PostMapping("/add-basket")
    public Basket addAsBasket(@RequestBody Basket basket){
        return basketService.addAsBasket(basket);
    }
    @PostMapping("/add-favorite")
    public Basket addAsFavorite(@RequestBody Basket basket) throws IOException {
        return basketService.addAsFavorite(basket);
    }
    @GetMapping("/get/{usId}/{edId}")
    public Basket getBasketByUsIdEdId(@PathVariable Long usId, @PathVariable Long edId){
        return basketService.getBasketByUsIdEdId(usId, edId);
    }
    @GetMapping("/get/{id}")
    public Basket getBasketById(@PathVariable Long id){
        return basketService.getBasket(id);
    }
    @GetMapping("/delete-basket/{id}")
    public BasketView deleteBasket(@PathVariable Long id){
        return basketService.deleteBasketById(id);
    }
    @GetMapping("/delete-baskets/{ids}")
    public Basket deleteBaskets(@PathVariable String ids) throws IOException {
        return basketService.deleteBaskets(ids);
    }
    @GetMapping("/delete-favorite/{id}")
    public Basket deleteFavorite(@PathVariable Long id) throws IOException {
        return basketService.deleteFavoriteById(id);
    }
    @DeleteMapping("/delete/{id}")
    public void deleteById(@PathVariable Long id){
        basketService.deleteById(id);
    }
    @GetMapping("/get-libs-by-choose/{edId}/{userId}")
    public List<Library> getAllLibraryByEditionAndUser(@PathVariable Long edId, @PathVariable Long userId){
        return basketService.getAllByEditionAndUser(edId, userId);
    }
}
