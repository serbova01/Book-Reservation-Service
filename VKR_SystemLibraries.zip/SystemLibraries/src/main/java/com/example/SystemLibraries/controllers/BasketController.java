package com.example.SystemLibraries.controllers;

import com.example.SystemLibraries.formModels.BasketChoose;
import com.example.SystemLibraries.models.*;
import com.example.SystemLibraries.services.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.security.Principal;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/basket")
public class BasketController {
    @Autowired
    BasketService basketService;
    @Autowired
    UserService userService;
    @Autowired
    EditionService editionService;
    @Autowired
    LibraryService libraryService;
    @Autowired
    RequestService requestService;
    @Autowired
    ReservationService reservationService;
    @Autowired
    IssuedHRService issuedHRService;

    @GetMapping("/request/{bId}")
    public String request(Model model, @PathVariable("bId") Long id, Principal principal) throws IOException {
        User user =  userService.getUserByUsername(principal.getName());
        Basket basket = basketService.getBasket(id);
        if(user.getRole() == Role.USER && basket.getUsId() == user.getId()){
            model.addAttribute("user", user);
            List<Subscription> subscriptions = userService.getSubsList(user.getId());
            List<Library> list = userService.getLibsByUserEmail(user.getId());

            model.addAttribute("user_subsList", subscriptions);
            model.addAttribute("basket", basket);
            model.addAttribute("libraries", list);
            return "basket/chooseLibForRequest";
        }else
            return "redirect:/home";
    }

    @GetMapping("/request/{bId}/{libId}")
    @PreAuthorize("hasAuthority('USER')")
    public String request(Model model, @PathVariable("bId") Long bId, @PathVariable("libId") Long libId,
                          Principal principal) throws IOException {
        User user =  userService.getUserByUsername(principal.getName());
        Basket basket = basketService.getBasket(bId);
        Library library = libraryService.getLibrary(libId);
        if(user.getRole() == Role.USER && basket.getUsId() == user.getId() &&
                userService.getLibsByUserEmail(user.getId()).stream().filter(lib-> lib.getId() == library.getId()).count()>0){
            model.addAttribute("user", user);
            List<Subscription> subscriptions = userService.getSubsList(user.getId());
            model.addAttribute("user_subsList", subscriptions);

            requestService.add(basket.getEdition().getId(), user.getId(), libId);
            basketService.deleteBasketById(basket.getId());

            return "redirect:/basket/list";
        }else
            return "redirect:/home";
    }
    @GetMapping("/chooseLib/{bId}/{libId}")
    public String chooseLib(Model model, @PathVariable("bId") Long bId, @PathVariable("libId") Long libId,
                            Principal principal) throws IOException {
        User user =  userService.getUserByUsername(principal.getName());
        Basket basket = basketService.getBasket(bId);
        Library library = libraryService.getLibrary(libId);
        if(user.getRole() == Role.USER && basket.getUsId() == user.getId() &&
                userService.getLibsByUserEmail(user.getId()).stream().filter(lib-> lib.getId() == library.getId()).count()>0){
            List<Subscription> subscriptions = userService.getSubsList(user.getId());
            model.addAttribute("user_subsList", subscriptions);
            model.addAttribute("user", user);

            basket.setLibrary(libraryService.getLibrary(libId));
            basketService.save(basket);

            List<Basket> basketViews = basketService.getAlsoBasketsByUserId(user.getId());
            List<Basket> listReserv = new ArrayList<>();
            List<Basket> listRequest = new ArrayList<>();
            for(Basket item : basketViews){
                if(checkAvailbleEdInUserLib(item)){
                    listReserv.add(item);
                }else
                    listRequest.add(item);
            }
            model.addAttribute("listReserv", listReserv);
            model.addAttribute("listRequest", listRequest);
            return "basket/list1";
        }else
            return "redirect:/home";
    }
    //@GetMapping("/list")
    @PreAuthorize("hasAuthority('USER')")
    public String list1(Model model, Principal principal) throws IOException {
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.USER){
            List<Subscription> subscriptions = userService.getSubsList(user.getId());
            model.addAttribute("user_subsList", subscriptions);
            model.addAttribute("user", user);
            List<Basket> basketViews = basketService.getAlsoBasketsByUserId(user.getId());
            List<Basket> listReserv = new ArrayList<>();
            List<Basket> listRequest = new ArrayList<>();
            for(Basket basket : basketViews){
                if(checkAvailbleEdInUserLib(basket)){
                    listReserv.add(basket);
                }else
                    listRequest.add(basket);
            }
            model.addAttribute("listReserv", listReserv);
            model.addAttribute("listRequest", listRequest);
            return "basket/list";
        }else
            return "redirect:/home";
    }

    @GetMapping("/list")
    @PreAuthorize("hasAuthority('USER')")
    public String list(Model model, Principal principal) throws IOException {
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.USER){
            List<Subscription> subscriptions = userService.getSubsList(user.getId());
            model.addAttribute("user_subsList", subscriptions);
            model.addAttribute("user", user);
            List<Basket> basketViews = basketService.getAlsoBasketsByUserId(user.getId());
            List<BasketChoose> listReserv = new ArrayList<>();
            List<Basket> listRequest = new ArrayList<>();
            long count = userService.getCountReservs(user);
            if(count >= 10){
                model.addAttribute("maxReserv", true);
                listRequest = basketViews;
            }else{
                for(Basket basket : basketViews){
                    if(checkAvailbleEdInUserLib(basket)){
                        listReserv.add(new BasketChoose(basket, getLibs(basket)));
                    }else
                        listRequest.add(basket);
                }
            }
            model.addAttribute("listReserv", listReserv);
            model.addAttribute("listRequest", listRequest);
            return "basket/list1";
        }else
            return "redirect:/home";
    }
    @GetMapping("/reservation/{bId}")
    @PreAuthorize("hasAuthority('USER')")
    public String reservation(Model model, @PathVariable("bId") Long basketId, Principal principal) throws IOException {
        User user =  userService.getUserByUsername(principal.getName());
        Basket basket = basketService.getBasket(basketId);
        if(user.getRole() == Role.USER && user.getId() == basket.getUsId()){
            List<Subscription> subscriptions = userService.getSubsList(user.getId());
            model.addAttribute("user_subsList", subscriptions);
            model.addAttribute("user", user);
            long maxCount = editionService.getCountInLib(basket.getEdId(), basket.getLibId());
            boolean isDelayedBook;
            if(basket.getLibrary() != null){
                isDelayedBook = issuedHRService.getAllDelayedByUserEmail(user.getId()).stream().filter(hr->
                        hr.getLibrary().getId() == basket.getLibrary().getId()).count()>0;
                if(!isDelayedBook){
                    model.addAttribute("basket", basket);
                    model.addAttribute("maxCount", maxCount);
                    return "basket/chooseLib";
                }else{
                    model.addAttribute("idB_DelayedBook", basketId);
                }
            }else model.addAttribute("idB_LibNull", basketId);

            List<Basket> basketViews = basketService.getAlsoBasketsByUserId(user.getId());
            List<BasketChoose> listReserv = new ArrayList<>();
            List<Basket> listRequest = new ArrayList<>();
            long count = userService.getCountReservs(user);
            if(count >= 10){
                model.addAttribute("maxReserv", true);
                listRequest = basketViews;
            }else{
                for(Basket item : basketViews){
                    if(checkAvailbleEdInUserLib(item)){
                        listReserv.add(new BasketChoose(item, getLibs(item)));
                    }else
                        listRequest.add(item);
                }
            }
            model.addAttribute("listReserv", listReserv);
            model.addAttribute("listRequest", listRequest);
            return "basket/list1";
        }else
            return "redirect:/home";
    }
    @GetMapping("/reservation/{bId}/{libId}")
    @PreAuthorize("hasAuthority('USER')")
    public String reservation(Model model, @PathVariable("bId") Long basketId,
                                  @PathVariable("libId") Long libId, Principal principal) throws IOException {
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.USER){
            List<Subscription> subscriptions = userService.getSubsList(user.getId());
            model.addAttribute("user_subsList", subscriptions);
            model.addAttribute("user", user);

            Library library = libraryService.getLibrary(libId);
            Basket basket = basketService.getBasket(basketId);
            basket.setLibrary(library);
            List<Library> libraries = getLibs(basket);
            libraries.remove(library);
            long count = editionService.getCountInLib(libId, basket.getEdId());
            model.addAttribute("availableDelayeds", issuedHRService.getAllDelayedByUserEmail(user.getId()).size());
            model.addAttribute("maxCount", count);
            model.addAttribute("basket", basket);
            model.addAttribute("libraries", libraries);
            return "basket/chooseLib";
        }else
            return "redirect:/home";
    }
    @PostMapping("/reservation")
    @PreAuthorize("hasAuthority('USER')")
    public String reservation(Model model, @ModelAttribute Basket basket, Principal principal) throws IOException {
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.USER){
            if(basket.getLibrary() != null){
                reservationService.makingReserv(basket);
                return "redirect:/basket/list";
            }else{
                return "redirect:/reservation/" + basket.getId();
            }
        }else
            return "redirect:/home";
    }
    private boolean checkAvailbleEdInUserLib(Basket basket) throws IOException {
        for(Library library : userService.getLibsByUserEmail(basket.getUsId())){
            if(editionService.getCountInLib(library.getId(), basket.getEdId()) > 0){
                return true;
            }
        }
        return false;
    }

    private List<Library> getLibs(Basket basket) throws IOException {
        List<Library> libraries = userService.getLibsByUserEmail(basket.getUser().getId());
        List<Library> libraryList = new ArrayList<>();
        for(Library library : libraries){
            if(editionService.getCountInLib(library.getId(), basket.getEdId()) > 0) {
                libraryList.add(library);
            }
        }
        return libraryList;
    }
    @GetMapping("/delete/{bId}")
    @PreAuthorize("hasAuthority('USER')")
    public String delete(Model model, @PathVariable("bId") Long basketId, Principal principal) throws IOException {
        User user =  userService.getUserByUsername(principal.getName());
        Basket basket = basketService.getBasket(basketId);
        if(user.getRole() == Role.USER && basket.getUsId() == user.getId()){
            basketService.deleteBasketById(basketId);
            return "redirect:/basket/list";
        }else
            return "redirect:/home";
    }
}
