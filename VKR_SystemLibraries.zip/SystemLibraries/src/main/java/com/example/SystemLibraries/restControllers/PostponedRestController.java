package com.example.SystemLibraries.restControllers;

import com.example.SystemLibraries.models.Postponed;
import com.example.SystemLibraries.services.PostponedService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/rest/postponed")
public class PostponedRestController {
    @Autowired
    public PostponedService postponedService;
    @GetMapping("/get-all")
    public List<Postponed> getAllPostponed(){
        return postponedService.getAllPostponeds();
    }
    @GetMapping("/get-all/{id}")
    public List<Postponed> getAllPostponed(@PathVariable Long id){
        return postponedService.getAllPostponedsByLibId(id);
    }
    @PostMapping("/save")
    public Postponed save(@RequestBody Postponed postponed){
        return postponedService.save(postponed);
    }
    @GetMapping("/get/{id}")
    public Postponed getPostponedById(@PathVariable Long id){
        return postponedService.getPostponed(id);
    }
    @DeleteMapping("/delete/{id}")
    public void delete(@PathVariable Long id){
        postponedService.deleteById(id);
    }
}
