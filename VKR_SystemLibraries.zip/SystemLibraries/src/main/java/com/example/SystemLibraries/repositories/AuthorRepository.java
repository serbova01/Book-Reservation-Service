package com.example.SystemLibraries.repositories;

import com.example.SystemLibraries.models.Author;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AuthorRepository extends JpaRepository<Author, Long> {
    Author findByFirstnameAndSecondnameAndLastname(String firstname,
                                                   String secondname,
                                                   String lastname);
}
