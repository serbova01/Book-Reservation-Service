package com.example.SystemLibraries.controllers;

import com.example.SystemLibraries.models.*;
import com.example.SystemLibraries.services.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;

@Controller
@RequestMapping("/department")
public class DepartmentController {
    @Autowired
    private DepartmentService mainServer;
    @Autowired
    private LibraryService libraryService;
    @Autowired
    private AuthorService authorService;
    @Autowired
    private GenreService genreService;
    @Autowired
    private UserService userService;
    String[] message = {
            "Некорректные данные. Следуйте правилу выше.",
            "Отдел с таким названием уже существует."
    };
    String inf = "Для добавления отдела по жанру введите только название жанра, " +
            "по автору - фамилию автора и выберете Отдел с жанром.";
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/list")
    public String list(Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        List<Department> list = mainServer.getAllDepartmentsByLibId(user.getLibId());
        model.addAttribute("departments", list);
        //model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
        return "department/list";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/details/{id}")
    public String details(Model model, @PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        Department department = mainServer.getDepartment(id);
        model.addAttribute("department", department);
        //model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
        return "department/details";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/create")
    public String create(Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        List<Library> libraries = libraryService.getAllLibraries();
        Department[] departments = mainServer.getDepParentsByLibId(0L).toArray(new Department[0]);
        model.addAttribute("libraries", libraries);
        //model.addAttribute("departments", departments);
        model.addAttribute("departments", mainServer.getDepParentsByLibId(0L));
        model.addAttribute("department", new Department());
        model.addAttribute("inf", inf);
        //model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
        return "department/create";

    }
    @PreAuthorize("hasAuthority('LIB')")
    @PostMapping("/create")
    public String create(@ModelAttribute Department department, Model model){
        if(mainServer.getByNameAndLibrary(department) == null){
            if(checkDepByLevel(department)){
                mainServer.save(department);
                return "redirect:/department/list";
            }else {
                model.addAttribute("libraries", libraryService.getAllLibraries());
                model.addAttribute("departments", mainServer.getDepParentsByLibId(0L));
                model.addAttribute("inf", inf);

                model.addAttribute("message", message[0]);
                return "department/create";
            }
        }else{
            model.addAttribute("libraries", libraryService.getAllLibraries());
            model.addAttribute("departments", mainServer.getDepParentsByLibId(0L));
            model.addAttribute("inf", inf);
            model.addAttribute("message", message[1]);
            return "department/create";
        }

    }
    @PreAuthorize("hasAuthority('LIB')")
    private boolean checkDepByLevel(Department department) {
        List<Author> authors = authorService.getAllAuthors();
        List<Genre> genres = genreService.getAllGenres();

        if(authors.stream().filter(author -> author.getFirstname().equals(department.getName())).count()>0 &&
                department.getParent() != null)
            return true;
        else{
            return genres.stream().filter(genre -> genre.getName().equals(department.getName())).count()>0 &&
                    department.getParent() == null;
        }
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/edit/{id}")
    public String edit(Model model, @PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        List<Library> libraries = libraryService.getAllLibraries();
        model.addAttribute("libraries", libraries);
        model.addAttribute("departments", mainServer.getDepParentsByLibId(0L));
        model.addAttribute("department", mainServer.getDepartment(id));
        model.addAttribute("inf", inf);
        //model.addAttribute("user", user);
        return "department/edit";

    }
    @PreAuthorize("hasAuthority('LIB')")
    @PostMapping("/edit")
    public String edit(@ModelAttribute Department department, Model model, Principal principal){
        if (department.getName() == null || department.getName().trim().length() < 2){
            List<Library> libraries = libraryService.getAllLibraries();
            model.addAttribute("libraries", libraries);
            model.addAttribute("departments", mainServer.getDepParentsByLibId(0L));
            model.addAttribute("message", message[0]);
            return "department/edit/" + department.getId();
        }
        //User user = mainServer.findUserByLogin(principal.getName());
        //department.setLibrary(user.getLibrary()); //Библиотекарь
        Department depCheck = mainServer.getByNameAndLibrary(department);
        if (depCheck != null && depCheck.getId() != department.getId()){
            List<Library> libraries = libraryService.getAllLibraries();
            model.addAttribute("libraries", libraries);
            model.addAttribute("departments", mainServer.getDepParentsByLibId(0L));
            model.addAttribute("department", department);
            //model.addAttribute("user", user);
            model.addAttribute("message", message[1]);
            return "department/edit/" + department.getId();
        }else{
            mainServer.save(department);
            return "redirect:/department/list";
        }
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id, Principal principal){
        //User user =  mainServer.findUserByLogin(principal.getName());
        mainServer.deleteById(id);
        return "redirect:/department/list";
    }
}
