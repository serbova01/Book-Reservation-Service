package com.example.SystemLibraries.services;

import com.example.SystemLibraries.models.Genre;
import com.example.SystemLibraries.repositories.GenreRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.util.Streamable;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class GenreService {
    @Autowired
    private GenreRepository genreRepository;

    public Genre save(Genre author){
        return  genreRepository.save(author);
    }
    public void deleteById(long id){
        genreRepository.deleteById(id);
    }
    public List<Genre> getAllGenres(){
        List<Genre> genres = new ArrayList<>();
        Streamable.of(genreRepository.findAll()).forEach(genres::add);
        return genres;
    }
    public List<Genre> getAllGenresByLibId(@Nullable Long libId){
        List<Genre> genres = new ArrayList<>();
        Streamable.of(genreRepository.findAll()).forEach(genre ->{
            if(libId == null || genre.getBooks().stream().filter(book ->
                    book.getEditions().stream().filter(edition ->
                            edition.getCopyBooks().stream().filter(copyBook ->
                                    copyBook.getDepartment().getLibrary().getId()==libId)
                                    .count() > 0).count() > 0).count() > 0)
                genres.add(genre);
        });
        return genres;
    }
    public Genre getGenre(long id){
        return genreRepository.findById(id).get();
    }

    public Genre getByName(String name) {
        return genreRepository.findByName(name);
    }
}
