package com.example.SystemLibraries.repositories;

import com.example.SystemLibraries.models.Edition;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EditionRepository extends JpaRepository<Edition, Long> {
    @Query(value = "select s.* from edition s join Book b on s.book_id = b.id left join Cycle c on b.cycle_id = c.id " +
            "where lower(b.name) like %:keyword% or lower(b.author_str) like %:keyword% or " +
            "lower(c.name) like %:keyword%", nativeQuery = true)
    List<Edition> findByKeyword(@Param("keyword") String keyword);
}
