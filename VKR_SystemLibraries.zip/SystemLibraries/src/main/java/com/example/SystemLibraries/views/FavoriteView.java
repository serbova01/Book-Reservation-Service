package com.example.SystemLibraries.views;

import com.example.SystemLibraries.models.Basket;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import javax.persistence.*;
import lombok.Getter;
import org.hibernate.annotations.Immutable;

import java.io.IOException;

@Entity
@Table(name = "v_favorite")
@Getter
@Immutable
public class FavoriteView {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private boolean favorite;
    private Long libId;
    private Long usId;
    private Long edId;
    @ManyToOne
    @JsonManagedReference
    private CatalogView edition;

    public FavoriteView(Basket basket) throws IOException {
        id = basket.getId();
        favorite = basket.isFavorite();
        libId = basket.getLibId();
        usId = basket.getUsId();
        edId = basket.getEdId();
        edition = new CatalogView(basket.getEdition());
    }
}
