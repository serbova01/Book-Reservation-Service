package com.example.SystemLibraries.services;

import com.example.SystemLibraries.models.Author;
import com.example.SystemLibraries.models.Edition;
import com.example.SystemLibraries.repositories.EditionRepository;
import org.apache.catalina.valves.rewrite.InternalRewriteMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.util.Streamable;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Service
public class EditionService {
    @Autowired
    private EditionRepository editionRepository;
    @Autowired
    private BookService bookService;
    @Autowired
    private PublHouseService publHouseService;
    @Autowired
    private ReaderService readerService;
    //@Autowired
    //private CopyBookService copyBookService;

    public Edition save(Edition edition){
        edition.setBook(bookService.getBook(edition.getBId()));
        edition.setPublHouse(publHouseService.getPublHouse(edition.getPublHId()));
        return  editionRepository.save(edition);
    }
    public void deleteById(long id){
        editionRepository.deleteById(id);
    }
    public List<String> getCatalogCardsByLibId(@Nullable Long libId){
        List<String> catalogCards = new ArrayList<>();
        Streamable.of(editionRepository.findAll()).forEach(edition ->{
            if(libId == null || edition.getCopyBooks().stream().filter(copyBook ->
                    copyBook.getDepartment().getLibrary().getId() == libId).count() > 0){
                List<Author> authors = edition.getBook().getAuthors();
                String str = edition.getCopyBooks().get(0).getBBK() + " ";
                str.concat(authors.get(0).getLastname() + ", " + authors.get(0).getFirstname() +
                        " " + authors.get(0).getSecondname() + "\n");
                str.concat(edition.getCopyBooks().get(0).getDepartment().getParent().getName() +
                        " " + edition.getBook().getName() + " : " + edition.getBook().getGenre());
                str.concat(" / " + edition.getBook().getAuthorStr() + ". - " +
                        edition.getPublHouse().getCity() + " : " + edition.getPublHouse().getName() +
                        ", " + edition.getYear() + ". - " + edition.getCountPage() + " c. : ил.\n");
                str.concat("\tISBN " + edition.getISBN() + ".\n\n\t" + edition.getDiscription());

                catalogCards.add(str);
            }

        });
        return  catalogCards;
    }
    public List<Edition> getEditionsByLibId(@Nullable Long libId){
        List<Edition> editions = new ArrayList<>();
        Streamable.of(editionRepository.findAll()).forEach(edition ->{
            if(libId == null || edition.getCopyBooks().stream().filter(copyBook ->
                    copyBook.getDepartment().getLibrary().getId() == libId).count() > 0)
                editions.add(edition);
        });
        return  editions;
    }
    public Edition getEdition(long id){
        return editionRepository.findById(id).get();
    }
    public long getCountInLib(Long libId, long edId) throws IOException {
        Edition edition = getEdition(edId);
        return edition.getCopyBooks().stream().filter(copyBook ->
                copyBook.getStatusInThisLib().equals("в наличии") && copyBook.getDepartment().getLibId() == libId).count();
    }

    public List<Edition> getAllEditions() {
        List<Edition> editions = new ArrayList<>();
        Streamable.of(editionRepository.findAll()).forEach(editions::add);
        return  editions;
    }

    public List<Edition> getByKeyword(String keyword){
        keyword = keyword.toLowerCase();
        return editionRepository.findByKeyword(keyword);
    }
}
