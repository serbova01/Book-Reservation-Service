package com.example.SystemLibraries.services;

import com.example.SystemLibraries.models.Author;
import com.example.SystemLibraries.models.Book;
import com.example.SystemLibraries.repositories.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.util.Streamable;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class BookService {
    @Autowired
    private BookRepository bookRepository;
    @Autowired
    private GenreService genreService;
    @Autowired
    private CycleService cycleService;

    public Book save(Book book){
        book.setGenre(genreService.getGenre(book.getGId()));
        if(book.getCId() != null && book.getCId()>0){
            book.setCycle(cycleService.getCycle(book.getCId()));
        }
        return bookRepository.save(book);
    }
    public void deleteById(long id){
        Book book = getBook(id);
        book.setAuthors(null);
        save(book);
        bookRepository.deleteById(id);
    }
    public List<Book> getAllBooks(){
        List<Book> books = new ArrayList<>();
        Streamable.of(bookRepository.findAll()).forEach(books::add);
        return books;
    }
    public List<Book> getAllBooksByLibId(@Nullable Long libId){
        List<Book> books = new ArrayList<>();
        Streamable.of(bookRepository.findAll()).forEach(book -> {
            if(libId == null || book.getEditions().stream().filter(edition ->
                    edition.getCopyBooks().stream().filter(copyBook ->
                                    copyBook.getDepartment().getLibrary().getId() == libId)
                            .count() > 0).count() > 0)
                books.add(book);
        });
        return books;
    }
    public Book getBook(long id){
        return bookRepository.findById(id).get();
    }

    public void addAuthor(long id, Author author) {
        Book book = getBook(id);
        book.getAuthors().add(author);
        save(book);
    }

    public void deleteAuthor(Long id, Author author) {
        Book book = getBook(id);
        book.getAuthors().remove(author);
        save(book);
    }

    public Book getByNameAndAuthors(Book book) {
        List<Book> books = bookRepository.findByName(book.getName());
        Book findBook = null;
        for(Book item : books){
            for(int i =0; i<book.getAuthors().size(); i++){
                int finalI = i;
                if(item.getAuthors().stream().filter(author ->
                        author.getId() == book.getAuthors().get(finalI).getId()).count() == 0){
                    break;
                }
            }
            findBook = item;
        }
        return findBook;
    }

    public List<Book> getByAuthor(Author author) {
        List<Book> books = getAllBooks().stream().filter(book ->
                book.getAuthors().stream().filter(item -> item.getId() == author.getId()).count()>0).toList();
        return books;
    }
}
