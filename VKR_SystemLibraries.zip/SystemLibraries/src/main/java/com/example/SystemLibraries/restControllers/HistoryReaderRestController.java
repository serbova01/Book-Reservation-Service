package com.example.SystemLibraries.restControllers;

import com.example.SystemLibraries.models.HistoryReader;
import com.example.SystemLibraries.services.HRViewService;
import com.example.SystemLibraries.services.HistoryReaderService;
import com.example.SystemLibraries.services.IssuedHRService;
import com.example.SystemLibraries.views.HRView;
import com.example.SystemLibraries.views.IssuedHRView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/rest/historyReader")
public class HistoryReaderRestController {
    @Autowired
    public HistoryReaderService historyReaderService;
    @Autowired
    public HRViewService hrViewService;
    @Autowired
    public IssuedHRService issuedHRService;
    @GetMapping("/get-all")
    public List<HistoryReader> getAllHistoryReader(){
        return historyReaderService.getAllHistoryReaders();
    }
    @GetMapping("/get-all/{id}")
    public List<HistoryReader> getAllHistoryReader(@PathVariable Long id){
        return historyReaderService.getAllHistoryReadersByLibId(id);
    }
    @PostMapping("/save")
    public HistoryReader save(@RequestBody HistoryReader historyReader){
        return historyReaderService.save(historyReader);
    }
    @GetMapping("/get/{id}")
    public HistoryReader getHistoryReaderById(@PathVariable Long id){
        return historyReaderService.getHistoryReader(id);
    }
    @GetMapping("/get-for-subs/{id}")
    public List<HistoryReader> getHistoryReaderBySubsId(@PathVariable Long id){
        return historyReaderService.getAllHistoryReaderBySubsId(id);
    }
    @GetMapping("/get-issueds-user/{id}")
    public List<IssuedHRView> getAllIssuedHRByUserEmail(@PathVariable Long id){
        return issuedHRService.getAllIssuedByUserEmail(id);
    }
    @GetMapping("/get-delayeds-user/{id}")
    public List<IssuedHRView> getAllDelayedHRByUserEmail(@PathVariable Long id){
        return issuedHRService.getAllDelayedByUserEmail(id);
    }
    @GetMapping("/prolong/{id}")
    public IssuedHRView prolongHR(@PathVariable Long id) throws IOException {
        return historyReaderService.prolongHR(id);
    }
    //@GetMapping("/prolong")
    //public IssuedHRView prolongListLong(@RequestBody ArrayList<Long> list){
        //return historyReaderService.prolongListHR(list);
    //}
    @PostMapping("/prolong/{ids}")
    public IssuedHRView prolongList(@PathVariable String ids) throws IOException {
        return historyReaderService.prolongListHR(ids);
    }
    @GetMapping("/get-issued-for-subs/{id}")
    public List<IssuedHRView> getAllIssuedHRBySubsId(@PathVariable Long id){
        return issuedHRService.getAllBySubsId(id);
    }
    @GetMapping("/get-noissued-for-subs/{id}")
    public List<IssuedHRView> getAllNoIssuedHRBySubsId(@PathVariable Long id){
        return historyReaderService.getAllNoIssuedHRBySubsId(id);
    }
    @DeleteMapping("/delete/{id}")
    public void delete(@PathVariable Long id){
        historyReaderService.deleteById(id);
    }
    @GetMapping("/returned/{id}")
    public HistoryReader returned(@PathVariable Long id){
        return historyReaderService.returnedBook(id);
    }
    @PostMapping("/add")
    public HistoryReader add(@RequestBody HistoryReader historyReader){
        return historyReaderService.add(historyReader);
    }
    @GetMapping("/view/get-for-subs/{id}")
    public List<HRView> getAllHR(@PathVariable Long id){
        return hrViewService.getAllHRView(id);
    }
}
