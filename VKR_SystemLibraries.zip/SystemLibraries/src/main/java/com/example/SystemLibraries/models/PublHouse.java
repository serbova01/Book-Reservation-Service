package com.example.SystemLibraries.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class PublHouse {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String city;
    private String shortNameCity;

    @OneToMany(mappedBy = "publHouse")
    @JsonIgnore
    //@JsonBackReference(value="edition-publHouse")
    private List<Edition> editions;

    public boolean isNullFields() {
        return name == null || name.length() == 0 || city == null || city.length() == 0;
    }
}
