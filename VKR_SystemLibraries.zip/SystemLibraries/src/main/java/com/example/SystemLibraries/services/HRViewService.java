package com.example.SystemLibraries.services;

import com.example.SystemLibraries.models.HistoryReader;
import com.example.SystemLibraries.views.CatalogView;
import com.example.SystemLibraries.views.HRView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.util.Streamable;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Service
public class HRViewService {
    @Autowired
    private HistoryReaderService historyReaderService;
    @Autowired
    private CatalogService catalogService;
    public List<HRView> getAllHRView(long subsId){
        List<HRView> list = new ArrayList<>();
        Streamable.of(historyReaderService.getAllHistoryReaderBySubsId(subsId)).forEach(hr -> {
            try {
                CatalogView catalogView = catalogService.get(hr.getCopyBook().getEdId());
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            HRView hrView = null;
            try {
                hrView = new HRView(hr);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            list.add(hrView);
        });
        return list;
    }
    public HRView getHR(long id) throws IOException {
        HistoryReader hr = historyReaderService.getHistoryReader(id);
        CatalogView catalogView = catalogService.get(hr.getCopyBook().getEdId());
        HRView hrView = new HRView(hr);
        return hrView;
    }
}
