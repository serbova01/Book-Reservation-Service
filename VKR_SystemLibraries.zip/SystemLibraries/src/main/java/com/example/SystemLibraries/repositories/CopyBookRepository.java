package com.example.SystemLibraries.repositories;

import com.example.SystemLibraries.models.CopyBook;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CopyBookRepository extends JpaRepository<CopyBook, Long> {
    List<CopyBook> findByInvNumber(String invNumber);
}
