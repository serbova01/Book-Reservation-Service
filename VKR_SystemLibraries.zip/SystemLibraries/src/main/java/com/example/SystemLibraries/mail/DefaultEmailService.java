package com.example.SystemLibraries.mail;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class DefaultEmailService implements EmailService{
    @Autowired
    public JavaMailSender emailSender;
    @Value("${spring.mail.username}")
    private String from;
    @Override
    public void sendSimpleEmail(String toAddress, String subject, String message) {
        SimpleMailMessage simpleMailMessage = new SimpleMailMessage();
        simpleMailMessage.setFrom(from);
        simpleMailMessage.setTo(toAddress);
        simpleMailMessage.setSubject(subject);
        simpleMailMessage.setText(message);
        emailSender.send(simpleMailMessage);
    }

    public String sendCode(String toAddress) {
        String subject = "Код подтверждения";
        String code = generateCode();
        String message = "Ваш код подтверждения: " + code + "\nС уважением, сайт 'Бронирование книг'.";
        SimpleMailMessage simpleMailMessage = new SimpleMailMessage();
        simpleMailMessage.setFrom(from);
        simpleMailMessage.setTo(toAddress);
        simpleMailMessage.setSubject(subject);
        simpleMailMessage.setText(message);
        emailSender.send(simpleMailMessage);
        return code;
    }

    private String generateCode() {
        String code = "";
        String uuid = UUID.randomUUID().toString();
        for(char c : uuid.toCharArray()){
            if(code.length() < 4){
                if(Character.isDigit(c))
                    code += c;
            }
        }
        while(code.length() < 4)
            code+="0";
        return code;
    }

    public void sendCreateLibUser(String toAddress, String username, String password) {
        SimpleMailMessage simpleMailMessage = new SimpleMailMessage();
        simpleMailMessage.setFrom(from);
        simpleMailMessage.setTo(toAddress);
        String subject = "Логин и пароль учетки 'Бронирование книг'.";
        simpleMailMessage.setSubject(subject);
        String message = "Вам была создана учетная запись на сайте 'Бронирование книг' для работы с данными Вашей " +
                "библитеки. \n\tЛогин: " + username + "\n\tПароль: " + password + "\n Для безопасности данных смените " +
                "пароль при первом заходе в систему.";
        simpleMailMessage.setText(message);
        emailSender.send(simpleMailMessage);
    }
}
