package com.example.SystemLibraries.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Basket {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private boolean favorite;
    private int count;
    @Column(name = "library_id", insertable=false, updatable=false)
    private Long libId;
    @ManyToOne
    @JsonIgnore
    //@JsonManagedReference(value="basket-library")
    private Library library;
    @Column(name = "user_id", insertable=false, updatable=false)
    private Long usId;
    @ManyToOne
    @JsonIgnore
    //@JsonManagedReference(value="basket-user")
    private User user;
    @Column(name = "edition_id", insertable=false, updatable=false)
    private Long edId;
    @ManyToOne
    @JsonIgnore
    //@JsonManagedReference(value="basket-edition")
    private Edition edition;

    public void setEdition(Edition edition) {
        this.edition = edition;
        setEdId(edition.getId());
    }

    public void setLibrary(Library library) {
        this.library = library;
        setLibId(library.getId());
    }

    public void setUser(User user) {
        this.user = user;
        setUsId(user.getId());
    }
}
