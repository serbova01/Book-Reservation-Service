package com.example.SystemLibraries.controllers;

import com.example.SystemLibraries.formModels.LibDetails;
import com.example.SystemLibraries.mail.DefaultEmailService;
import com.example.SystemLibraries.models.Library;
import com.example.SystemLibraries.models.Role;
import com.example.SystemLibraries.models.Subscription;
import com.example.SystemLibraries.models.User;
import com.example.SystemLibraries.services.LibraryService;
import com.example.SystemLibraries.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;
import java.util.Random;

@Controller
@RequestMapping("/library")
public class LibraryController {
    String[] messages = {
            "Заполните обязательные поля: Название, Городской номер, Улицу, Дом.",
            "Библиотека с таким адресом уже существует.",
            "Поля Долгота и Широта либо оба заполнены, либо оба равны 0.",
            "Заполните обязательные поля Email и Имя пользователя.",
            "Такое Имя пользователя уже занято.",
            "Такой Email уже занят."
    };
    @Autowired
    private LibraryService mainServer;
    @Autowired
    private UserService userService;
    @Autowired
    DefaultEmailService emailService;
    @GetMapping("/list")
    public String list(Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        if(user.getRole() == Role.USER){
            List<Subscription> subscriptions = userService.getSubsList(user.getId());
            model.addAttribute("user_subsList", subscriptions);
        }
        List<Library> list = mainServer.getAllLibraries();
        model.addAttribute("libraries", list);
        //model.addAttribute("user", user);
        return "library/list";
    }
    @PreAuthorize("hasAuthority('ADMIN')")
    @GetMapping("/create")
    public String createGet(Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.ADMIN){
            model.addAttribute("user", user);
            model.addAttribute("library", new LibDetails(new Library()));
            //model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
            return "library/create";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('ADMIN')")
    @PostMapping("/create")
    public String createPost(@ModelAttribute LibDetails library, Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        if (library.isNullFields()){
            model.addAttribute("library", library);
            model.addAttribute("message", messages[0]);
            return "library/create";
        }
        if((library.getLatitude() <= 0 && library.getLongitude() <= 0) || (library.getLatitude() > 0 &&
                library.getLongitude() > 0)){
            Library newLib = library.convertToLibrary(new Library());
            if (mainServer.getByAddress(newLib.getAddress()) == null){
                newLib = mainServer.save(newLib);
                return "redirect:/library/createLibUser/" + newLib.getId();
            }else{
                model.addAttribute("message", messages[1]);
                model.addAttribute("library", library);
                return "library/create";
            }
        }else {
            model.addAttribute("message", messages[2]);
            model.addAttribute("library", library);
            return "library/create";
        }
    }
    @PreAuthorize("hasAuthority('ADMIN')")
    @GetMapping("/createLibUser/{id}")
    public String createLibUser(Model model, @PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.ADMIN){
            User librarian = new User();
            librarian.setLibrary(mainServer.getLibrary(id));
            model.addAttribute("user", user);
            model.addAttribute("librarian", librarian);
            return "library/createLibUser";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('ADMIN')")
    @PostMapping("/createLibUser")
    public String createLibUser(@ModelAttribute User librarian, Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(librarian.isNullFields()){
            User check = userService.getUserByUsername(librarian.getUsername());
            if(check == null){
                check = userService.getByEmail(librarian.getEmail());
                if(check == null){
                    String password = alphaNumericString(8);
                    emailService.sendCreateLibUser(librarian.getEmail(), librarian.getUsername(), password);
                    BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
                    librarian.setPassword(passwordEncoder.encode(password));
                    librarian.setRole(Role.LIB);
                    userService.save(librarian);
                    return "redirect:/library/list";
                }else
                    model.addAttribute("message", messages[5]);
            }else
                model.addAttribute("message", messages[4]);
        }else
            model.addAttribute("message", messages[3]);
        model.addAttribute("user", user);
        model.addAttribute("librarian", librarian);
        return "library/createLibUser";
    }
    @GetMapping("/details/{id}")
    public String details(Model model, @PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        if((user.getRole() == Role.USER && userService.getSubsList(user.getId()).stream().filter(subs ->
                subs.getLibrary().getId() == id).count()>0) || user.getRole() == Role.ADMIN || user.getRole() == Role.LIB){
            Library library = mainServer.getLibrary(id);
            model.addAttribute("library", library);
            List<User> librarians = userService.getAllUsers().stream().filter(us -> us.getRole() == Role.LIB &&
                    us.getLibId() == library.getId()).toList();
            if(!librarians.isEmpty()){
                model.addAttribute("librarian", librarians.get(0));
            }
            if(user.getRole() == Role.USER){
                List<Subscription> subscriptions = userService.getSubsList(user.getId());
                model.addAttribute("user_subsList", subscriptions);
            }
            return "library/details";
        }else{
            return "redirect:/home";
        }
    }
    @PreAuthorize("hasAuthority('ADMIN') || hasAuthority('LIB')")
    @GetMapping("/edit/{id}")
    public String edit(Model model, @PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.ADMIN || (user.getRole() == Role.LIB &&
                user.getLibId() == id)){
            model.addAttribute("user", user);
            model.addAttribute("library", new LibDetails(mainServer.getLibrary(id)));
            //model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
            return "library/edit";
        }else{
            return "redirect:/home";
        }
    }
    @PreAuthorize("hasAuthority('ADMIN') || hasAuthority('LIB')")
    @PostMapping("/edit")
    public String edit(@ModelAttribute LibDetails libDetails, Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if (libDetails.isNullFields()){
            return "redirect:/library/edit-mes/1/" + libDetails.getId();
        }
        if((libDetails.getLatitude() <= 0 && libDetails.getLongitude() <= 0) || (libDetails.getLatitude() > 0 &&
                libDetails.getLongitude() > 0)){
            Library library = mainServer.getLibrary(libDetails.getId());
            library = libDetails.convertToLibrary(library);
            Library libCheck = mainServer.getByAddress(library.getAddress());
            if (libCheck != null && libCheck.getId() != library.getId()){
                model.addAttribute("user", user);
                model.addAttribute("library", library);
                model.addAttribute("message", messages[1]);
                return "library/edit";
            }else{
                mainServer.save(library);
                if(user.getRole() == Role.ADMIN)
                    return "redirect:/library/list";
                else
                    return "redirect:/profileUser";
            }
        }else{
            model.addAttribute("message", messages[2]);
            return "library/create";
        }
    }
    @PreAuthorize("hasAuthority('ADMIN')")
    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() != Role.USER){
            mainServer.deleteById(id);
            return "redirect:/library/list";
        }else
            return "redirect:/home";
    }
    public static String alphaNumericString(int len) {
        String AB = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        Random rnd = new Random();

        StringBuilder sb = new StringBuilder(len);
        for (int i = 0; i < len; i++) {
            sb.append(AB.charAt(rnd.nextInt(AB.length())));
        }
        return sb.toString();
    }

}
