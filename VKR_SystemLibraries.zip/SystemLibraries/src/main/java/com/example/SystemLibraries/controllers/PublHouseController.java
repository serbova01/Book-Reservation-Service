package com.example.SystemLibraries.controllers;

import com.example.SystemLibraries.models.*;
import com.example.SystemLibraries.services.PublHouseService;
import com.example.SystemLibraries.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;

@Controller
@RequestMapping("/publhouse")
public class PublHouseController {
    @Autowired
    private PublHouseService publHouseService;
    @Autowired
    private UserService userService;
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/list")
    public String list(Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            model.addAttribute("user", user);
            List<PublHouse> list = publHouseService.getAllPublHouses();
            model.addAttribute("publHouses", list);
            //model.addAttribute("user", user);
            return "publhouse/list";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/create")
    public String createGet(Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            model.addAttribute("user", user);
            model.addAttribute("publHouse", new PublHouse());
            //model.addAttribute("user", publHouseService.getPublHouse(principal.getName()));
            return "publhouse/create";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @PostMapping("/create")
    public String createPost(@ModelAttribute PublHouse publHouse, Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        if (publHouse.isNullFields()){
            model.addAttribute("message", "Заполните обязательные поля: Название и Город");
            return "publhouse/create";
        }
        if (publHouseService.getByName(publHouse.getName()) == null){
            publHouseService.save(publHouse);
            List<PublHouse> list = publHouseService.getAllPublHouses();
            model.addAttribute("publHouses", list);
            return "redirect:/publhouse/list";
        }else{
            model.addAttribute("publHouse", publHouse);
            model.addAttribute("message", "Издательство с таким названием уже существует.");
            return "publhouse/create";
        }
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/details/{id}")
    public String details(Model model, @PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            model.addAttribute("user", user);
            PublHouse publHouse = publHouseService.getPublHouse(id);
            model.addAttribute("publHouse", publHouse);
            //model.addAttribute("user", user);
            return "publhouse/details";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/edit/{id}")
    public String edit(Model model, @PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            model.addAttribute("user", user);
            model.addAttribute("publHouse", publHouseService.getPublHouse(id));
            //model.addAttribute("user", user);
            return "publhouse/edit";
        }else
            return "redirect:/home";
    }
    @PreAuthorize("hasAuthority('LIB')")
    @PostMapping("/edit")
    public String edit(@ModelAttribute PublHouse publHouse, Model model, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        model.addAttribute("user", user);
        if (publHouse.isNullFields()){
            model.addAttribute("message", "Заполните обязательные поля: Название и Город");
            return "publhouse/edit/" + publHouse.getId();
        }
        PublHouse phCheck = publHouseService.getByName(publHouse.getName());
        if (phCheck != null && phCheck.getId() != publHouse.getId()){
            model.addAttribute("publHouse", publHouse);
            model.addAttribute("message", "Издательство с таким названием уже существует.");
            return "publhouse/edit/" + publHouse.getId();
        }else{
            publHouseService.save(publHouse);
            return "redirect:/publhouse/list";
        }
    }
    @PreAuthorize("hasAuthority('LIB')")
    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id, Principal principal){
        User user =  userService.getUserByUsername(principal.getName());
        if(user.getRole() == Role.LIB){
            publHouseService.deleteById(id);
            return "redirect:/publhouse/list";
        }else
            return "redirect:/home";
    }
}
