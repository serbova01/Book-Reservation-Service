package com.example.SystemLibraries.mail;

public interface EmailService {
    public void sendSimpleEmail(String toAddress, String subject, String message);
}
