package com.example.SystemLibraries.formModels;

import com.example.SystemLibraries.models.CopyBook;
import com.example.SystemLibraries.models.Edition;
import com.example.SystemLibraries.models.Library;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CopyBookEdit {
    private Long id;
    private String invNumber;
    private String BBK;
    private Edition edition;
    private Library library;

    public CopyBookEdit(CopyBook copyBook){
        id = copyBook.getId();
        invNumber = copyBook.getInvNumber();
        BBK = copyBook.getBBK();
        edition = copyBook.getEdition();
        library = copyBook.getDepartment().getLibrary();
    }

    public CopyBook convertToCopyBook(CopyBook copyBook) {
        copyBook.setId(id);
        copyBook.setInvNumber(invNumber);
        copyBook.setBBK(BBK);
        copyBook.setEdition(edition);
        return  copyBook;
    }
}
