package com.example.SystemLibraries.formModels;

import com.example.SystemLibraries.models.Basket;
import com.example.SystemLibraries.models.Edition;
import com.example.SystemLibraries.models.Library;
import com.example.SystemLibraries.views.BasketView;
import com.example.SystemLibraries.views.CatalogView;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class BasketChoose {
    private Long id;
    private Edition edition;
    private Library library;
    private String selLibId;
    private long сount;
    private long maxCount;
    //private List<Library> libraryList;
    private Library[] libraryList;
    public BasketChoose(Basket basket, List<Library> list){
        id = basket.getId();
        edition = basket.getEdition();
        сount = basket.getCount();
        library = basket.getLibrary();
        if(library!=null)
            selLibId = library.getId().toString();
        libraryList = list.toArray(new Library[0]);
        //libraryList = list;
    }
}
