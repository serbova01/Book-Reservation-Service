package com.example.SystemLibraries.views;

import com.example.SystemLibraries.models.Library;
import com.example.SystemLibraries.models.Reservation;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import javax.persistence.*;
import lombok.Getter;
import org.hibernate.annotations.Immutable;

import java.io.IOException;

@Entity
@Table(name = "v_reserv")
@Getter
@Immutable
public class ReservView {
    @Id
    private Long id;
    private String dateFormStr;
    private String dateReservStr;
    private String status;
    private long maxCopies;
    private Long edId;
    private Long subsId;
    @ManyToOne
    @JsonManagedReference
    private CatalogView edition;
    private String invNum;
    private Long libId;
    private String libName;
    private String libAddress;
    @ManyToOne
    @JsonManagedReference
    private Library library;

    public ReservView(Reservation reservation, long maxCopies) throws IOException {
        id = reservation.getId();
        dateFormStr = reservation.getDateForm().toString();
        dateReservStr = reservation.getDateReserv() == null ? null : reservation.getDateReserv().toString();
        status = reservation.getStatus();
        this.maxCopies = maxCopies;
        subsId = reservation.getSubsId();
        edId = reservation.getEdId();
        edition = new CatalogView(reservation.getEdition());
        if(reservation.getCopyBook() != null)
            invNum = reservation.getCopyBook().getInvNumber();
        libId = reservation.getSubscription().getLibId();
        libName = reservation.getSubscription().getLibrary().getName();
        libAddress = reservation.getSubscription().getLibrary().getAddress();
        library = reservation.getSubscription().getLibrary();
    }
}
