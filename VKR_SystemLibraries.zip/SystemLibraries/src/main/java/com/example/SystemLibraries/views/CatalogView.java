package com.example.SystemLibraries.views;

import com.example.SystemLibraries.models.*;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import javax.persistence.*;
import lombok.Getter;
import org.apache.commons.io.IOUtils;
import org.hibernate.annotations.Immutable;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

@Entity
@Table(name = "v_catalog")
@Getter
@Immutable
public class CatalogView {
    @Id
    private Long id;
    private String ISBN;
    @Column(name = "description", insertable=false, updatable=false)
    private String discription;
    private byte[] imagePath;
    private String imageName;
    private int year;
    private int countPage;
    private float price;
    private String bookName;
    private String genreName;
    private String cycleName;
    private String bookAuthorStr;
    private String publHouseName;
    private String text;
    @OneToMany(mappedBy = "edition")
    @JsonIgnore
    private List<HRView> hrViewList;
    @OneToMany(mappedBy = "edition")
    @JsonBackReference
    private List<ReqView> reqViewList;
    @OneToMany(mappedBy = "edition")
    @JsonBackReference
    private List<ReservView> reservViewList;

    public CatalogView(Edition edition) throws IOException {
        id = edition.getId();
        ISBN = edition.getISBN();
        discription = edition.getDiscription();
        imageName = edition.getImagePath();
        try{
            InputStream in = getClass().getResourceAsStream("/static/img" + edition.getImagePath());
            imagePath = IOUtils.toByteArray(in);
        }catch (Exception ex){
            InputStream in = getClass().getResourceAsStream("/static/img/images/empty_book.png");
            imagePath = IOUtils.toByteArray(in);
        }
        year = edition.getYear();
        countPage = edition.getCountPage();
        price = edition.getPrice();
        if(edition.getBook().getCycle() != null)
            cycleName = edition.getBook().getCycle().getName();
        bookName = edition.getBook().getName();
        genreName = edition.getBook().getGenre().getName();
        bookAuthorStr = edition.getBook().getAuthorStr();
        publHouseName = edition.getPublHouse().getName();
        setText();
    }

    public void setText() {
        this.text = publHouseName;
        if(cycleName!=null)
            text += "\n" + cycleName;
        text += "\n" + bookAuthorStr;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
