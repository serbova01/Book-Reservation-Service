package com.example.SystemLibraries.services;

import com.example.SystemLibraries.models.Request;
import com.example.SystemLibraries.views.ReqView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.util.Streamable;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Service
public class ReqViewService {
    @Autowired
    RequestService requestService;
    @Autowired
    UserService userService;
    @Autowired
    EditionService editionService;

    public List<ReqView> getAllBySubsId(long subsId){
        List<ReqView> reqViews = new ArrayList<>();
        Streamable.of(requestService.getRequestsBySubsId(subsId)).forEach(request -> {
            try {
                reqViews.add(new ReqView(request));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
        return reqViews;
    }
    public ReqView get(long id) throws IOException {
        Request request = requestService.getRequest(id);
        return new ReqView(request);
    }

    public List<ReqView> getAllByUserEmail(Long usId) {
        List<ReqView> reqViews = new ArrayList<>();
        String email = userService.getUser(usId).getEmail();
        Streamable.of(requestService.getRequestsByUserEmail(email)).forEach(request -> {
            try {
                reqViews.add(new ReqView(request));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
        return reqViews;
    }

    public Request add(Long id, ReqView reqView) {
        Request request = new Request();
        request.setSubscription(userService.getSubs(id, reqView.getLibId()));
        request.setEdition(editionService.getEdition(id));
        return requestService.add(request);
    }
    public Request add(ReqView reqView) {
        Request request = new Request();
        request.setSubscription(userService.getSubs(reqView.getUsId(), reqView.getLibId()));
        request.setEdition(editionService.getEdition(reqView.getEdId()));
        return requestService.add(request);
    }
}
