package com.example.SystemLibraries.restControllers;

import com.example.SystemLibraries.models.Reader;
import com.example.SystemLibraries.models.Subscription;
import com.example.SystemLibraries.services.ReaderService;
import com.example.SystemLibraries.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/rest/reader")
public class ReaderRestController {
    @Autowired
    public ReaderService readerService;
    @Autowired
    public UserService userService;
    @GetMapping("/get-all")
    public List<Reader> getAllReader(){
        return readerService.getAllReaders();
    }
    @GetMapping("/get-all/{id}")
    public List<Reader> getAllReader(@PathVariable Long id){
        return readerService.getAllReadersByLibId(id);
    }
    @GetMapping("/get-all-by-subs/{id}")
    public List<Reader> getAllSubscriptionReaders(@PathVariable Long id){
        return readerService.getAllReadersBySubsId(id);
    }
    @GetMapping("/get-all-subs/{id}")
    public List<Subscription> getAllSubsReader(@PathVariable Long id){
        return readerService.getAllSubsByReaderId(id);
    }
    @GetMapping("/get-by-while_id/{id}")
    public Reader getReaderByWhileId(@PathVariable Long id, @RequestBody Subscription subsId){
        return readerService.getReaderByWhileId(id, subsId);
    }
    @PostMapping("/save")
    public Reader save(@RequestBody Reader genre){
        return readerService.save(genre);
    }
    @GetMapping("/get/{id}")
    public List<Reader> getReaderById(@PathVariable Long id){
        return readerService.getReader(id);
    }
    @GetMapping("/get-by-email/{id}")
    public List<Reader> getReaderByEmail(@PathVariable Long id){
        return userService.getReadersById(id);
    }

    //@DeleteMapping("/delete/{id}")
    //public void delete(@PathVariable Long id){
    //    publHouseService.deleteById(id);
    //}
}
