package com.example.SystemLibraries.formModels;

import com.example.SystemLibraries.models.HistoryReader;
import lombok.Data;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
@Data
public class HRDetails {
    private Long id;
    private LocalDate dateIssue;
    private LocalDate dateReturn;
    private boolean relevance;
    private boolean isCanBeExtended;
    private String invNumber;
    private String bookName;
    private String publHouseName;
    private String libName;

    public HRDetails(HistoryReader hr){
        id = hr.getId();
        dateIssue = hr.getDateIssue();
        dateReturn = hr.getDateReturn();
        relevance = hr.isRelevance();
        isCanBeExtended = ChronoUnit.MONTHS.between(hr.getDateIssue(), hr.getDateReturn()) < 5;
        invNumber = hr.getCopyBook().getInvNumber();
        bookName = hr.getCopyBook().getEdition().getBook().getName();
        publHouseName = hr.getCopyBook().getEdition().getPublHouse().getName();
        libName = hr.getCopyBook().getDepartment().getLibrary().getName();
    }
}
