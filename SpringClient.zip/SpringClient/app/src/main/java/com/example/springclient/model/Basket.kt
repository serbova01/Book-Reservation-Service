package com.example.springclient.model

class Basket() {
    var id = 0L
    var favorite = true
    var count = 0
    var libId = 0L
    var usId = 0L
    var edId = 0L
    var library:Library? = null
    var user:User? = null
    lateinit var edition:Edition
    var subsId = 0L

    var maxCountCopies = 0
    var isSelected = false

    constructor(id:Long, favorite:Boolean, count:Int, libId:Long, usId: Long, edId: Long):this(){
        this.id = id
        this.favorite = favorite
        this.count = count
        this.libId = libId
        this.edId = edId
        this.usId = usId
    }

    constructor(id:Long, favorite:Boolean, count:Int, library:Library, user:User,
                edition: Edition):this(){
        this.id = id
        this.favorite = favorite
        this.count = count
        if(library != null){
            this.library = library
            this.libId = library.id
        }
        this.edition = edition
        this.edId = edition.id
        this.user = user
        this.usId = user.id
    }
    constructor(id:Long, favorite:Boolean, count:Int, user:User,
                edition: Edition):this(){
        this.id = id
        this.favorite = favorite
        this.count = count
        this.edition = edition
        this.edId = edition.id
        this.user = user
        this.usId = user.id
    }
}