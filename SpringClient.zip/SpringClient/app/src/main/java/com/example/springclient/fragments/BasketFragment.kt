package com.example.springclient.fragments

import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.AppCompatButton
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.springclient.CheckConNetwork
import com.example.springclient.R
import com.example.springclient.adapters.ItemBasketAdapter
import com.example.springclient.adapters.ItemBasketRequestAdapter
import com.example.springclient.adapters.ItemBasketReservAdapter
import com.example.springclient.controllers.RequestActivity
import com.example.springclient.controllers.ReservBasketActivity
import com.example.springclient.controllers.ViewEditionActivity
import com.example.springclient.databinding.FragmentMainFormBasketBinding
import com.example.springclient.databinding.FragmentReservListBasketBinding
import com.example.springclient.model.*
import com.example.springclient.reotrifit.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class BasketFragment : Fragment() {
    lateinit var binding: FragmentMainFormBasketBinding
    private lateinit var retrofit: RetrofitService
    private lateinit var mDBHelper: WorkLocalDB
    private lateinit var mSettings: SharedPreferences

    var userId = 0L
    lateinit var token:String
    lateinit var user: User
    lateinit var baskets:List<Basket>
    lateinit var basketsReservs:ArrayList<Basket>
    lateinit var basketsRequests:ArrayList<Basket>
    lateinit var selBasketsForReserv:ArrayList<Basket>
    lateinit var selBasketsForDel:ArrayList<Basket>
    lateinit var libraries:List<ViewLibWithEd>
    var countReservs = 0

    //lateinit var itemBasketAdapter:ItemBasketAdapter
    lateinit var itemBasketReservAdapter:ItemBasketReservAdapter
    lateinit var itemBasketRequestAdapter:ItemBasketRequestAdapter

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        init()
    }

    private fun init() {
        binding.rlFrBasketChoose.visibility = LinearLayout.INVISIBLE
        binding.tvFrBasketNoList.visibility = TextView.GONE
        binding.rvFrBasketForReserv.setHasFixedSize(true)
        binding.rvFrBasketForReserv.layoutManager = LinearLayoutManager(requireView().context)
        binding.rvFrBasketForRequest.setHasFixedSize(true)
        binding.rvFrBasketForRequest.layoutManager = LinearLayoutManager(requireView().context)
        binding.btnFrBasketReservationList.setOnClickListener(){onReservList()}
        binding.tvFrBasketDeleteChoosed.setOnClickListener(){onDeleteChooseds()}
        binding.cbFrBasketChooseAll.text = getString(R.string.chooseAll)
        binding.cbFrBasketChooseAll.setOnClickListener(){
            onChooseAll(binding.cbFrBasketChooseAll.isChecked)}
        binding.srlFrBasket.setOnRefreshListener {
            initData()
        }
        initData()
    }

    private fun onChooseAll(isChecked: Boolean) {
        selBasketsForReserv.clear()
        selBasketsForDel.clear()
        if(isChecked){
            binding.tvFrBasketDeleteChoosed.visibility = TextView.VISIBLE
            baskets.forEach { basket -> basket.isSelected = true;
                if(basket.maxCountCopies>0){selBasketsForReserv.add(basket)};
                selBasketsForDel.add(basket)}
        }else{
            binding.tvFrBasketDeleteChoosed.visibility = TextView.INVISIBLE
            baskets.forEach { basket -> basket.isSelected = false }
        }
        setAdapters()
    }

    private fun onDeleteChooseds() {
        if(selBasketsForDel.isNotEmpty()){
            var basketApi = retrofit.retrofit.create(BasketApi::class.java)
            basketApi.deleteBasket(token, getStrIds(selBasketsForDel)).enqueue(object : Callback<Basket>{
                override fun onResponse(call: Call<Basket>, response: Response<Basket>) {
                    if(response.isSuccessful){
                        Toast.makeText(requireContext(), getString(R.string.deleteBasketsOK),
                            Toast.LENGTH_LONG).show()
                        initData()
                    }else
                        Toast.makeText(requireContext(), getString(R.string.deleteBasketsBad),
                            Toast.LENGTH_LONG).show()
                }

                override fun onFailure(call: Call<Basket>, t: Throwable) {
                    Toast.makeText(requireContext(), getString(R.string.deleteBasketsBad),
                        Toast.LENGTH_LONG).show()
                }

            })
        }
    }

    private fun getStrIds(list:ArrayList<Basket>): String {
        var str = ""
        for(basket in list){
            str+=basket.id.toString() + ", "
        }
        return str.removeRange(str.length-2, str.length)
    }

    private fun initData() {
        binding.btnFrBasketReservationList.visibility = AppCompatButton.GONE
        selBasketsForReserv = ArrayList()
        binding.srlFrBasket.isRefreshing = true
        mSettings = requireContext().getSharedPreferences("my_storage", Context.MODE_PRIVATE) as SharedPreferences
        val is_logged = mSettings!!.getBoolean("is_logged", false)
        token = mSettings!!.getString("token", "") as String
        if(is_logged && token.isNotEmpty()){
            if(CheckConNetwork().checkConnectivity(requireContext()) && mSettings!!.getBoolean("is_conServer", false)){
                userId = mSettings!!.getLong("userId", 0)
                if(userId > 0){
                    retrofit = RetrofitService()
                    setUser()
                }
            }else
                noCon()
        }else
            noList()
    }

    private fun noCon() {
        noList()
        binding.tvFrBasketNoList.text = getString(R.string.noConNetwork)
    }

    private fun setUser() {
        var userApi = retrofit.retrofit.create(UserSystemApi::class.java)
        userApi.get(token, userId).enqueue(object : Callback<User>{
            override fun onResponse(call: Call<User>, response: Response<User>) {
                if(response.isSuccessful){
                    user = response.body()!!
                    setBasket()
                }else{
                    Toast.makeText(requireContext(), "Не удалось получить данные о пользователе. " +
                            "Попробуйте позже.", Toast.LENGTH_LONG).show()
                    noList()
                }
            }

            override fun onFailure(call: Call<User>, t: Throwable) {
                Toast.makeText(requireContext(), "Не удалось получить данные о пользователе. " +
                        "Попробуйте позже.", Toast.LENGTH_LONG).show()
                noCon()
            }

        })
    }

    private fun noList() {
        binding.srlFrBasket.isRefreshing = false
        binding.nsvFrBasket.visibility = ScrollView.GONE
        binding.tvFrBasketNoList.visibility = TextView.VISIBLE
    }

    private fun setBasket() {
        var basketApi = retrofit.retrofit.create(BasketApi::class.java)
        basketApi.getAllBaskets(token, userId).enqueue(object : Callback<List<Basket>>{
            override fun onResponse(call: Call<List<Basket>>, response: Response<List<Basket>>) {
                if(response.isSuccessful || response.body()!!.isNotEmpty()){
                    baskets = response.body()!!
                    initListsBaskets()
                    initForm()
                }else
                    noList()
            }

            override fun onFailure(call: Call<List<Basket>>, t: Throwable) {
                Toast.makeText(requireContext(), "Не удалось закрузить 'Корзину'. Попробуйте позже.", Toast.LENGTH_LONG)
                noCon()
            }

        })
    }

    private fun initListsBaskets() {
        basketsReservs = ArrayList()
        basketsRequests = ArrayList()
        for(basket in baskets){
            if(basket.maxCountCopies >0){
                basketsReservs.add(basket)
            }else
                basketsRequests.add(basket)
        }
    }

    private fun initForm() {
        binding.rlFrBasketChoose.visibility = LinearLayout.VISIBLE
        selBasketsForReserv = ArrayList()
        selBasketsForDel = ArrayList()
        setAdapters()
        binding.srlFrBasket.isRefreshing = false
        binding.nsvFrBasket.visibility = ScrollView.VISIBLE
        binding.tvFrBasketNoList.visibility = TextView.GONE
    }
    private fun setAdapters(){
        initListsBaskets()
        itemBasketReservAdapter = ItemBasketReservAdapter(basketsReservs)
        itemBasketRequestAdapter = ItemBasketRequestAdapter(basketsRequests)
        setReservAdapter()
        setRequestsAdapter()
    }

    private fun setReservAdapter() {
        if(basketsReservs.isNotEmpty()){
            itemBasketReservAdapter.onItemClick={ item ->
                toEdition(item.edId)
            }
            itemBasketReservAdapter.onItemDelete = { item ->
                deleteBasket(item)
            }
            itemBasketReservAdapter.onItemSelected = { item, isChecked  ->
                selectedBasket(item, isChecked)
            }
            itemBasketReservAdapter.onItemReservation = { item ->
                reservationBasket(item)
            }
            itemBasketReservAdapter.onItemChoosedLib = { item ->
                showAlertChooseLib(item)
            }
            binding.rvFrBasketForReserv.adapter = itemBasketReservAdapter
            binding.rvFrBasketForReserv.visibility = LinearLayout.VISIBLE
        }else
            binding.rvFrBasketForReserv.visibility = LinearLayout.INVISIBLE
    }

    private fun setRequestsAdapter() {
        if(basketsRequests.isNotEmpty()){
            binding.tvFrBasketLibrary.visibility = TextView.VISIBLE
            itemBasketRequestAdapter.onItemClick={ item ->
                toEdition(item.edId)
            }
            itemBasketRequestAdapter.onItemCreatedReq = { item ->
                createRequest(item)
            }
            itemBasketRequestAdapter.onItemDelete = { item ->
                deleteBasket(item)
            }
            itemBasketRequestAdapter.onItemSelected = { item, isChecked  ->
                selectedBasket(item, isChecked)
            }
            itemBasketRequestAdapter.onItemChoosedLib = { item ->
                showAlertChooseLib(item)
            }
            binding.rvFrBasketForRequest.adapter = itemBasketRequestAdapter
            binding.llFrBasketForRequest.visibility = LinearLayout.VISIBLE
        }else
            binding.llFrBasketForRequest.visibility = LinearLayout.GONE
    }

    /*private fun setAdapter() {
        itemBasketAdapter = ItemBasketAdapter(baskets)
        itemBasketAdapter.onItemClick={ item ->
            toEdition(item.edId)
        }
        itemBasketAdapter.onItemCreatedReq = { item ->
            createRequest(item)
        }
        itemBasketAdapter.onItemDelete = { item ->
            deleteBasket(item)
        }
        itemBasketAdapter.onItemSelected = { item, isChecked  ->
            selectedBasket(item, isChecked)
        }
        itemBasketAdapter.onItemReservation = { item ->
            reservationBasket(item)
        }
        itemBasketAdapter.onItemChoosedLib = { item ->
            showAlertChooseLib(item)
        }
        binding.rvFrBasket.adapter = itemBasketAdapter
    }*/

    private fun reservationBasket(basket: Basket) {
        checkDelayedsBooksForOneReserv(basket)
    }

    private fun onReservList() {

        if(selBasketsForReserv.isNotEmpty()){
            if(checkAvailableLib()){
                //checkSubsCount()
                checkDelayedsBooksForListReserv()
                //toReservView()
            }else
                showAlert("Не у всех изданий выбрана библиотека, в которой она будет забронирована.")
        }
    }

    private fun checkDelayedsBooksForListReserv() {
        var historyRApi = retrofit.retrofit.create(HistroryRApi::class.java)
        historyRApi.getDelayedsByUser(token, user.id).enqueue(object : Callback<List<HistoryReader>>{
            override fun onResponse(
                call: Call<List<HistoryReader>>,
                response: Response<List<HistoryReader>>
            ) {
                if(response.isSuccessful){
                    var flag = response.body()!!.isNotEmpty()
                    if(response.body()!!.isNotEmpty()){
                        for(delayed in response.body()!!){
                            if(selBasketsForReserv.any { basket ->
                                    basket.libId == delayed.libId
                                }){
                                flag = true
                                var basket = selBasketsForReserv.first{ basket ->
                                    basket.libId == delayed.libId }
                                showAlert("Вы задержали книги в " + basket.library!!.name +
                                        " поэтому Вы не можете забронировать книги в этой библиотеке.")
                                break
                            }
                        }
                    }
                    if(!flag)
                        toReservView(getListIds())
                }else
                    showAlert("Не удалось получить данные о задержанных книгах.")
            }

            override fun onFailure(call: Call<List<HistoryReader>>, t: Throwable) {
                showAlert("Не удалось получить данные о задержанных книгах.")
            }

        })
    }
    private fun checkDelayedsBooksForOneReserv(basket: Basket) {
        var historyRApi = retrofit.retrofit.create(HistroryRApi::class.java)
        historyRApi.getDelayedsByUser(token, user.id).enqueue(object : Callback<List<HistoryReader>>{
            override fun onResponse(
                call: Call<List<HistoryReader>>,
                response: Response<List<HistoryReader>>
            ) {
                if(response.isSuccessful){
                    var flag = response.body()!!.isNotEmpty()
                    if(response.body()!!.isNotEmpty()){
                        for(delayed in response.body()!!){
                            if(basket.libId == delayed.libId){
                                flag = true
                                showAlert("Вы задержали книги в " + basket.library!!.name +
                                        " поэтому Вы не можете бронировать книги в этой библиотеке.")
                                break
                            }
                        }
                    }
                    if(!flag)
                        toReservView(Array(1){basket.id})
                }else
                    showAlert("Не удалось получить данные о задержанных книгах.")
            }

            override fun onFailure(call: Call<List<HistoryReader>>, t: Throwable) {
                showAlert("Не удалось получить данные о задержанных книгах.")
            }

        })
    }

    private fun getStrLibIds(): String {
        var str = ""
        for(basket in selBasketsForReserv){
            str+=basket.library!!.id.toString() + ", "
        }
        return str.removeRange(str.length-2, str.length)
    }

    private fun toReservView(list:Array<Long>) {
        val intent = Intent(context, ReservBasketActivity::class.java)
        intent.putExtra("ARRAYLIST", list)
        startActivity(intent)
    }

    private fun getListIds(): Array<Long> {
        var listIds = ArrayList<Long>()
        for(basket in selBasketsForReserv){
            listIds.add(basket.id)
        }
        return listIds.toTypedArray()
    }

    private fun showAlertChooseLib(basket: Basket) {
        var editionApi = retrofit.retrofit.create(EditionApi::class.java)
        editionApi.getLibsForReserv(token, basket.edition.id, user.id)
            .enqueue(object : Callback<List<ViewLibWithEd>>{
            override fun onResponse(
                call: Call<List<ViewLibWithEd>>,
                response: Response<List<ViewLibWithEd>>
            ) {
                if(response.isSuccessful){
                    if(response.body()!!.isNotEmpty()){
                        showAlertLibs(response.body()!!)
                    }else
                        Toast.makeText(requireContext(), "Ни в одной вашей библиотеке нет " +
                                "нужного издания.", Toast.LENGTH_LONG).show()
                }else
                    Toast.makeText(requireContext(), "Не удалось получить список библиотек, в " +
                            "которых можно забронировать издание. Попробуйте позже.",
                        Toast.LENGTH_LONG).show()
            }

            private fun showAlertLibs(list: List<ViewLibWithEd>) {
                var copyBasket = basket
                copyBasket.libId = list.get(0).library.id
                copyBasket.library = list.get(0).library
                var listStr:Array<String> = arrayOf()
                for(library in list){
                    var str = library.library.name + " " + library.library.address
                    listStr = listStr.plus(str)
                }
                val builder = AlertDialog.Builder(requireContext())
                builder.setTitle(getString(R.string.chooseLibrary))
                builder.setSingleChoiceItems(listStr, 0) { dialog, which ->
                    copyBasket.libId = list[which].library.id
                    copyBasket.library = list[which].library
                }
                // add OK and Cancel buttons
                builder.setPositiveButton("OK") { dialog, which ->
                    if(copyBasket.library != null)
                        saveBasket(copyBasket)
                    else
                        Toast.makeText(requireContext(), "Выберете библиотеку.",
                            Toast.LENGTH_LONG).show()
                }
                builder.setNegativeButton("Отмена", null)
                // create and show the alert dialog
                val dialog = builder.create()
                dialog.show()
            }

            override fun onFailure(call: Call<List<ViewLibWithEd>>, t: Throwable) {
                Toast.makeText(requireContext(), "Не удалось получить список библиотек, в которых " +
                        "можно забронировать издание. Попробуйте позже.", Toast.LENGTH_LONG)
            }

        })

    }

    private fun saveBasket(basket: Basket) {
        var item = Basket(basket.id, basket.favorite, basket.count, basket.libId, userId, basket.edId)
        var basketApi = retrofit.retrofit.create(BasketApi::class.java)
        basketApi.save(token, item).enqueue(object : Callback<Basket>{
            override fun onResponse(call: Call<Basket>, response: Response<Basket>) {
                if(response.isSuccessful){
                    var basketReturn = response.body()!!
                    if(basket.id == basketReturn.id){
                        updateBaskets(basketReturn)
                    }else
                        removeInBaskets(basket)
                    if(baskets.isEmpty())
                        noList()
                    //initForm()
                }else
                    Toast.makeText(requireContext(), "Не удалось сохранить изменения. Попробуйте позже.",
                        Toast.LENGTH_LONG).show()
            }

            private fun removeInBaskets(basket: Basket) {
                var list:ArrayList<Basket> = ArrayList()
                for(b in baskets){
                    if(b.id != basket.id)
                        list.add(b)
                }
                baskets = list
                initListsBaskets()
                updatesAdapters()
            }

            override fun onFailure(call: Call<Basket>, t: Throwable) {
                Toast.makeText(requireContext(), "Не удалось сохранить изменения. Попробуйте позже.",
                    Toast.LENGTH_LONG).show()
            }

        })
    }

    private fun updatesAdapters() {
        if(basketsReservs.isNotEmpty()){
            if(itemBasketReservAdapter.baskets.isNotEmpty()){
                binding.rvFrBasketForReserv.visibility = RecyclerView.VISIBLE
                itemBasketReservAdapter.updateBaskets(basketsReservs)
            }
            else
                setReservAdapter()
        }else
            binding.rvFrBasketForReserv.visibility = RecyclerView.GONE

        if(basketsRequests.isNotEmpty()){
            binding.llFrBasketForRequest.visibility = RecyclerView.VISIBLE
            if(itemBasketRequestAdapter.baskets.isNotEmpty())
                itemBasketRequestAdapter.updateBaskets(basketsRequests)
            else
                setRequestsAdapter()
        }else
            binding.llFrBasketForRequest.visibility = RecyclerView.GONE
    }


    private fun checkAvailableLib(): Boolean {
        for(lib in selBasketsForReserv){
            if(lib.libId == 0L)
                return false
        }
        return true
    }

    private fun selectedBasket(basket: Basket, isChecked:Boolean) {
        if (isChecked){
            if (!selBasketsForReserv.contains(basket) && basket.maxCountCopies>0)
                selBasketsForReserv.add(basket)
            if (!selBasketsForDel.contains(basket))
                selBasketsForDel.add(basket)
        }else{
            if (selBasketsForReserv.contains(basket)&& basket.maxCountCopies>0)
                selBasketsForReserv.remove(basket)
            if (selBasketsForDel.contains(basket))
                selBasketsForDel.remove(basket)
        }
        if (selBasketsForReserv.isNotEmpty()){
            binding.btnFrBasketReservationList.visibility = AppCompatButton.VISIBLE
            binding.rlFrBasketChoose.visibility = RelativeLayout.VISIBLE
        }
        else{
            binding.btnFrBasketReservationList.visibility = AppCompatButton.GONE
            binding.rlFrBasketChoose.visibility = RelativeLayout.GONE
        }
        if (selBasketsForDel.isNotEmpty()){
            binding.tvFrBasketDeleteChoosed.visibility = TextView.VISIBLE
            binding.rlFrBasketChoose.visibility = RelativeLayout.VISIBLE
        }
        else{
            binding.tvFrBasketDeleteChoosed.visibility = TextView.INVISIBLE
            binding.rlFrBasketChoose.visibility = RelativeLayout.GONE
        }
    }


    private fun showAlert(str: String) {
        val builder = AlertDialog.Builder(requireContext())
        builder.setPositiveButton("OK", DialogInterface.OnClickListener { dialog, which ->
            dialog.cancel()
        })
        builder.setMessage(str)
        builder.show()
    }

    private fun updateBaskets(basket: Basket) {
        var list:ArrayList<Basket> = ArrayList()
        for(b in baskets){
            if(b.id == basket.id)
                list.add(basket)
            else
                list.add(b)
        }
        baskets = list
        initListsBaskets()
        itemBasketRequestAdapter.updateBaskets(basketsRequests)
        itemBasketReservAdapter.updateBaskets(basketsReservs)
    }

    private fun deleteBasket(basket: Basket) {
        binding.srlFrBasket.isRefreshing = true
        var basketApi = retrofit.retrofit.create(BasketApi::class.java)
        basketApi.deleteBasket(token, basket.id).enqueue(object : Callback<Basket>{
            override fun onResponse(call: Call<Basket>, response: Response<Basket>) {
                if(response.isSuccessful){
                    removeInBaskets(basket)
                    if(baskets.isEmpty())
                        noList()
                    else
                        setAdapters()
                }else{
                    showAlert("Не удалось удалить запись из 'Корзины'. Попробуйте позже.")
                }
                binding.srlFrBasket.isRefreshing = false
            }

            private fun removeInBaskets(basket: Basket) {
                var list = ArrayList<Basket>()
                for(b in baskets){
                    if(b.id != basket.id)
                        list.add(b)
                }
                baskets = list
            }

            override fun onFailure(call: Call<Basket>, t: Throwable) {
                binding.srlFrBasket.isRefreshing = false
                showAlert("Не удаллось удалить запись из 'Корзины'. Попробуйте позже.")
            }

        })
    }

    private fun createRequest(basket: Basket) {
        val intent = Intent(requireContext(), RequestActivity::class.java)
        intent.putExtra("edId", basket.edition.id)
        startActivity(intent)
    }

    private fun toEdition(edId:Long) {
        val intent = Intent(context, ViewEditionActivity::class.java)
        intent.putExtra("edId", edId)
        startActivity(intent)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        requireActivity().title = getString(R.string.basket)
        binding = FragmentMainFormBasketBinding.inflate(layoutInflater)

        return binding!!.root
    }

    companion object {
        @JvmStatic
        fun newInstance() = BasketFragment()
    }
}