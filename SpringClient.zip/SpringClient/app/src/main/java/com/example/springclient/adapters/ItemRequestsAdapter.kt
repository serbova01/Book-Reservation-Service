package com.example.springclient.adapters

import android.graphics.BitmapFactory
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.widget.AppCompatButton
import androidx.recyclerview.widget.RecyclerView
import com.example.springclient.R
import com.example.springclient.model.Basket
import com.example.springclient.model.Request

class ItemRequestsAdapter(var requests: List<Request>, var conServer:Boolean) :
    RecyclerView.Adapter<ItemRequestsAdapter.ItemRequestsViewHolder>(){
    var onItemClick: ((Request) -> Unit)? = null
    var onItemClickCancelReq: ((Request) -> Unit)? = null

    inner class ItemRequestsViewHolder(itemView: View): RecyclerView.ViewHolder(itemView){
        val imageView : ImageView = itemView.findViewById(R.id.iv_itemReq_imageEd)
        val textView_status : TextView = itemView.findViewById(R.id.tv_itemReq_status)
        val textView_title : TextView = itemView.findViewById(R.id.tv_itemReq_titleBook)
        val textView_text : TextView = itemView.findViewById(R.id.tv_itemReq_descriptionBook)
        val textView_libName : TextView = itemView.findViewById(R.id.tv_itemReq_libName)
        val textView_libAddress : TextView = itemView.findViewById(R.id.tv_itemReq_libAddress)
        val btn_delete: AppCompatButton = itemView.findViewById(R.id.btn_itemReq_cancel)
        init {
            itemView.setOnClickListener {
                onItemClick?.invoke(requests[adapterPosition])
            }
            if(conServer){
                btn_delete.setOnClickListener(){
                    if(conServer)
                        onItemClickCancelReq?.invoke(requests[adapterPosition])
                }
            }else{
                btn_delete.visibility = ImageButton.INVISIBLE
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemRequestsViewHolder {
        var view = LayoutInflater.from(parent.context).inflate(R.layout.item_requests, parent, false)

        return ItemRequestsViewHolder(view)
    }

    override fun onBindViewHolder(holder: ItemRequestsViewHolder, position: Int) {
        val item = requests[position]
        setImage(item.edition.setImage(), holder)
        holder.textView_title.text = item.edition.bookName
        holder.textView_text.text = item.edition.getShortText()
        holder.textView_libName.text = item.libName
        holder.textView_libAddress.text = item.libAddress
        holder.textView_status.text = item.status
        holder.btn_delete.setOnClickListener(){
            onItemClickCancelReq?.invoke(item)
        }
    }

    private fun setImage(byteArray: ByteArray, holder: ItemRequestsViewHolder) {
        if(byteArray.isNotEmpty()){
            val bmp = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.size)
            holder.imageView.setImageBitmap(bmp)
        }
    }

    override fun getItemCount(): Int {
        return requests.size
    }
}