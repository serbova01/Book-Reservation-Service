package com.example.springclient.fragments

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.springclient.R
import com.example.springclient.adapters.ItemLibBasketReservAdapter
import com.example.springclient.adapters.ItemLibReservsAdapter
import com.example.springclient.controllers.MainActivity
import com.example.springclient.controllers.ReservBasketActivity
import com.example.springclient.controllers.ViewEditionActivity
import com.example.springclient.databinding.FragmentReservListBasketBinding
import com.example.springclient.databinding.FragmentReservOneBasketBinding
import com.example.springclient.model.*
import com.example.springclient.reotrifit.ReservationApi
import com.example.springclient.reotrifit.RetrofitService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ReservListBasketFragment : Fragment() {
    lateinit var binding:FragmentReservListBasketBinding
    private lateinit var mSettings: SharedPreferences
    private lateinit var retrofit: RetrofitService

    lateinit var baskets: List<Basket>
    lateinit var libsForBaskets: ArrayList<ViewLibBasketReserv>
    lateinit var user: User
    var userId = 0L
    lateinit var token:String

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        baskets = (requireActivity() as ReservBasketActivity).listBasket
        user = (requireActivity() as ReservBasketActivity).user
        userId = (requireActivity() as ReservBasketActivity).userId
        token = (requireActivity() as ReservBasketActivity).token
        init()
    }

    private fun init() {
        setListLibs()
        binding.rvRListBasket.setHasFixedSize(true)
        binding.rvRListBasket.layoutManager = LinearLayoutManager(requireContext())
        binding.btnRListBasketReservation.setOnClickListener(){onReservation()}
        setAdapter()
    }

    private fun setAdapter() {
        var itemLibBasketReservAdapter  = ItemLibBasketReservAdapter(requireContext(), libsForBaskets)
        itemLibBasketReservAdapter.onItemClick = { item ->
            val intent = Intent(context, ViewEditionActivity::class.java)
            intent.putExtra("edId", item.edId)
            startActivity(intent)
        }
        itemLibBasketReservAdapter.onItemListEmpty = { item ->
            binding.nsvRListBasket.visibility = ScrollView.GONE
            binding.tvRListBasketListEmpty.visibility = TextView.VISIBLE
        }
        binding.rvRListBasket.adapter = itemLibBasketReservAdapter
    }

    private fun onReservation() {
        if(libsForBaskets.isNotEmpty()){
            retrofit = RetrofitService()
            var list:String = getListIds()
            var reservationApi = retrofit.retrofit.create(ReservationApi::class.java)
            reservationApi.add(token, list).enqueue(object : Callback<Reservation>{
                override fun onResponse(call: Call<Reservation>, response: Response<Reservation>) {
                    if(response.isSuccessful){
                        Toast.makeText(requireContext(), getString(R.string.reservListOk),
                            Toast.LENGTH_LONG).show()
                        backToBasket()
                    }else
                        Toast.makeText(requireContext(), getString(R.string.reservListBad),
                            Toast.LENGTH_LONG).show()
                }

                private fun backToBasket() {
                    val setIntent = Intent(requireContext(), MainActivity::class.java)
                    setIntent.putExtra("fragment", 'B')
                    startActivity(setIntent)
                }

                override fun onFailure(call: Call<Reservation>, t: Throwable) {
                    Toast.makeText(requireContext(), getString(R.string.reservListBad),
                        Toast.LENGTH_LONG).show()
                }

            })
        }
    }

    private fun getListIds(): String {
        var str = ""
        for (lib in libsForBaskets){
            for (basket in lib.list){
                str += basket.id.toString() + ", "
            }
        }
        return str.removeRange(str.length-2, str.length)
    }

    private fun setListLibs() {
        libsForBaskets = arrayListOf()
        for(reserv in baskets){
            if(libsForBaskets.findLast { libReserv -> libReserv.libName == reserv.library!!.name } != null){
                libsForBaskets.findLast { libReserv -> libReserv.libName == reserv.library!!.address }!!.list
                    .add(reserv)
            }else{
                var list = ArrayList<Basket>()
                list.add(reserv)
                libsForBaskets.add(ViewLibBasketReserv(reserv.library!!.name, reserv.library!!.address, list))
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentReservListBasketBinding.inflate(layoutInflater)
        return binding!!.root
    }

    companion object {
        @JvmStatic
        fun newInstance() = ReservListBasketFragment()
    }
}