package com.example.springclient.fragments

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.widget.AppCompatButton
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.springclient.CheckConNetwork
import com.example.springclient.R
import com.example.springclient.adapters.ItemProfileLibAdapter
import com.example.springclient.controllers.EditProfileActivity
import com.example.springclient.controllers.MainActivity
import com.example.springclient.databinding.FragmentEditProfileBinding
import com.example.springclient.model.Library
import com.example.springclient.model.Reader
import com.example.springclient.model.Subscription
import com.example.springclient.model.User
import com.example.springclient.reotrifit.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.logging.Level
import java.util.logging.Logger

class EditProfileFragment : Fragment() {
    lateinit var binding: FragmentEditProfileBinding
    private lateinit var mSettings: SharedPreferences
    private lateinit var mDBHelper: WorkLocalDB
    private lateinit var retrofit: RetrofitService

    var user:User = User()
    lateinit var token:String
    var subscriptions:List<Subscription> = ArrayList<Subscription>()
    var conServer:Boolean = false

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        init()
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun init() {
        (requireActivity() as EditProfileActivity).activeFr = "EP"
        binding.llFrEditProfile.visibility = LinearLayout.INVISIBLE
        binding.splFrEditProfile.isRefreshing = true
        binding.headerFrEditProfile.btnHeaderBack.visibility = ImageButton.VISIBLE
        binding.headerFrEditProfile.btnHeaderBack.setOnClickListener(){
            val intent = Intent(requireActivity(), MainActivity::class.java)
            intent.putExtra("fragment", 'P')
            startActivity(intent)
        }
        binding.rvFrEditProfile.layoutManager = LinearLayoutManager(requireView().context)
        binding.rvFrEditProfile.setHasFixedSize(true)
        binding.splFrEditProfile.setOnRefreshListener {
            initData()
        }
        binding.tvEditProfileEditDataUser.setOnClickListener(){
            (requireActivity() as EditProfileActivity).replaceFragment(EditUserFragment())
        }
        initData()
        //binding.etEditProfileEmail.text = user.email
        //binding.etEditProfileLogin.text = user.username
        //binding.headerFrEditProfile.btnFrProfileEditProfile.visibility = AppCompatButton.INVISIBLE


        //if (!conServer)
        //    binding.tvEditProfileEditDataUser.visibility = TextView.INVISIBLE
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun initData() {
        mSettings = requireContext().getSharedPreferences("my_storage", Context.MODE_PRIVATE) as SharedPreferences
        mDBHelper = WorkLocalDB(requireContext())
        val is_logged = mSettings.getBoolean("is_logged", false)
        token = mSettings.getString("token", "") as String
        if(is_logged && token.isNotEmpty()){
            if(CheckConNetwork().checkConnectivity(requireContext()) ){
                val userId = mSettings.getLong("userId", 0)
                if(userId > 0){
                    retrofit = RetrofitService()
                    setDataServer(userId)
                }
            }else{
                noConnectionServer()
            }
            //setAdapters()
            //binding.headerFrEditProfile.tvUser.text = user.username
        }
    }

    private fun setAdapters() {
        val itemProfileLibAdapter = ItemProfileLibAdapter(subscriptions, conServer)
        itemProfileLibAdapter.onEditClick = { item ->
            (requireActivity() as EditProfileActivity).replaceViewReaderFragment(item.id)
        }
        binding.rvFrEditProfile.adapter = itemProfileLibAdapter
    }

    private fun setDataServer(id: Long) {
        try{
            val userApi = retrofit.retrofit.create(UserSystemApi::class.java)
            userApi.get(token, id).enqueue(object : Callback<User> {
                override fun onResponse(call: Call<User>, response: Response<User>) {
                    if(response.isSuccessful){
                        user = response.body()!!
                        setLibraryForUser()
                    }else
                        noConnectionServer()
                }

                override fun onFailure(call: Call<User>, t: Throwable) {
                    Logger.getLogger(requireView().javaClass.name).log(Level.SEVERE, t.message)
                    Toast.makeText(requireContext(), "Ошибка при считывании данных пользователя!!",
                        Toast.LENGTH_SHORT).show()
                    noConnectionServer()

                }
            })
        }catch (ex: Exception){
            noConnectionServer()
        }
    }

    private fun setLibraryForUser() {
        if(user.libId>0){
            val libraryApi = retrofit.retrofit.create(LibraryApi::class.java)
            libraryApi.getLibrary(token, user.libId).enqueue(object : Callback<Library>{
                override fun onResponse(call: Call<Library>, response: Response<Library>) {
                    user.library = response.body()!!
                    getReader()
                }
                override fun onFailure(call: Call<Library>, t: Throwable) {
                    Toast.makeText(requireContext(), "Ошибка при считывании данных библиотеки!!",
                        Toast.LENGTH_SHORT).show()
                    noConnectionServer()
                }
            })
        }else
            getReader()
    }

    private fun setIsConServer(b: Boolean) {
        mSettings = requireContext().getSharedPreferences("my_storage", Context.MODE_PRIVATE) as SharedPreferences
        var editor = mSettings.edit()
        //editor.putBoolean("is_conServer", b).apply()
    }

    private fun noConnectionServer() {
        setDataLocalDB()
        initForm()
        conServer = false
        binding.splFrEditProfile.isRefreshing = false
        binding.tvEditProfileEditDataUser.visibility = TextView.INVISIBLE
        setIsConServer(false)
    }

    private fun initForm() {
        binding.headerFrEditProfile.tvUser.text = user.username
        binding.etEditProfileEmail.text = user.email
        binding.etEditProfileLogin.text = user.username
        binding.headerFrEditProfile.btnFrProfileEditProfile.visibility = AppCompatButton.INVISIBLE
        setAdapters()
        binding.splFrEditProfile.isRefreshing = false
        binding.llFrEditProfile.visibility = LinearLayout.VISIBLE
    }

    private fun getReader() {
        try{
            var readerApi = retrofit.retrofit.create(ReaderApi::class.java)
            readerApi.getAllReaderByEmail(token, user.id).enqueue(object : Callback<List<Reader>>{
                override fun onResponse(call: Call<List<Reader>>, response: Response<List<Reader>>
                ) {
                    if(response.isSuccessful){
                        getSubs(response.body()!!)
                    }
                    else
                        noConnectionServer()
                }

                override fun onFailure(call: Call<List<Reader>>, t: Throwable) {
                    Logger.getLogger(requireView().javaClass.name).log(Level.SEVERE, t.message)
                    Toast.makeText(requireContext(), "Ошибка при считывании данных читателя!!",
                        Toast.LENGTH_SHORT).show()
                    noConnectionServer()
                }
            })
        }catch(ex: Exception){
            noConnectionServer()
        }
    }

    private fun getSubs(body: List<Reader>){
        var readers = body
        var subscriptionApi = retrofit.retrofit.create(SubscriptionApi::class.java)
        try{
            var countLib = 0
            subscriptionApi.getAllSubscriptions(token, body.get(0).readerId.reader_id)
                .enqueue(object : Callback<List<Subscription>>{
                    @RequiresApi(Build.VERSION_CODES.O)
                    override fun onResponse(call: Call<List<Subscription>>,
                                            response: Response<List<Subscription>>
                    ) {
                        if(response.isSuccessful){
                            subscriptions = response.body()!!
                            var libraryApi = retrofit.retrofit.create(LibraryApi::class.java)
                            for(subs in subscriptions){
                                libraryApi.getLibrary(token, subs.libId)
                                    .enqueue(object : Callback<Library>{
                                        override fun onResponse(
                                            call: Call<Library>,
                                            response: Response<Library>
                                        ) {
                                            if(response.isSuccessful){
                                                subs.library = response.body()!!
                                                countLib++
                                            }
                                            if(countLib == subscriptions.size){
                                                updateDataLocalDB(subscriptions, readers)
                                                conServer = user.id != 0L
                                                initForm()
                                                setIsConServer(true)
                                                binding.splFrEditProfile.isRefreshing = false
                                            }
                                        }
                                        override fun onFailure(call: Call<Library>, t: Throwable) {
                                            Toast.makeText(requireContext(), "Ошибка при считывании данных библиотеки!!",
                                                Toast.LENGTH_SHORT).show()
                                        }

                                    })
                            }
                        }else
                            noConnectionServer()
                    }

                    override fun onFailure(call: Call<List<Subscription>>,
                                           t: Throwable) {
                        Logger.getLogger(requireView().javaClass.name).log(Level.SEVERE, t.message)
                        Toast.makeText(requireContext(), "Ошибка при считывании данных абонементов читателя!!",
                            Toast.LENGTH_SHORT).show()
                        noConnectionServer()
                    }

                })
        }catch(ex: Exception){
            noConnectionServer()
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun updateDataLocalDB(subscriptions: List<Subscription>, readers: List<Reader>) {
        var libraries = ArrayList<Library>()
        for(subs in subscriptions) {
            libraries.add(subs.library)
        }
        for(reader in readers){
            reader.readerId.subscription = subscriptions.first { subs -> subs.id == reader.subsId }
        }
        mDBHelper.updateLibraries(libraries)
        mDBHelper.subscriptions = subscriptions
        mDBHelper.readers = readers

        mDBHelper.setUser(user)
    }

    private fun setDataLocalDB() {
        mDBHelper = WorkLocalDB(requireView().context)
        user = mDBHelper.getUserWithServer()
        subscriptions = mDBHelper.subscriptions.toList()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        requireActivity().title = getString(R.string.editProfile)
        binding = FragmentEditProfileBinding.inflate(layoutInflater)
        return binding!!.root
    }

    companion object {
        @JvmStatic
        fun newInstance() =
            EditProfileFragment()
    }
}
