package com.example.springclient.model

class ViewLibBasketReserv(var libName:String, var libAddress:String, var list:ArrayList<Basket>) {
}