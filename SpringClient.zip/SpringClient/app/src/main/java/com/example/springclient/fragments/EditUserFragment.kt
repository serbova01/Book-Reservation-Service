package com.example.springclient.fragments

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.GridLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.AppCompatButton
import androidx.fragment.app.Fragment
import com.example.springclient.CheckConNetwork
import com.example.springclient.R
import com.example.springclient.controllers.EditProfileActivity
import com.example.springclient.controllers.LoginActivity
import com.example.springclient.databinding.FragmentEditUserBinding
import com.example.springclient.model.User
import com.example.springclient.reotrifit.*
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.logging.Level
import java.util.logging.Logger

class EditUserFragment : Fragment() {
    lateinit var binding: FragmentEditUserBinding
    private lateinit var mSettings: SharedPreferences
    private lateinit var mDBHelper: WorkLocalDB
    private lateinit var retrofit: RetrofitService

    var user: User = User()
    lateinit var token:String

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        init()
    }

    private fun init() {
        (requireActivity() as EditProfileActivity).activeFr = "EU"
        binding.cbEditIsEditPass.setOnClickListener(){onOpenPanelEditPass()}
        binding.headerFrEditUser.btnFrProfileEditProfile.visibility = AppCompatButton.INVISIBLE
        binding.btnFrEditUserSave.setOnClickListener(){onSaveData()}
        binding.headerFrEditUser.btnHeaderBack.setOnClickListener(){
            (requireActivity() as EditProfileActivity).activeFr = "EP"
            (requireActivity() as EditProfileActivity).replaceFragment(EditProfileFragment())
        }
        initData()
    }

    private fun initData() {
        mSettings = requireContext().getSharedPreferences("my_storage", Context.MODE_PRIVATE)
                as SharedPreferences
        val is_logged = mSettings!!.getBoolean("is_logged", false)
        token = mSettings!!.getString("token", "") as String
        if(is_logged && token.isNotEmpty()){
            if(CheckConNetwork().checkConnectivity(requireContext()) &&
                mSettings!!.getBoolean("is_conServer", false)){
                val userId = mSettings!!.getLong("userId", 0)
                if(userId > 0){
                    retrofit = RetrofitService()
                    setDataServer(userId)
                }
            }
        }
    }

    private fun setDataServer(id: Long) {
        mDBHelper = WorkLocalDB(requireContext())
        val userApi = retrofit.retrofit.create(UserSystemApi::class.java)
        userApi.get(token, id).enqueue(object : Callback<User> {
            override fun onResponse(call: Call<User>, response: Response<User>) {
                if(response.isSuccessful){
                    user = response.body()!!
                    binding.headerFrEditUser.tvUser.text = user.username
                    binding.user = user
                }
            }
            override fun onFailure(call: Call<User>, t: Throwable) {
                showAlert("Ошибка при считывании данных пользователя. Попробуйте позже.")
                (requireActivity() as EditProfileActivity).replaceFragment(EditProfileFragment())
            }

        })
    }

    private fun onSaveData() {
        if((!binding.cbEditIsEditPass.isChecked || checkPass()) && checkNullText()){
            val userApi = retrofit.retrofit.create(UserSystemApi::class.java)
            var new_user = setUserWithForm()
            userApi.save(new_user).enqueue(object : Callback<User> {
                override fun onResponse(call: Call<User>, response: Response<User>) {
                    if(response.isSuccessful){
                        mDBHelper = WorkLocalDB(requireContext())
                        mDBHelper.setUser(response.body()!!)
                        if (binding.cbEditIsEditPass.isChecked){
                            val intent = Intent(requireActivity(), LoginActivity::class.java)
                            startActivity(intent)
                        }else
                            (requireActivity() as EditProfileActivity).replaceFragment(EditProfileFragment())
                    }
                }

                override fun onFailure(call: Call<User>, t: Throwable) {
                    Toast.makeText(requireContext(),
                        "Ошибка при попытке сохранения данных пользователя. ", Toast.LENGTH_LONG)
                    Logger.getLogger(requireView().javaClass.name).log(Level.SEVERE, t.message)
                }

            })
        }
    }

    private fun checkNullText(): Boolean {
        if(binding.etFrEditUserLogin.text.isNotEmpty()){
            return true
        }else{
            binding.tilFrEditUserNewUsername.error = getString(R.string.canNotBeEmpty)
            return false
        }
    }

    private fun setUserWithForm(): User? {
        var newDataUser:User = User(user.id, binding.etFrEditUserLogin.text.toString(), user.authorize,
            user.password, user.email, user.role, user.libId)
        if(binding.cbEditIsEditPass.isChecked)
            newDataUser.password = binding.etFrEditUserNewPass.text.toString()
        return newDataUser
    }

    private fun checkPass(): Boolean {
        val passwordEncoder = BCryptPasswordEncoder()
        if(binding.etFrEditUserOldPass.text.isEmpty()){
            binding.tilFrEditUserOldPass.error = getString(R.string.canNotBeEmpty)
            return false
        }else{
            if(passwordEncoder.matches(binding.etFrEditUserOldPass.text.toString(), user.password)){
                if(binding.etFrEditUserNewPass.text.isEmpty()){
                    binding.tilFrEditUserNewPass.error = getString(R.string.canNotBeEmpty)
                    return false
                }
            }else{
                binding.tilFrEditUserOldPass.error = getString(R.string.oldPassNoEqualsThisPass)
                return false
            }
        }

        return true
    }

    private fun showAlert(str: String) {
        val builder = AlertDialog.Builder(requireContext())
        builder.setPositiveButton("OK") { dialog, which ->
            dialog.cancel()
        }
        builder.setMessage(str)
        builder.create()
    }

    private fun onOpenPanelEditPass() {
        if (binding.cbEditIsEditPass.isChecked){
            binding.lvFrEditUserChangePass.visibility = GridLayout.VISIBLE
        }else
            binding.lvFrEditUserChangePass.visibility = GridLayout.INVISIBLE
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        requireActivity().title = getString(R.string.editUser)
        binding = FragmentEditUserBinding.inflate(layoutInflater)
        return binding!!.root
    }

    companion object {
        @JvmStatic
        fun newInstance() =
            EditUserFragment()
    }
}