package com.example.springclient

import android.content.Context
import android.net.ConnectivityManager
import androidx.core.content.ContextCompat

public class CheckConNetwork() {
  public fun checkConnectivity(context: Context):Boolean{
   val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
   val activeNetwork = cm.activeNetworkInfo
   return activeNetwork != null && activeNetwork.isConnectedOrConnecting
  }
}