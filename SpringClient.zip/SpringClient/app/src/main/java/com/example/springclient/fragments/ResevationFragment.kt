package com.example.springclient.fragments

import android.content.Context
import android.content.DialogInterface
import android.content.SharedPreferences
import android.graphics.BitmapFactory
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.springclient.R
import com.example.springclient.adapters.ItemLibEditionAdapter
import com.example.springclient.adapters.ItemResevInLibAdapter
import com.example.springclient.controllers.ViewEditionActivity
import com.example.springclient.databinding.FragmentEditionBinding
import com.example.springclient.databinding.FragmentResevationBinding
import com.example.springclient.model.*
import com.example.springclient.reotrifit.EditionApi
import com.example.springclient.reotrifit.ReservationApi
import com.example.springclient.reotrifit.RetrofitService
import com.example.springclient.reotrifit.UserSystemApi
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.create

class ResevationFragment : Fragment() {
    //private lateinit var mSettings: SharedPreferences
    private lateinit var retrofit: RetrofitService
    lateinit var binding: FragmentResevationBinding

    lateinit var user: User
    var userId = 0L
    lateinit var edition: Edition
    lateinit var libsForReser:List<ViewLibWithEd>
    var library = Library()
    var count:Long = 1
    var maxCountCopies = 0L
    var subsId = 0L
    lateinit var token:String

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        init()
    }

    private fun init() {
        //mSettings = requireContext().getSharedPreferences("my_storage", Context.MODE_PRIVATE) as SharedPreferences
        retrofit = RetrofitService()

        user = (requireActivity() as ViewEditionActivity).user
        userId = (requireActivity() as ViewEditionActivity).userId
        edition = (requireActivity() as ViewEditionActivity).edition
        libsForReser = (requireActivity() as ViewEditionActivity).libsForReserv
        token = (requireActivity() as ViewEditionActivity).token

        initComp()
    }

    private fun initComp() {
        //binding.edition = edition
        //binding.count = count
        //binding.library = library
        binding.ibReservationMinusCount.setOnClickListener(){minusCount()}
        binding.ibReservationPlusCount.setOnClickListener(){plusCount()}
        binding.btnReservationReserv.setOnClickListener(){addReservation()}
        //binding.tvReservationCancel.setOnClickListener(){(requireActivity() as ViewEditionActivity).init()}
        initAdapter()
    }

    private fun initAdapter() {
        binding.rvReservation.setHasFixedSize(true)
        binding.rvReservation.layoutManager = LinearLayoutManager(requireContext())

        var itemLibWithEd = ItemResevInLibAdapter(libsForReser,user.id > 0L)
        itemLibWithEd.onItemClick = { view, checkBox ->
            if(checkBox.isChecked){
                library = view.library
                subsId = view.subsId
                maxCountCopies = view.count
                updateMaxCount()
                (requireActivity() as ViewEditionActivity).selectedLib = view
                libsForReser.filter { item -> item.library.id != view.library.id }.forEach{item ->
                    item.checked = false
                }
                setCountForm(view)
                binding.btnReservationReserv.isEnabled = view.availableDelayeds
                binding.ibReservationPlusCount.isEnabled = view.availableDelayeds
                binding.ibReservationMinusCount.isEnabled = view.availableDelayeds
                if(!view.availableDelayeds){
                    binding.tvReservationHaveDelayed.visibility = TextView.VISIBLE
                    binding.tvReservationMistake.visibility = TextView.INVISIBLE
                }else
                    binding.tvReservationHaveDelayed.visibility = TextView.INVISIBLE
            }else
                library = Library()
            libsForReser.first { item -> item.library.id == view.library.id }.checked = checkBox.isChecked
            initAdapter()
        }
        binding.rvReservation.adapter = itemLibWithEd
    }

    private fun setCountForm(view:ViewLibWithEd) {
        count = 1
        binding.count = count
        maxCountCopies = view.count
        updateMaxCount()
    }

    private fun addReservation() {
        if(library.id >0){
            var reservation = Reservation(edition, user, library)
            reservation.subsId = subsId
            var reservationApi = retrofit.retrofit.create(ReservationApi::class.java)
            reservationApi.add(token, reservation).enqueue(object : Callback<Reservation>{
                override fun onResponse(call: Call<Reservation>, response: Response<Reservation>) {
                    if(response.isSuccessful && response.body()!!.id > 0){
                        Toast.makeText(requireContext(), getString(R.string.reservOk), Toast.LENGTH_LONG).show()
                        (requireActivity() as ViewEditionActivity).init()
                    }
                }

                override fun onFailure(call: Call<Reservation>, t: Throwable) {
                    Toast.makeText(requireContext(), getString(R.string.reservBad), Toast.LENGTH_LONG).show()
                }

            })
        }else
            showAlert("Для бронирования книги нужно выбрать библиотеку.")
    }

    private fun showAlert(str: String) {
        val builder = AlertDialog.Builder(requireContext())
        builder.setPositiveButton("OK", DialogInterface.OnClickListener { dialog, which ->
            dialog.cancel()
        })
        builder.setMessage(str)
        builder.show()
    }

    private fun plusCount() {
        if(count <= maxCountCopies){
            binding.count = ++count
            if(count == maxCountCopies)
                binding.ibReservationPlusCount.isEnabled = false
            binding.ibReservationMinusCount.isEnabled = true
        }
    }

    private fun minusCount() {
        if(count > 1){
            binding.count = --count
            if(count == 1L)
                binding.ibReservationMinusCount.isEnabled = false
            binding.ibReservationPlusCount.isEnabled = true
        }
    }

    private fun updateMaxCount() {
        if(maxCountCopies == 1L){
            binding.ibReservationPlusCount.isEnabled = false
            binding.ibReservationMinusCount.isEnabled = false
            binding.tvReservationMistake.visibility = TextView.VISIBLE
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        requireActivity().title = getString(R.string.reservation_title)
        binding = FragmentResevationBinding.inflate(layoutInflater)
        return binding!!.root
    }

    companion object {
        @JvmStatic
        fun newInstance() = ResevationFragment()
    }
}