package com.example.springclient.model

class CodeConfim () {
    var email:String = ""
    var code:String = ""

    constructor(email:String):this(){
        this.email = email
    }
    constructor(email:String, code:String):this(){
        this.email = email
        this.code = code
    }
}