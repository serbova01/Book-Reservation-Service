package com.example.springclient.adapters

import android.graphics.BitmapFactory
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.widget.AppCompatButton
import androidx.recyclerview.widget.RecyclerView
import com.example.springclient.R
import com.example.springclient.model.Basket

class ItemBasketRequestAdapter (var baskets:List<Basket>):
    RecyclerView.Adapter<ItemBasketRequestAdapter.ItemBasketRequestViewHolder>(){
    var onItemDelete: ((Basket) -> Unit)? = null
    var onItemSelected: ((Basket, Boolean) -> Unit)? = null
    var onItemCreatedReq: ((Basket) -> Unit)? = null
    var onItemClick: ((Basket) -> Unit)? = null
    var onItemChoosedLib: ((Basket) -> Unit)? = null

    inner class ItemBasketRequestViewHolder(itemView: View): RecyclerView.ViewHolder(itemView){
        val imageView : ImageView = itemView.findViewById(R.id.iv_basketReq_imageItem)
        val tvTitle : TextView = itemView.findViewById(R.id.tv_basketReq_bookName)
        val tvText : TextView = itemView.findViewById(R.id.tv_basketReq_discription)
        val btnReq: AppCompatButton = itemView.findViewById(R.id.btn_basketReq_createReq)
        val checkBox: CheckBox = itemView.findViewById(R.id.cb_basketReq_isSelect)
        val btnDelete: ImageButton = itemView.findViewById(R.id.btn_basketReq_delete)
        val btnChooseLib: TextView = itemView.findViewById(R.id.btn_basketReq_chooseLib)
        init {
            imageView.setOnClickListener() {
                onItemClick?.invoke(baskets[adapterPosition])
            }
            tvTitle.setOnClickListener() {
                onItemClick?.invoke(baskets[adapterPosition])
            }
            btnReq.setOnClickListener(){
                onItemCreatedReq?.invoke(baskets[adapterPosition])
            }
            checkBox.setOnClickListener(){
                baskets[adapterPosition].isSelected = checkBox.isChecked
                onItemSelected?.invoke(baskets[adapterPosition], checkBox.isChecked)
            }
            btnDelete.setImageResource(R.drawable.ic_delete)
            btnChooseLib.setOnClickListener(){
                onItemChoosedLib?.invoke(baskets[adapterPosition])
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemBasketRequestViewHolder {
        var view = LayoutInflater.from(parent.context).inflate(R.layout.item_item_basket_req,
            parent, false)

        return ItemBasketRequestViewHolder(view)
    }

    override fun onBindViewHolder(holder: ItemBasketRequestViewHolder, position: Int) {
        var item = baskets[position]
        setImage(item.edition.setImage(), holder)
        //item.edition.image?.let { holder.imageView.setImageResource(it) }
        holder.tvTitle.text = item.edition.bookName
        holder.tvText.text = item.edition.bookAuthorStr
        holder.checkBox.isChecked = item.isSelected
        if(item.count > item.maxCountCopies){
            item.count = item.maxCountCopies
        }
        holder.btnDelete.setOnClickListener(){
            //basket.remove(item)
            //notifyItemRemoved(position)
            onItemDelete?.invoke(item)
        }
    }
    private fun setImage(byteArray: ByteArray, holder: ItemBasketRequestViewHolder) {
        if(byteArray.isNotEmpty()){
            val bmp = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.size)
            holder.imageView.setImageBitmap(bmp)
        }
    }

    override fun getItemCount(): Int {
        return baskets.size
    }

    fun updateBaskets(list: ArrayList<Basket>) {
        baskets = list
        notifyDataSetChanged()
    }
}