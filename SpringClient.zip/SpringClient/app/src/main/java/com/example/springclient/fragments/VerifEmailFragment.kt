package com.example.springclient.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.example.springclient.R
import com.example.springclient.controllers.LoginActivity
import com.example.springclient.databinding.FragmentVerifEmailBinding
import com.example.springclient.model.CodeConfim
import com.example.springclient.model.User
import com.example.springclient.reotrifit.RetrofitService
import com.example.springclient.reotrifit.UserSystemApi
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.create

class VerifEmailFragment : Fragment() {

    lateinit var binding: FragmentVerifEmailBinding

    private lateinit var retrofit: RetrofitService
    lateinit var user: User
    lateinit var code:String

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        init()
    }

    private fun init() {
        user = (activity as LoginActivity).user

        binding.tvVerEmailTitle.text = getString(R.string.ver_email) + " " + user.email
        binding.tvVerEmailSendCode.setOnClickListener(){sendCode()}
        binding.btnCheckCode.setOnClickListener(){checkCode()}
    }

    private fun checkCode() {
        if(code.equals(binding.etVerEmailCode.text.toString())){
            Toast.makeText(requireView().context, "Код совпадает!!", Toast.LENGTH_LONG).show()
            var userSystemApi = retrofit.retrofit.create(UserSystemApi::class.java)
            userSystemApi.registration(user).enqueue(object : Callback<User>{
                override fun onResponse(call: Call<User>, response: Response<User>) {
                    if(response.isSuccessful){
                        if(response.body()!!.id > 0)
                            (activity as LoginActivity).replaceFragment(LoginFragment())
                    }
                }

                override fun onFailure(call: Call<User>, t: Throwable) {
                    Toast.makeText(requireView().context, "Ошибка при регистрации!!",
                        Toast.LENGTH_LONG).show()
                }

            })
        }else{
            var builder = AlertDialog.Builder(requireView().context)
                        builder.setTitle(getString(R.string.confimCodeNoThisTitle))
                        builder.setMessage(getString((R.string.confimCodeNoThis)))
        }
    }

    private fun sendCode() {
        retrofit = RetrofitService()
        var codeConfim = CodeConfim(user.email)
        val userApi: UserSystemApi = retrofit.retrofit.create(
            UserSystemApi::class.java)
        userApi.code(codeConfim).enqueue(object : Callback<CodeConfim>{
            override fun onResponse(call: Call<CodeConfim>, response: Response<CodeConfim>) {
                setConfimCode(response.body()!!.code)
            }

            override fun onFailure(call: Call<CodeConfim>, t: Throwable) {
                Toast.makeText(requireView().context, "Ошибка при отправке кода подтверждения!!",
                    Toast.LENGTH_LONG).show()
            }

        })
    }

    private fun setConfimCode(body: String?) {
        binding.btnCheckCode.isEnabled = true
        code = body.toString()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentVerifEmailBinding.inflate(layoutInflater)
        // Inflate the layout for this fragment
        return binding!!.root
    }

    companion object {

        @JvmStatic
        fun newInstance() = VerifEmailFragment()
    }
}