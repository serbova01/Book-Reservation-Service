package com.example.springclient.controllers

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import androidx.fragment.app.Fragment
import com.example.springclient.R
import com.example.springclient.fragments.*
import com.example.springclient.model.Library
import com.example.springclient.model.Reader
import com.example.springclient.model.User
import com.yandex.mapkit.MapKitFactory

class EditProfileActivity : AppCompatActivity() {
    var editProfileFragment = EditProfileFragment()
    var editReaderFragment = EditReaderFragment()
    var viewReaderFragment = ViewReaderFragment()
    var historyReaderFragment = HistoryReaderFragment()
    var viewReaderMapFragment = ViewReaderMapFragment()

    var activeFr = ""

    lateinit var user: User
    lateinit var library: Library
    var subsId = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_profile)
        //MapKitFactory.setApiKey("f719a147-aaa9-4b70-bc20-0b571f3b6c7a")
        replaceFragment(editProfileFragment)
        activeFr = "EP"
        init()
    }

    fun init(){
    }

    fun replaceFragment(fragment: Fragment){
        if (fragment != null){
            val transaction = supportFragmentManager.beginTransaction()
            transaction.replace(R.id.fl_editProfile, fragment)
            transaction.commit()
        }
    }
    fun replaceFrMap(library : Library, user:User){
        viewReaderMapFragment.library = library
        viewReaderMapFragment.user = user
        viewReaderMapFragment.subsId = subsId
        activeFr = "VM"
        replaceFragment(viewReaderMapFragment)
    }

    fun replaceEditProfileFragment(reader:Reader) {
        editReaderFragment.reader = reader
        activeFr = "ER"
        replaceFragment(editReaderFragment)
    }

    fun replaceViewReaderFragment(id: Long) {
        activeFr = "VR"
        viewReaderFragment = ViewReaderFragment()
        viewReaderFragment.subsId=id
        subsId = id
        replaceFragment(viewReaderFragment)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle presses on the action bar menu items
        when (item.itemId) {
            android.R.id.home -> {
                this.onBackPressed()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onBackPressed() {
        when (activeFr){
            "EP" -> {
                val setIntent = Intent(this, MainActivity::class.java)
                setIntent.putExtra("fragment", 'P')
                startActivity(setIntent)
            }
            "ER" -> replaceViewReaderFragment(subsId)
            "EU" -> replaceFragment(editProfileFragment)
            "HR" -> replaceViewReaderFragment(subsId)
            "VM" -> replaceViewReaderFragment(subsId)
            "VR" -> replaceFragment(editProfileFragment)
        }
    }

}