package com.example.springclient.adapters

import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.AppCompatButton
import androidx.recyclerview.widget.RecyclerView
import com.example.springclient.R
import com.example.springclient.model.Basket
import com.example.springclient.model.Reservation
import com.example.springclient.model.ViewLibBasketReserv
import com.example.springclient.model.ViewLibWithEd

class ItemBasketResrvAdapter(var context: Context, private val list:List<Basket>) :
    RecyclerView.Adapter<ItemBasketResrvAdapter.ItemBasketResrvHolder>(){
    var onItemClick: ((Basket) -> Unit)? = null
    var onItemClickDelete: ((Basket) -> Unit)? = null

    inner class ItemBasketResrvHolder(itemView: View): RecyclerView.ViewHolder(itemView){
        val imageView : ImageView = itemView.findViewById(R.id.iv_reservationItem)
        val tv_title : TextView = itemView.findViewById(R.id.tv_reservItem_title)
        val tv_text : TextView = itemView.findViewById(R.id.tv_reservItem_content)
        val np_count : NumberPicker = itemView.findViewById(R.id.np_reservItem)
        val button:ImageButton = itemView.findViewById(R.id.btn_reservItem_delete)
        init {
            imageView.setOnClickListener {
                onItemClick?.invoke(list[adapterPosition])
            }
            tv_title.setOnClickListener {
                onItemClick?.invoke(list[adapterPosition])
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemBasketResrvHolder {
        var view = LayoutInflater.from(parent.context).inflate(R.layout.item_reserv_layout, parent, false)
        return ItemBasketResrvHolder(view)
    }

    override fun onBindViewHolder(holder: ItemBasketResrvHolder, position: Int) {
        val item = list[position]
        setImage(item.edition.setImage(), holder)
        holder.tv_title.text = item.edition.bookName
        holder.tv_text.text = item.edition.bookAuthorStr
        holder.np_count.value = item.count
        holder.np_count.maxValue = item.maxCountCopies
        holder.np_count.minValue = 1
        holder.button.setOnClickListener(){
            notifyItemRemoved(position)
            onItemClickDelete?.invoke(list[position])
        }
    }

    private fun createAlert(basket: Basket) {
        val alertDialog = AlertDialog.Builder(context)
        alertDialog.setTitle(R.string.deleteReservation)

        //alertDialog.setMessage(R.string.confimDeleteBasketReserv)
        alertDialog.setPositiveButton("Да"){dialog, id->
            //onItemClickDelete!!(basket)

        }
        alertDialog.setNegativeButton("Нет"){dialog, id->
            dialog.dismiss()
        }

        alertDialog.show()
    }

    private fun setImage(bytes: ByteArray, holder: ItemBasketResrvAdapter.ItemBasketResrvHolder) {
        if(bytes.isNotEmpty()){
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            holder.imageView.setImageBitmap(bmp)
        }
    }

    override fun getItemCount(): Int {
        return list.size
    }
}