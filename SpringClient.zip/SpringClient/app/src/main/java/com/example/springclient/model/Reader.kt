package com.example.springclient.model

import android.os.Build
import android.view.ViewParent
import androidx.annotation.RequiresApi
import java.time.LocalDate

class Reader (){
    var readerId = ReaderId(0L, Subscription())
    var subsId = 0L
    var lastName = ""
    var firstName = ""
    var secondName = ""
    var email = ""
    @RequiresApi(Build.VERSION_CODES.O)
    var dateRegistration:String = ""
    var phoneNumber = ""
    var address = ""
    var parentId:Long = 0
    lateinit var parent:Reader

    @RequiresApi(Build.VERSION_CODES.O)
    constructor(readerId:ReaderId, lastName:String, firstName:String, secondName:String, email:String,
                phoneNumber:String, address:String, dateRegistration:String, parent: Reader):this(){
        this.readerId = readerId
        this.lastName = lastName
        this.firstName = firstName
        this.secondName = secondName
        this.email = email
        this.dateRegistration = dateRegistration
        this.phoneNumber = phoneNumber
        this.address = address
        this.parent = parent
        this.parentId = parent.readerId.reader_id
        this.subsId = readerId.subscription.id
                }

    @RequiresApi(Build.VERSION_CODES.O)
    constructor(readerId:ReaderId, lastName:String, firstName:String, secondName:String, email:String,
                phoneNumber:String, address:String, dateRegistration:String):this(){
        this.readerId = readerId
        this.lastName = lastName
        this.firstName = firstName
        this.secondName = secondName
        this.email = email
        this.dateRegistration = dateRegistration
        this.phoneNumber = phoneNumber
        this.address = address
        this.subsId = readerId.subscription.id
    }

}

class ReaderId (reader_id:Long, subsId:Long){
    var reader_id = reader_id
    var subsId = subsId
    var subscription = Subscription()

    constructor(reader_id:Long, subscription:Subscription):this(reader_id, subscription.id){
        this.subscription = subscription
    }
}
