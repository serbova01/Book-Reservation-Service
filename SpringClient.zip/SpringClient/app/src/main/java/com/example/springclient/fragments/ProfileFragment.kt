package com.example.springclient.fragments

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.widget.AppCompatButton
import com.example.springclient.CheckConNetwork
import com.example.springclient.controllers.EditProfileActivity
import com.example.springclient.R
import com.example.springclient.controllers.LoginActivity
import com.example.springclient.controllers.ProfilePanelActivity
import com.example.springclient.databinding.FragmentMainFormProfileBinding
import com.example.springclient.model.Library
import com.example.springclient.model.User
import com.example.springclient.reotrifit.LibraryApi
import com.example.springclient.reotrifit.RetrofitService
import com.example.springclient.reotrifit.UserSystemApi
import com.example.springclient.reotrifit.WorkLocalDB
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.Serializable
import java.util.logging.Level
import java.util.logging.Logger

class ProfileFragment : Fragment() {
    private lateinit var mSettings: SharedPreferences
    private lateinit var mDBHelper: WorkLocalDB
    private lateinit var retrofit: RetrofitService

    lateinit var binding: FragmentMainFormProfileBinding
    var user: User = User()
    lateinit var token:String
    var conServer = false

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        init(view)
    }

    private fun init(view: View) {
        mDBHelper = WorkLocalDB(requireView().context)
        binding.tvFrProfileAuthorize.setOnClickListener(){ onPageAuth() }
        binding.headerFrProfile.btnFrProfileEditProfile.setOnClickListener(){onEditProfile()}
        binding.headerFrProfile.btnHeaderBack.visibility = ImageButton.GONE
        binding.btnFrProfileExit.setOnClickListener({onExitProfile()})

        binding.tvFrProfileFavorites.setOnClickListener(){goToList(ProfilePanelActivity.Lists.FAVORITES)}
        binding.tvFrProfileRequest.setOnClickListener(){goToList(ProfilePanelActivity.Lists.REQUESTS)}
        binding.tvFrProfileReservation.setOnClickListener(){goToList(ProfilePanelActivity.Lists.RESERVATIONS)}
        binding.tvFrProfileHistoryReader.setOnClickListener(){goToList(ProfilePanelActivity.Lists.ISSUEDS)}

        binding.splFrProfile.setOnRefreshListener {
            initData()
        }
        initData()
    }

    private fun goToList(lists: ProfilePanelActivity.Lists) {
        val intent = Intent(requireActivity(), ProfilePanelActivity::class.java)
        intent.putExtra("list", lists as Serializable)
        startActivity(intent)
    }

    private fun initData() {
        mSettings = requireContext().getSharedPreferences("my_storage", Context.MODE_PRIVATE) as SharedPreferences
        val is_logged = mSettings!!.getBoolean("is_logged", false)
        token = mSettings!!.getString("token", "") as String
        if(is_logged && token.isNotEmpty()) {
            if(CheckConNetwork().checkConnectivity(requireContext()) && mSettings!!.getBoolean("is_conServer", false)){
                var userId = mSettings!!.getLong("userId", 0)
                if(userId > 0){
                    retrofit = RetrofitService()
                    setUserServer(userId)
                }
            }else{
                getUserLocalDB()
            }
        }else
            noAction()
    }

    private fun onExitProfile() {
        var editor = mSettings.edit()
        editor.putBoolean("is_logged", false).apply()
        editor.putString("token", "").apply()
        editor.putLong("userId", 0).apply()
        onPageAuth()
    }

    private fun onEditProfile() {
        val intent = Intent(requireActivity(), EditProfileActivity::class.java)
        startActivity(intent)
    }

    private fun setUserServer(id:Long) {
        binding.splFrProfile.isRefreshing = true
        try{
            val userApi = retrofit.retrofit.create(UserSystemApi::class.java)
            userApi.get(token, id).enqueue(object : Callback<User>{
                override fun onResponse(call: Call<User>, response: Response<User>) {
                    if(response.isSuccessful){
                        user = response.body()!!
                        if(user.libId >0){
                            val libraryApi = retrofit.retrofit.create(LibraryApi::class.java)
                            libraryApi.getLibrary(token, user.libId).enqueue(object : Callback<Library>{
                                override fun onResponse(
                                    call: Call<Library>,
                                    response: Response<Library>
                                ) {
                                    if(response.isSuccessful){
                                        user.library = response.body()!!
                                        setUserLocalDB()
                                        conServer = false
                                        initForm()
                                    }
                                }

                                override fun onFailure(call: Call<Library>, t: Throwable) {
                                    Toast.makeText(requireContext(), "Ошибка при считывании данных библиотеки!!",
                                        Toast.LENGTH_SHORT).show()
                                }

                            })
                        }else{
                            setUserLocalDB()
                            initForm()
                        }
                    }else{
                        getUserLocalDB()
                        initForm()
                    }
                }

                override fun onFailure(call: Call<User>, t: Throwable) {
                    Logger.getLogger(requireView().javaClass.name).log(Level.SEVERE, t.message)
                    Toast.makeText(requireContext(), "Ошибка при считывании данных пользователя!!",
                        Toast.LENGTH_SHORT).show()
                    getUserLocalDB()
                    initForm()
                }

            })
        }catch(ex:Exception){
            getUserLocalDB()
            initForm()
        }
    }

    private fun initForm() {
        if(conServer)
            binding.btnFrProfileExit.visibility = AppCompatButton.INVISIBLE
        else
            binding.btnFrProfileExit.visibility = AppCompatButton.VISIBLE
        binding.headerFrProfile.tvUser.text = user.username
        binding.splFrProfile.isRefreshing = false
    }

    private fun setUserLocalDB() {
        mDBHelper.setUser(user)
    }

    private fun getUserLocalDB() {
        conServer = false
        user = mDBHelper.getUserWithServer()
        binding.headerFrProfile.tvUser.text = user.username
    }

    private fun noAction() {
        binding.tvFrProfileAuthorize.visibility = TextView.VISIBLE
        binding.btnFrProfileExit.visibility = AppCompatButton.INVISIBLE
        binding.headerFrProfile.btnFrProfileEditProfile.visibility = AppCompatButton.INVISIBLE
        binding.tvFrProfileRequest.isEnabled = false
        binding.tvFrProfileReservation.isEnabled = false
        binding.tvFrProfileHistoryReader.isEnabled = false
        binding.tvFrProfileFavorites.isEnabled = false
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        requireActivity().title = getString(R.string.profile)
        binding = FragmentMainFormProfileBinding.inflate(layoutInflater)
        return binding!!.root
        //return inflater.inflate(R.layout.fragment_main_form_profile, container, false)
    }

    companion object {
        @JvmStatic
        fun newInstance() = ProfileFragment()
    }

    fun onPageAuth() {
        val intent = Intent(requireActivity(), LoginActivity::class.java)
        startActivity(intent)
    }
}