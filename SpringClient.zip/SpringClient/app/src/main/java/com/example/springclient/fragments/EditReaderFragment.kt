package com.example.springclient.fragments

import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.AppCompatButton
import com.example.springclient.CheckConNetwork
import com.example.springclient.R
import com.example.springclient.controllers.EditProfileActivity
import com.example.springclient.controllers.MainActivity
import com.example.springclient.databinding.FragmentEditReaderBinding
import com.example.springclient.model.Reader
import com.example.springclient.model.User
import com.example.springclient.reotrifit.ReaderApi
import com.example.springclient.reotrifit.RetrofitService
import com.example.springclient.reotrifit.UserSystemApi
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class EditReaderFragment : Fragment() {
    lateinit var binding: FragmentEditReaderBinding
    private lateinit var mSettings: SharedPreferences
    private lateinit var retrofit: RetrofitService

    var user: User = User()
    lateinit var reader:Reader
    lateinit var token:String


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        init()
    }

    private fun init() {
        (requireActivity() as EditProfileActivity).activeFr = "ER"
        (requireActivity() as EditProfileActivity).subsId = reader.readerId.subsId
        binding.headerFrEditReader.btnHeaderBack.setOnClickListener(){
            (requireActivity() as EditProfileActivity).subsId = reader.readerId.subsId
            (requireActivity() as EditProfileActivity).activeFr = "VR"
            (requireActivity() as EditProfileActivity).replaceViewReaderFragment(reader.subsId)
        }
        binding.headerFrEditReader.btnFrProfileEditProfile.visibility = AppCompatButton.INVISIBLE
        binding.btnFrEditReaderSave.setOnClickListener(){onSaveReader()}
        initData()
    }

    private fun onSaveReader() {
        if(checkNull()){
            setReaderWithForm()
            val readerApi = retrofit.retrofit.create(ReaderApi::class.java)
            readerApi.save(token, reader).enqueue(object : Callback<Reader>{
                override fun onResponse(call: Call<Reader>, response: Response<Reader>) {
                    if(response.isSuccessful){
                        (requireActivity() as EditProfileActivity).replaceViewReaderFragment(reader.subsId)
                    }else
                        showAlert("Ошибка при сохранении данных читателя. Попробуйте позже.")
                }

                override fun onFailure(call: Call<Reader>, t: Throwable) {
                    showAlert("Ошибка при сохранении данных читателя. Попробуйте позже.")
                }

            })
        }
    }

    private fun checkNull(): Boolean {
        if(binding.etFrEditReaderFirstname.text.isNotEmpty()){
            if(binding.etFrEditReaderSecondName.text.isNotEmpty()){
                if(binding.etFrEditReaderStreet.text.isNotEmpty()){
                    if(binding.etFrEditReaderHouse.text.isNotEmpty()){
                        if(binding.etFrEditReaderHouse.text.isEmpty()){
                            binding.tilFrEditReaderPhoneNumber.error = getString(R.string.canNotBeEmpty)
                            return false
                        }
                    }else{
                        binding.etFrEditReaderHouse.error = getString(R.string.canNotBeEmpty)
                        return false
                    }
                }else{
                    binding.tilFrEditReaderStreet.error = getString(R.string.canNotBeEmpty)
                    return false
                }
            }else{
                binding.tilFrEditReaderSecondName.error = getString(R.string.canNotBeEmpty)
                return false
            }
        }else{
            binding.tilFrEditReaderFirstname.error = getString(R.string.canNotBeEmpty)
            return false
        }
        return true
    }

    private fun setReaderWithForm(){
        var newAddress:String = binding.etFrEditReaderStreet.text.toString() + ", "
        newAddress += binding.etFrEditReaderHouse.text.toString()
        if(binding.etFrEditReaderFlat.text.isNotEmpty())
            newAddress += ", " + binding.etFrEditReaderFlat.text.toString()

        reader.firstName = binding.etFrEditReaderFirstname.text.toString()
        reader.secondName = binding.etFrEditReaderSecondName.text.toString()
        reader.lastName = binding.etFrEditReaderLastName.text.toString()
        reader.phoneNumber = binding.etFrEditReaderPhoneNumber.text.toString()
        reader.address = newAddress
    }

    private fun initData() {
        mSettings = requireContext().getSharedPreferences("my_storage", Context.MODE_PRIVATE)
                as SharedPreferences
        val is_logged = mSettings!!.getBoolean("is_logged", false)
        token = mSettings!!.getString("token", "") as String
        if(is_logged && token.isNotEmpty()){
            if(CheckConNetwork().checkConnectivity(requireContext()) &&
                mSettings!!.getBoolean("is_conServer", false)){
                val userId = mSettings!!.getLong("userId", 0)
                if(userId > 0){
                    retrofit = RetrofitService()
                    setDataServer(userId)
                }
            }
        }
    }

    private fun setDataServer(id: Long) {
        val userApi = retrofit.retrofit.create(UserSystemApi::class.java)
        userApi.get(token, id).enqueue(object : Callback<User> {
            override fun onResponse(call: Call<User>, response: Response<User>) {
                if(response.isSuccessful){
                    user = response.body()!!
                    initForm()
                }else
                    showAlert("Ошибка при считывании данных пользователя. Попробуйте позже.")
            }
            override fun onFailure(call: Call<User>, t: Throwable) {
                showAlert("Ошибка при считывании данных пользователя. Попробуйте позже.")
                (requireActivity() as EditProfileActivity).replaceFragment(EditProfileFragment())
            }

        })
    }

    private fun initForm() {
        binding.headerFrEditReader.tvUser.text = user.username
        binding.reader = reader
        (requireActivity() as EditProfileActivity).subsId = reader.subsId
        binding.address = convertToArray(reader.address).toTypedArray()
    }

    private fun convertToArray(address: String): ArrayList<String> {
        var list = ArrayList<String>()
        for (str in address.split(',')){
            list.add(str)
        }
        return list
    }

    private fun showAlert(str: String) {
        val builder = AlertDialog.Builder(requireContext())
        builder.setPositiveButton("OK", DialogInterface.OnClickListener { dialog, which ->
            dialog.cancel()
        })
        builder.setMessage(str)
        builder.create()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        requireActivity().title = getString(R.string.editUser)
        binding = FragmentEditReaderBinding.inflate(layoutInflater)
        return binding!!.root
    }

    companion object {
        @JvmStatic
        fun newInstance() =
            EditReaderFragment()
    }
}