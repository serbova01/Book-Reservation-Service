package com.example.springclient.adapters

import android.graphics.BitmapFactory
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.widget.AppCompatButton
import androidx.recyclerview.widget.RecyclerView
import com.example.springclient.R
import com.example.springclient.model.Basket

class ItemBasketReservAdapter (var baskets:List<Basket>) :
    RecyclerView.Adapter<ItemBasketReservAdapter.ItemBasketReservViewHolder>(){
    var onItemReservation: ((Basket) -> Unit)? = null
    var onItemDelete: ((Basket) -> Unit)? = null
    var onItemSelected: ((Basket, Boolean) -> Unit)? = null
    var onItemClick: ((Basket) -> Unit)? = null
    var onItemChoosedLib: ((Basket) -> Unit)? = null

    inner class ItemBasketReservViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imageView: ImageView = itemView.findViewById(R.id.iv_basketReserv_imageItem)
        val textView_title: TextView = itemView.findViewById(R.id.tv_basketReserv_bookName)
        val textView_text: TextView = itemView.findViewById(R.id.tv_basketReserv_discription)
        val textView_libName: TextView = itemView.findViewById(R.id.tv_basketReserv_libName)
        val textView_libAddr: TextView = itemView.findViewById(R.id.tv_basketReserv_libAddress)
        val numberPicker: NumberPicker = itemView.findViewById(R.id.np_basketReserv_number)
        val buttonReserv: AppCompatButton = itemView.findViewById(R.id.btn_basketReserv_reservation)
        val checkBox: CheckBox = itemView.findViewById(R.id.cb_basketReserv_isSelect)
        val btnDelete: ImageButton = itemView.findViewById(R.id.btn_basketReserv_delete)

        val btnChooseLib: TextView = itemView.findViewById(R.id.btn_basketReserv_chooseLib)

        init {
            imageView.setOnClickListener() {
                onItemClick?.invoke(baskets[adapterPosition])
            }
            textView_title.setOnClickListener() {
                onItemClick?.invoke(baskets[adapterPosition])
            }
            buttonReserv.setOnClickListener() {
                baskets[adapterPosition].count = numberPicker.value
                onItemReservation?.invoke(baskets[adapterPosition])
            }
            checkBox.setOnClickListener() {
                baskets[adapterPosition].isSelected = checkBox.isChecked
                baskets[adapterPosition].count = numberPicker.value
                onItemSelected?.invoke(baskets[adapterPosition], checkBox.isChecked)
            }
            btnDelete.setImageResource(R.drawable.ic_delete)
            btnChooseLib.setOnClickListener() {
                onItemChoosedLib?.invoke(baskets[adapterPosition])
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemBasketReservViewHolder {
         var view = LayoutInflater.from(parent.context).inflate(R.layout.item_item_basket_reserv,
             parent, false)
        return ItemBasketReservViewHolder(view)
    }

    override fun onBindViewHolder(holder: ItemBasketReservViewHolder, position: Int) {
        var item = baskets[position]
        setImage(item.edition.setImage(), holder)
        //item.edition.image?.let { holder.imageView.setImageResource(it) }
        holder.textView_title.text = item.edition.bookName
        holder.textView_text.text = item.edition.bookAuthorStr
        if(item.libId>0){
            holder.textView_libName.text = item.library!!.name
            holder.textView_libAddr.text = item.library!!.address
        }
        holder.textView_title.text = item.edition.bookName
        holder.checkBox.isChecked = item.isSelected
        holder.numberPicker.minValue = 1
        holder.numberPicker.maxValue = item.maxCountCopies
        holder.numberPicker.value = item.count
        if(item.count > item.maxCountCopies){
            item.count = item.maxCountCopies
        }
        holder.btnDelete.setOnClickListener(){
            //basket.remove(item)
            //notifyItemRemoved(position)
            onItemDelete?.invoke(item)
        }
    }
    private fun setImage(byteArray: ByteArray, holder: ItemBasketReservViewHolder) {
        if(byteArray.isNotEmpty()){
            val bmp = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.size)
            holder.imageView.setImageBitmap(bmp)
        }
    }

    override fun getItemCount(): Int {
        return baskets.size
    }

    fun updateBaskets(list: ArrayList<Basket>) {
        baskets = list
        notifyDataSetChanged()
    }
}