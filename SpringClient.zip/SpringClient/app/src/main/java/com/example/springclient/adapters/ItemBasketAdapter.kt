package com.example.springclient.adapters

import android.graphics.BitmapFactory
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.widget.AppCompatButton
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.springclient.R
import com.example.springclient.model.Basket

class ItemBasketAdapter(var baskets:List<Basket>):
    RecyclerView.Adapter<ItemBasketAdapter.ItemBasketViewHolder>() {

    var onItemReservation: ((Basket) -> Unit)? = null
    var onItemDelete: ((Basket) -> Unit)? = null
    var onItemSelected: ((Basket, Boolean) -> Unit)? = null
    var onItemCreatedReq: ((Basket) -> Unit)? = null
    var onItemClick: ((Basket) -> Unit)? = null
    var onItemChoosedLib: ((Basket) -> Unit)? = null
    lateinit var view: View
    var basketsReservs:ArrayList<Basket>
    var basketsRequests:ArrayList<Basket>

    init{
        basketsReservs = ArrayList()
        basketsRequests = ArrayList()
       for(basket in baskets){
           if(basket.maxCountCopies >0){
               basketsReservs.add(basket)
           }else
               basketsRequests.add(basket)
       }
    }

    inner class ItemBasketViewHolder(itemView: View): RecyclerView.ViewHolder(itemView){
        val rv_Reservs:RecyclerView = itemView.findViewById(R.id.rv_basket_forReserv)
        val rv_Requests:RecyclerView = itemView.findViewById(R.id.rv_basket_forRequest)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemBasketViewHolder {
        view = LayoutInflater.from(parent.context).inflate(R.layout.item_basket, parent, false)

        return ItemBasketViewHolder(view)
    }

    override fun onBindViewHolder(holder: ItemBasketViewHolder, position: Int) {
        var item = baskets[position]
        holder.rv_Reservs.setHasFixedSize(true)
        holder.rv_Reservs.layoutManager = LinearLayoutManager(view.context)
        holder.rv_Requests.setHasFixedSize(true)
        holder.rv_Requests.layoutManager = LinearLayoutManager(view.context)

        var itemBasketReservAdapter = ItemBasketReservAdapter(basketsReservs)
        itemBasketReservAdapter.onItemClick={ item ->
            onItemClick?.invoke(item)
        }
        itemBasketReservAdapter.onItemDelete = { item ->
            onItemDelete?.invoke(item)
        }
        itemBasketReservAdapter.onItemSelected = { item, isChecked  ->
            onItemSelected?.invoke(item,isChecked)
        }
        itemBasketReservAdapter.onItemReservation = { item ->
            onItemReservation?.invoke(item)
        }
        itemBasketReservAdapter.onItemChoosedLib = { item ->
            onItemChoosedLib?.invoke(item)
        }
        holder.rv_Reservs.adapter = itemBasketReservAdapter

        var itemBasketRequestAdapter = ItemBasketRequestAdapter(basketsReservs)
        itemBasketRequestAdapter.onItemClick={ item ->
            onItemClick?.invoke(item)
        }
        itemBasketRequestAdapter.onItemCreatedReq = { item ->
            onItemCreatedReq?.invoke(item)
        }
        itemBasketRequestAdapter.onItemDelete = { item ->
            onItemDelete?.invoke(item)
        }
        itemBasketRequestAdapter.onItemSelected = { item, isChecked  ->
            onItemSelected?.invoke(item,isChecked)
        }
        itemBasketRequestAdapter.onItemChoosedLib = { item ->
            onItemChoosedLib?.invoke(item)
        }
        holder.rv_Requests.adapter = itemBasketRequestAdapter
    }

    override fun getItemCount(): Int {
        return baskets.size
    }

    fun updateBaskets(list: ArrayList<Basket>) {
        baskets = list
        basketsReservs = ArrayList()
        basketsRequests = ArrayList()
        for(basket in baskets){
            if(basket.maxCountCopies >0){
                basketsReservs.add(basket)
            }else
                basketsRequests.add(basket)
        }
        notifyDataSetChanged()
    }
}