package com.example.springclient.controllers

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.example.springclient.R
import com.example.springclient.fragments.FavoritesFragment
import com.example.springclient.fragments.IssuedsFragment
import com.example.springclient.fragments.RequestsFragment
import com.example.springclient.fragments.ReservsFragment
import com.example.springclient.model.User
import com.example.springclient.reotrifit.RetrofitService
import com.example.springclient.reotrifit.WorkLocalDB
import java.io.Serializable


class ProfilePanelActivity : AppCompatActivity() {

    var favoritesFragment = FavoritesFragment()
    var requestsFragment = RequestsFragment()
    var reservsFragment = ReservsFragment()
    var issuedsFragment = IssuedsFragment()

    //val binding: ActivityProlilePanelBinding? =
        //DataBindingUtil.setContentView(this, R.layout.activity_prolile_panel)
    private lateinit var mSettings: SharedPreferences
    private lateinit var mDBHelper: WorkLocalDB
    private lateinit var retrofit: RetrofitService

    lateinit var user: User
    var userId = 0L
    var conServer:Boolean = false
    lateinit var list:Lists

    enum class Lists:Serializable{
        FAVORITES, REQUESTS, RESERVATIONS, ISSUEDS
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_prolile_panel)

        list = (intent.getSerializableExtra("list") as? Lists)!!

        mSettings = getSharedPreferences("my_storage", Context.MODE_PRIVATE) as SharedPreferences
        mDBHelper = WorkLocalDB(this)
        retrofit = RetrofitService()
        //binding!!.srlTvProfilePanel.setOnRefreshListener { init() }
        init()
    }

    fun init(){
        //binding!!.srlTvProfilePanel.isRefreshing = true
        when(list){
            Lists.FAVORITES -> replaceFragment(favoritesFragment)//setFavoritesForm()
            Lists.REQUESTS -> replaceFragment(requestsFragment)//setRequestsForm()
            Lists.RESERVATIONS -> replaceFragment(reservsFragment)
            Lists.ISSUEDS -> replaceFragment(issuedsFragment)
            else -> {
                replaceFragment(favoritesFragment)
            }
        }
    }

    fun replaceFragment(fragment: Fragment){
        if (fragment != null){
            val transaction = supportFragmentManager.beginTransaction()
            transaction.replace(R.id.fl_profilePanel, fragment)
            transaction.commit()
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle presses on the action bar menu items
        when (item.itemId) {
            android.R.id.home -> {
                this.onBackPressed()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onBackPressed() {
        val setIntent = Intent(this, MainActivity::class.java)
        setIntent.putExtra("fragment", 'P')
        startActivity(setIntent)
    }
}
