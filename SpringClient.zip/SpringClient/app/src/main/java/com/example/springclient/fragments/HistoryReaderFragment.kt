package com.example.springclient.fragments

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.widget.AppCompatButton
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.springclient.CheckConNetwork
import com.example.springclient.adapters.ItemHistoryReaderAdapter
import com.example.springclient.controllers.EditProfileActivity
import com.example.springclient.controllers.ViewEditionActivity
import com.example.springclient.databinding.FragmentHistoryReaderBinding
import com.example.springclient.model.HistoryReader
import com.example.springclient.model.User
import com.example.springclient.reotrifit.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class HistoryReaderFragment : Fragment() {
    private lateinit var retrofit: RetrofitService
    private lateinit var mSettings: SharedPreferences
    private lateinit var mDBHelper: WorkLocalDB
    lateinit var binding:FragmentHistoryReaderBinding

    lateinit var user:User
    var subsId = 0L
    lateinit var token:String
    lateinit var historiesReader:List<HistoryReader>
    var conServer = false

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        init()
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun init() {
        (requireActivity() as EditProfileActivity).activeFr = "HR"
        (requireActivity() as EditProfileActivity).subsId = subsId
        binding.rvFrHRList.layoutManager = LinearLayoutManager(requireView().context)
        binding.rvFrHRList.setHasFixedSize(true)
        binding.srlHRList.setOnRefreshListener { initData() }
        binding.headerFrHR.btnFrProfileEditProfile.visibility = AppCompatButton.INVISIBLE
        binding.headerFrHR.btnHeaderBack.setOnClickListener(){
            backToViewReader()}
        initData()
    }

    private fun backToViewReader() {
        var viewReaderFragment = ViewReaderFragment()
        viewReaderFragment.subsId = subsId
        (requireActivity() as EditProfileActivity).activeFr = "VR"
        (requireActivity() as EditProfileActivity).replaceFragment(viewReaderFragment)
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun initData() {
        mDBHelper = WorkLocalDB(requireContext())
        mSettings = requireContext().getSharedPreferences("my_storage", Context.MODE_PRIVATE) as SharedPreferences
        val is_logged = mSettings!!.getBoolean("is_logged", false)
        token = mSettings!!.getString("token", "") as String
        if(is_logged && token.isNotEmpty()){
            if(CheckConNetwork().checkConnectivity(requireContext())&&
                mSettings!!.getBoolean("is_conServer", false)){
                val userId = mSettings!!.getLong("userId", 0)
                if(userId > 0){
                    retrofit = RetrofitService()
                    setDataServer(userId)
                }
            }else{
                getDataLocalDB()
            }

        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun getDataLocalDB() {
        user = mDBHelper.userWithServer
        historiesReader = mDBHelper.hr
        initForm()
    }

    private fun initForm() {
        binding.headerFrHR.tvUser.text = user.username
        binding.srlHRList.isRefreshing = false
        binding.tvFrHRNoListHR.visibility = TextView.GONE
        initAdapter()
        if(historiesReader.isEmpty())
            binding.clFrHRContent.visibility = ConstraintLayout.GONE
    }

    private fun setDataServer(id: Long) {
        val userApi = retrofit.retrofit.create(UserSystemApi::class.java)
        userApi.get(token, id).enqueue(object : Callback<User>{
            override fun onResponse(call: Call<User>, response: Response<User>) {
                if(response.isSuccessful){
                    user = response.body()!!
                    var historyRApi = retrofit.retrofit.create(HistroryRApi::class.java)
                    historyRApi.getAllNoIssued(token, subsId).enqueue(object : Callback<List<HistoryReader>>{
                        @RequiresApi(Build.VERSION_CODES.O)
                        override fun onResponse(
                            call: Call<List<HistoryReader>>,
                            response: Response<List<HistoryReader>>
                        ) {
                            if (response.isSuccessful){
                                historiesReader = response.body()!!
                                conServer = true
                                setDataLocalDB()
                                initForm()
                            }else{
                                getDataLocalDB()
                                Toast.makeText(requireContext(),
                                    "Ошибка при попытке считывания данных истории читателя.", Toast.LENGTH_LONG)
                            }

                        }

                        override fun onFailure(call: Call<List<HistoryReader>>, t: Throwable) {
                            Toast.makeText(requireContext(),
                                "Ошибка при попытке считывания данных истории читателя.", Toast.LENGTH_LONG)
                        }

                    })
                }
            }

            override fun onFailure(call: Call<User>, t: Throwable) {
                Toast.makeText(requireContext(),
                    "Ошибка при попытке считывания данных пользователя.", Toast.LENGTH_LONG)
            }

        })
    }

    private fun setDataLocalDB() {
        mDBHelper.setHR(historiesReader, "hr")
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentHistoryReaderBinding.inflate(layoutInflater)
        return binding!!.root
    }

    private fun initAdapter() {
        var itemHistoryReaderAdapter = ItemHistoryReaderAdapter(historiesReader)
        itemHistoryReaderAdapter.onItemClick = { item ->
            if(conServer) {
                val intent = Intent(context, ViewEditionActivity::class.java)
                intent.putExtra("edId", item.edId)
                startActivity(intent)
            }
        }
        binding.rvFrHRList.adapter = itemHistoryReaderAdapter
    }

    companion object {
        @JvmStatic
        fun newInstance() =
            HistoryReaderFragment()
    }
}