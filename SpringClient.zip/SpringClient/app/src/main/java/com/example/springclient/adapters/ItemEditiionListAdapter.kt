package com.example.springclient.adapters

import android.graphics.BitmapFactory
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.springclient.R
import com.example.springclient.model.Edition

class ItemEditionAdapter(public var catalog:ArrayList<Edition>?) :
    RecyclerView.Adapter<ItemEditionAdapter.ItemCatalogViewHolder>(){

    var onItemClick: ((Edition) -> Unit)? = null
    lateinit var view: View

    inner class ItemCatalogViewHolder(itemView: View): RecyclerView.ViewHolder(itemView){
        val imageView : ImageView = itemView.findViewById(R.id.iv_imageEdition)
        val textView_title : TextView = itemView.findViewById(R.id.tv_nameItem)
        val textView_text : TextView = itemView.findViewById(R.id.tv_discriptionItem)
        init {
            itemView.setOnClickListener {
                onItemClick?.invoke(catalog!![adapterPosition])
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemCatalogViewHolder {
        view = LayoutInflater.from(parent.context).inflate(R.layout.item_list_edition, parent, false)
        return ItemCatalogViewHolder(view)
    }

    override fun onBindViewHolder(holder: ItemCatalogViewHolder, position: Int) {
        val itemCatalog = catalog!![position]
        setImage(itemCatalog.setImage(), holder)
        holder.textView_title.text = itemCatalog.bookName
        holder.textView_text.text = itemCatalog.getShortText()
    }
    private fun setImage(byteArray: ByteArray, holder: ItemCatalogViewHolder) {
        if(byteArray.isNotEmpty()){
            val bmp = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.size)
            holder.imageView.setImageBitmap(bmp)
        }
    }

    override fun getItemCount(): Int {
        return catalog!!.size
    }

    fun filterList(filterlist: ArrayList<Edition>) {
        catalog = filterlist
        notifyDataSetChanged()
    }

}