package com.example.springclient.fragments

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ScrollView
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.springclient.CheckConNetwork
import com.example.springclient.R
import com.example.springclient.adapters.ItemLibReservsAdapter
import com.example.springclient.controllers.ViewEditionActivity
import com.example.springclient.databinding.FragmentResrvsBinding
import com.example.springclient.model.*
import com.example.springclient.reotrifit.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ReservsFragment : Fragment() {
    lateinit var binding: FragmentResrvsBinding
    private lateinit var mSettings: SharedPreferences
    private lateinit var mDBHelper: WorkLocalDB
    private lateinit var retrofit: RetrofitService

    lateinit var libsReserv:ArrayList<ViewLibReservs>
    lateinit var reservs:List<Reservation>
    lateinit var user: User
    var conServer = false
    var userId = 0L
    lateinit var token:String

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        init()
    }

    private fun init() {
        mSettings = requireContext().getSharedPreferences("my_storage", Context.MODE_PRIVATE) as SharedPreferences
        mDBHelper = WorkLocalDB(requireContext())
        retrofit = RetrofitService()

        binding.rvFrReservs.layoutManager = LinearLayoutManager(requireContext())
        binding.rvFrReservs.setHasFixedSize(true)
        binding.srlFrReservs.isRefreshing = true
        initData()
        binding.srlFrReservs.setOnRefreshListener {
            initData()
        }
    }

    private fun initData() {
        token = mSettings!!.getString("token", "") as String
        if(CheckConNetwork().checkConnectivity(requireContext())){
            userId = mSettings!!.getLong("userId", 0)
            if(userId > 0 && token.isNotEmpty()){
                getDataServer(userId)
            }
        }else{
            getLocalDB()
        }
    }

    private fun getLocalDB() {
        conServer = false
        user = mDBHelper.userWithServer
        reservs = mDBHelper.reservation
        if(reservs.isEmpty())
            setNoList()
        else{
            setLibsResrevs()
            initForm()
        }
    }

    private fun setLibsResrevs() {
        libsReserv = arrayListOf()
        for(reserv in reservs){
            if(libsReserv.findLast { libReserv -> libReserv.libName == reserv.libName } != null){
                libsReserv.findLast { libReserv -> libReserv.libName == reserv.libName }!!.list
                    .add(reserv)
            }else{
                var list = ArrayList<Reservation>()
                list.add(reserv)
                libsReserv.add(ViewLibReservs(reserv.libName, reserv.libAddress, list))
            }
        }
    }

    private fun initForm() {
        setAdapter()
        binding.srlFrReservs.isRefreshing = false
    }

    private fun setAdapter() {
        var itemLibReservsAdapter  = ItemLibReservsAdapter(requireContext(), libsReserv, conServer)
        itemLibReservsAdapter.onItemClick = { item ->
            val intent = Intent(context, ViewEditionActivity::class.java)
            intent.putExtra("edId", item.edId)
            startActivity(intent)
        }
        itemLibReservsAdapter.onItemClickDelete = { item ->
            deleteReserv(item)
        }
        binding.rvFrReservs.adapter = itemLibReservsAdapter
    }

    private fun deleteReserv(reservation: Reservation) {
        val reservationApi = retrofit.retrofit.create(ReservationApi::class.java)
        reservationApi.delete(token, reservation.id).enqueue(object : Callback<Reservation>{
            override fun onResponse(call: Call<Reservation>, response: Response<Reservation>) {
                if(response.isSuccessful){
                    conServer = true
                    removeReserv(reservation)
                    setLocalDB()
                    if(reservs.isEmpty())
                        setNoList()
                    else
                        setAdapter()
                }else
                    showAlert("Не удалось отменить бронирование книги. Попробуйте позже.")
            }
            private fun removeReserv(reservation: Reservation) {
                var newReservs = ArrayList<Reservation>()
                for(fav in reservs){
                    if(fav.id != reservation.id)
                        newReservs.add(fav)
                }
                reservs = newReservs
                setLibsResrevs()
            }

            override fun onFailure(call: Call<Reservation>, t: Throwable) {
                showAlert("Не удалось отменить бронирование книги. Попробуйте позже.")
            }

        })
    }

    private fun showAlert(str: String) {
        val builder = AlertDialog.Builder(requireContext())
        builder.setPositiveButton("OK") { dialog, which ->
            dialog.cancel()
        }
        builder.setMessage(str)
        builder.show()
    }

    private fun setNoList() {
        binding.tvFrReservsNoList.visibility = TextView.VISIBLE
        binding.svFrReservs.visibility = ScrollView.GONE
        binding.srlFrReservs.isRefreshing = false
    }

    private fun getDataServer(userId: Long) {
        binding.srlFrReservs.isRefreshing = true
        val userSystemApi = retrofit.retrofit.create(UserSystemApi::class.java)
        userSystemApi.get(token, userId).enqueue(object : Callback<User>{
            override fun onResponse(call: Call<User>, response: Response<User>) {
                if(response.isSuccessful){
                    user = response.body()!!
                    val reservationApi = retrofit.retrofit.create(ReservationApi::class.java)
                    reservationApi.getAllByUser(token, user.id).enqueue(object : Callback<List<Reservation>>{
                        @RequiresApi(Build.VERSION_CODES.O)
                        override fun onResponse(
                            call: Call<List<Reservation>>,
                            response: Response<List<Reservation>>
                        ) {
                            if(response.isSuccessful){
                                conServer = true
                                setListReservs(response.body()!!)
                                if(reservs.isNotEmpty()){
                                    setLibsResrevs()
                                    setLocalDB()
                                    initForm()
                                }else
                                    setNoList()
                            }else {
                                getLocalDB()
                            }
                        }

                        override fun onFailure(call: Call<List<Reservation>>, t: Throwable) {
                            getLocalDB()
                        }

                    })
                }else{
                    getLocalDB()
                }
            }

            override fun onFailure(call: Call<User>, t: Throwable) {
                getLocalDB()
            }

        })

    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun setListReservs(list: List<Reservation>) {
        reservs = list
        for (res in reservs){
            res.setData()
        }
    }

    private fun setLocalDB() {
        mDBHelper.setReservations(reservs)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        requireActivity().title = getString(R.string.listReservations)
        binding = FragmentResrvsBinding.inflate(layoutInflater)
        return binding!!.root
    }

    companion object {
        @JvmStatic
        fun newInstance() = ReservsFragment()
    }
}