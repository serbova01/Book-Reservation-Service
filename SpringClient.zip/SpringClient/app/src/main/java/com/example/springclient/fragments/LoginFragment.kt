package com.example.springclient.fragments

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.example.springclient.AuthRequest
import com.example.springclient.AuthResponse
import com.example.springclient.R
import com.example.springclient.controllers.LoginActivity
import com.example.springclient.controllers.MainActivity
import com.example.springclient.databinding.FragmentLoginBinding
import com.example.springclient.model.Library
import com.example.springclient.model.User
import com.example.springclient.reotrifit.LibraryApi
import com.example.springclient.reotrifit.RetrofitService
import com.example.springclient.reotrifit.UserSystemApi
import com.example.springclient.reotrifit.WorkLocalDB
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.create
import java.util.logging.Level
import java.util.logging.Logger

class LoginFragment : Fragment() {
    lateinit var activityLoginBinding:FragmentLoginBinding
    private lateinit var mSettings: SharedPreferences
    private lateinit var retrofit: RetrofitService
    private lateinit var mDBHelper: WorkLocalDB

    var user: User = User()
    lateinit var token:String

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        init()
    }
    private fun init() {
        mSettings = requireContext().getSharedPreferences("my_storage", Context.MODE_PRIVATE)
                as SharedPreferences
        requireActivity().title = getString(R.string.authorize)
        activityLoginBinding.btnAuthorizeGo.setOnClickListener(){onSign()}
        mDBHelper = WorkLocalDB(requireContext())
    }

    fun onSign() {
        var authRequest = AuthRequest()
        authRequest.username=activityLoginBinding.etLoginLogin.text.toString()
        authRequest.password=activityLoginBinding.etLoginPass.text.toString()
        if(checkIsNull(authRequest)){
            retrofit = RetrofitService()
            val userApi = retrofit.retrofit.create(UserSystemApi::class.java)
            userApi.check(authRequest)
                .enqueue(object : Callback<AuthResponse> {
                    override fun onResponse(call: Call<AuthResponse>, response: Response<AuthResponse>) {
                        //Toast.makeText(requireView().context, "Save successful!!!", Toast.LENGTH_SHORT).show()
                        if(response.isSuccessful){
                            var editor = mSettings.edit()
                            token = "Bearer " + response.body()!!.accessToken
                            setUser(response.body()!!.id)
                        }else{
                            Toast.makeText((requireActivity() as LoginActivity),
                                "Ошибка при проверке данных при авторизации!!",
                                Toast.LENGTH_SHORT).show()
                        }
                    }

                    override fun onFailure(call: Call<AuthResponse>, t: Throwable) {
                        Toast.makeText((requireActivity() as LoginActivity),
                            "Ошибка при проверке данных при авторизации!!",
                            Toast.LENGTH_SHORT).show()
                        Logger.getLogger((requireActivity() as LoginActivity).javaClass.name)
                            .log(Level.SEVERE,"Error occurred in LoginFragment.")
                    }

                })
        }
    }

    private fun checkIsNull(request: AuthRequest): Boolean {
        if(request.username.isNotEmpty()){
            if(request.password.isNotEmpty()){
                if(request.password.length < 5 || request.password.length > 50){
                    activityLoginBinding.tilFrLoginPassword.error =
                        getString(R.string.passwordNoLength)
                    return false
                }
            }else{
                activityLoginBinding.tilFrLoginPassword.error = getString(R.string.canNotBeEmpty)
                return false
            }
        }else{
            activityLoginBinding.tilFrLoginUsername.error = getString(R.string.canNotBeEmpty)
            return false
        }
        return true
    }

    private fun setUser(id:Long) {
        var userSystemApi = retrofit.retrofit.create(UserSystemApi::class.java)
        userSystemApi.get(token, id).enqueue(object : Callback<User>{
            override fun onResponse(call: Call<User>, response: Response<User>) {
                if(response.isSuccessful){
                    user = response?.body()!!
                    checkUser()
                }
            }

            override fun onFailure(call: Call<User>, t: Throwable) {
                Toast.makeText((requireActivity() as LoginActivity),
                    "Ошибка при проверке данных при авторизации!!",
                    Toast.LENGTH_SHORT).show()
            }

        })
    }

    private fun checkUser() {
        if (user.id <= 0){
            var builder = AlertDialog.Builder((requireActivity() as LoginActivity))
            builder.setTitle(getString(R.string.mistake_autorization))
            builder.setMessage(getString((R.string.no_user)))
            builder.show()
            user = User()
        }else{
            if(user.role.equals("USER")){
                mSettings = requireContext().getSharedPreferences("my_storage", Context.MODE_PRIVATE)
                        as SharedPreferences
                var editor = mSettings.edit()
                editor.putBoolean("is_logged", true).apply()
                editor.putLong("userId", user.id).apply()
                editor.putString("token", token).apply()
                mDBHelper.setUser(user)
                val intent = Intent((requireActivity() as LoginActivity), MainActivity::class.java)
                startActivity(intent)
            }else{
                var builder = AlertDialog.Builder((requireActivity() as LoginActivity))
                builder.setTitle(getString(R.string.mistake_autorization))
                builder.setMessage(getString((R.string.no_user)))
                builder.show()
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        //requireActivity().title = getString(R.string.authorize)
        activityLoginBinding = FragmentLoginBinding.inflate(layoutInflater)
        // Inflate the layout for this fragment
        return activityLoginBinding!!.root
    }

    companion object {
        @JvmStatic
        fun newInstance() = LoginFragment()
    }
}