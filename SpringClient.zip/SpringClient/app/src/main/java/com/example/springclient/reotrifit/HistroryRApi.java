package com.example.springclient.reotrifit;

import com.example.springclient.model.HistoryReader;
import com.example.springclient.model.Library;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface HistroryRApi {
    @GET("/rest/historyReader/get-noissued-for-subs/{id}")
    Call<List<HistoryReader>> getAllNoIssued(@Header("Authorization") String token,
                                             @Path(value = "id", encoded = false) long id);
    @GET("/rest/historyReader/get-issued-for-subs/{id}")
    Call<List<HistoryReader>> getAllIssued(@Header("Authorization") String token,
                                           @Path(value = "id", encoded = false) long id);
    @GET("/rest/historyReader/get-issueds-user/{id}")
    Call<List<HistoryReader>> getIssedsByUser(@Header("Authorization") String token,
                                              @Path(value = "id", encoded = false) long id);
    @GET("/rest/historyReader/get-delayeds-user/{id}")
    Call<List<HistoryReader>> getDelayedsByUser(@Header("Authorization") String token,
                                                @Path(value = "id", encoded = false) long id);

    @GET("/rest/historyReader/prolong/{id}")
    Call<HistoryReader> prolongHR(@Header("Authorization") String token,
                                  @Path(value = "id", encoded = false) long id);
    @POST("/rest/historyReader/prolong/{ids}")
    Call<HistoryReader> prolongHR(@Header("Authorization") String token,
                                  @Path(value = "ids", encoded = false) String id);
}
