package com.example.springclient.fragments

import android.content.DialogInterface
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.BitmapFactory
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.springclient.R
import com.example.springclient.adapters.ItemBasketAdapter
import com.example.springclient.adapters.ItemResevInLibAdapter
import com.example.springclient.controllers.MainActivity
import com.example.springclient.controllers.ReservBasketActivity
import com.example.springclient.controllers.ViewEditionActivity
import com.example.springclient.databinding.FragmentMainFormBasketBinding
import com.example.springclient.databinding.FragmentReservOneBasketBinding
import com.example.springclient.model.*
import com.example.springclient.reotrifit.EditionApi
import com.example.springclient.reotrifit.ReservationApi
import com.example.springclient.reotrifit.RetrofitService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ReservOneBasketFragment : Fragment() {
    lateinit var binding:FragmentReservOneBasketBinding
    private lateinit var retrofit: RetrofitService

    lateinit var basket:Basket
    lateinit var user: User
    var userId = 0L
    lateinit var token:String
    //lateinit var libsForReser:List<ViewLibWithEd>
    //var library = Library()
    var count:Long = 1
    var maxCountCopies = 0L
    //var subsId = 0L

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        basket = (requireActivity() as ReservBasketActivity).listBasket[0]
        user = (requireActivity() as ReservBasketActivity).user
        userId = (requireActivity() as ReservBasketActivity).userId
        token = (requireActivity() as ReservBasketActivity).token
        init()
    }

    private fun init() {
        retrofit = RetrofitService()
        //binding.srlROneBasket.setOnRefreshListener { initData() }
        binding.ibROneBasketMinusCount.setOnClickListener(){minusCount()}
        binding.ibROneBasketPlusCount.setOnClickListener(){plusCount()}
        binding.btnReservationReserv.setOnClickListener(){addReservation()}
        //initData()
        basket.count = 1
        binding.count = basket.count.toLong()
        binding.library = basket.library
        binding.edition = basket.edition
        maxCountCopies = basket.maxCountCopies.toLong()
        setImage(basket.edition.setImage())
        binding.srlROneBasket.isRefreshing = false
    }

    private fun setImage(byteArray: ByteArray) {
        if(byteArray.isNotEmpty()){
            val bmp = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.size)
            binding.ivROneBasketImage.setImageBitmap(bmp)
        }
    }

    /*private fun initForm() {
        binding.count = basket.count
        binding.srlROneBasket.isRefreshing = false
        //initAdapter()
    }

    private fun initData() {
        binding.srlROneBasket.isRefreshing = true
        var editionApi = retrofit.retrofit.create(EditionApi::class.java)
        editionApi.getLibsForReserv(basket.edition.id, user.email).enqueue(object : Callback<List<ViewLibWithEd>>{
            override fun onResponse(
                call: Call<List<ViewLibWithEd>>,
                response: Response<List<ViewLibWithEd>>
            ) {
                if(response.isSuccessful){
                    libsForReser = response.body()!!
                    initForm()
                }else {
                    Toast.makeText(requireContext(), getString(R.string.libsForReservBad),
                        Toast.LENGTH_LONG).show()
                    backToBasket()
                }
            }

            override fun onFailure(call: Call<List<ViewLibWithEd>>, t: Throwable) {
                Toast.makeText(requireContext(), getString(R.string.libsForReservBad),
                    Toast.LENGTH_LONG).show()
                backToBasket()
            }

        })
    }*/

    private fun addReservation() {
        var basketPost = setBasketForPost()
        var reservationApi = retrofit.retrofit.create(ReservationApi::class.java)
        reservationApi.add(token, basketPost).enqueue(object : Callback<Reservation> {
            override fun onResponse(call: Call<Reservation>, response: Response<Reservation>) {
                if(response.isSuccessful && response.body()!!.edId > 0L){
                    Toast.makeText(requireContext(), getString(R.string.reservOk),
                        Toast.LENGTH_LONG).show()
                    backToBasket()
                }else
                    Toast.makeText(requireContext(), getString(R.string.reservBad),
                        Toast.LENGTH_LONG).show()
            }

            override fun onFailure(call: Call<Reservation>, t: Throwable) {
                Toast.makeText(requireContext(), getString(R.string.reservBad),
                    Toast.LENGTH_LONG).show()
            }

        })
    }

    private fun setBasketForPost(): Basket {
        return Basket(basket.id, basket.favorite, basket.count, basket.libId, userId, basket.edId)
    }

    private fun backToBasket() {
        val setIntent = Intent(requireContext(), MainActivity::class.java)
        setIntent.putExtra("fragment", 'B')
        startActivity(setIntent)
    }

    private fun showAlert(str: String) {
        val builder = AlertDialog.Builder(requireContext())
        builder.setPositiveButton("OK", DialogInterface.OnClickListener { dialog, which ->
            dialog.cancel()
        })
        builder.setMessage(str)
        builder.show()
    }

    private fun plusCount() {
        if(count <= maxCountCopies){
            binding.count = ++count
            if(count == maxCountCopies)
                binding.ibROneBasketPlusCount.isEnabled = false
            binding.ibROneBasketMinusCount.isEnabled = true
        }
    }

    private fun minusCount() {
        if(count > 1){
            binding.count = --count
            if(count == 1L)
                binding.ibROneBasketMinusCount.isEnabled = false
            binding.ibROneBasketPlusCount.isEnabled = true
        }
    }

    /*private fun initAdapter() {
        binding.rvROneBasketLibs.setHasFixedSize(true)
        binding.rvROneBasketLibs.layoutManager = LinearLayoutManager(requireContext())

        var itemLibWithEd = ItemResevInLibAdapter(libsForReser,user.id > 0L)
        itemLibWithEd.onItemClick = { view, checkBox ->
            if(checkBox.isChecked){
                library = view.library
                subsId = view.subsId
                maxCountCopies = view.count
                updateMaxCount()
                libsForReser.filter { item -> item.library.id != view.library.id }.forEach{item ->
                    item.checked = false
                }
                setCountForm(view)
            }else
                library = Library()
            libsForReser.first { item -> item.library.id == view.library.id }.checked = checkBox.isChecked
            initAdapter()
        }
        binding.rvROneBasketLibs.adapter = itemLibWithEd
    }*/

    private fun updateMaxCount() {
        if(maxCountCopies == 1L){
            binding.ibROneBasketPlusCount.isEnabled = false
            binding.ibROneBasketMinusCount.isEnabled = false
            binding.tvROneBasketMistake.visibility = TextView.VISIBLE
        }
    }

    private fun setCountForm(view: ViewLibWithEd) {
        count = 1
        binding.count = count
        maxCountCopies = view.count
        updateMaxCount()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentReservOneBasketBinding.inflate(layoutInflater)
        return binding!!.root
    }

    companion object {
        @JvmStatic
        fun newInstance() = ReservOneBasketFragment()
    }
}