package com.example.springclient.controllers

import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.Fragment
import com.example.springclient.R
import com.example.springclient.fragments.BasketFragment
import com.example.springclient.fragments.CatalogFragment
import com.example.springclient.fragments.ProfileFragment
import com.example.springclient.model.User
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {
    val catalogFragment = CatalogFragment()
    val basketFragment = BasketFragment()
    val profileFragment = ProfileFragment()
    lateinit var mSettings: SharedPreferences
    var fragment:Char = ' '

    lateinit var user: User

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val bundle = intent.extras
        if (bundle != null){
            fragment = bundle.getChar("fragment")
            if(fragment != null){
                when(fragment){
                    'C' -> replaceFragment(catalogFragment)
                    'B'  -> replaceFragment(basketFragment)
                    'P' -> replaceFragment(profileFragment)
                }
            }
        }else
            replaceFragment(catalogFragment)
        mSettings = this.getSharedPreferences("my_storage", Context.MODE_PRIVATE) as SharedPreferences
        initializeComponents()
    }

    private fun replaceFragment(fragment: Fragment){
        if (fragment != null){
            val transaction = supportFragmentManager.beginTransaction()
            transaction.replace(R.id.fl_catalog, fragment)
            transaction.commit()
        }
    }

    private fun initializeComponents() {
        val bn_menu = findViewById<BottomNavigationView>(R.id.bn_menu)
        bn_menu.setOnNavigationItemSelectedListener {
            when(it.itemId){
                R.id.ic_catalog -> replaceFragment(catalogFragment)
                R.id.ic_basket -> replaceFragment(basketFragment)
                R.id.ic_profile -> replaceFragment(profileFragment)
            }
            true
        }
        val is_logged = mSettings!!.getBoolean("is_logged", false)



        /*val iet_name = findViewById<TextInputEditText>(R.id.form_textFieldName)
        val iet_email = findViewById<TextInputEditText>(R.id.form_textFieldEmail)
        val iet_address = findViewById<TextInputEditText>(R.id.form_textFieldAddress)
        val iet_cityNumber = findViewById<TextInputEditText>(R.id.form_textFieldCityNumber)
        val iet_latitude = findViewById<TextInputEditText>(R.id.form_textFieldLatitude)
        val iet_longitude = findViewById<TextInputEditText>(R.id.form_textFieldLongitude)
        val mb_saveLibrary = findViewById<MaterialButton>(R.id.form_buttonSave)

        val retrofit:RetrofitService = RetrofitService()
        val libraryApi:LibraryApi = retrofit.retrofit.create(LibraryApi::class.java)

        mb_saveLibrary.setOnClickListener(){
            var name:String = iet_name.text.toString()
            var email:String = iet_email.text.toString()
            var address:String = iet_address.text.toString()
            var cityNumber:String = iet_cityNumber.text.toString()
            var latitude:Int = iet_latitude.text.toString().toInt()
            var longitude:Int = iet_longitude.text.toString().toInt()
            var library:Library = Library(name, cityNumber, email, address, latitude, longitude)

            libraryApi.save(library)
                .enqueue(object : Callback<Library>{
                    override fun onFailure(call: Call<Library>, t:Throwable ) {
                        Toast.makeText(this@MainActivity, "Save failed!!!", Toast.LENGTH_SHORT).show()
                        Logger.getLogger(this@MainActivity.localClassName).log(Level.SEVERE, "Error occurred.")
                    }

                    override fun onResponse(call: Call<Library>, response: Response<Library> ) {
                        Toast.makeText(this@MainActivity, "Save successful!!!", Toast.LENGTH_SHORT).show()
                    }
                })
        }*/
    }
}