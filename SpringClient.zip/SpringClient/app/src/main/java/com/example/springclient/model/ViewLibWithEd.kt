package com.example.springclient.model

class ViewLibWithEd {
    lateinit var library:Library
    var subsId = 0L
    var count = 0L
    var reg = false
    var availableDelayeds = false
    var checked = false
}