package com.example.springclient.fragments

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.springclient.CheckConNetwork
import com.example.springclient.R
import com.example.springclient.adapters.ItemFavoritesAdapter
import com.example.springclient.controllers.ViewEditionActivity
import com.example.springclient.databinding.FragmentFavoritesBinding
import com.example.springclient.model.*
import com.example.springclient.reotrifit.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class FavoritesFragment : Fragment() {
    lateinit var binding: FragmentFavoritesBinding
    private lateinit var mSettings: SharedPreferences
    private lateinit var mDBHelper: WorkLocalDB
    private lateinit var retrofit: RetrofitService
    lateinit var itemFavoritesAdapter:ItemFavoritesAdapter

    lateinit var user:User
    var userId = 0L
    lateinit var token:String
    var favorites:List<Basket> = ArrayList()
    var conServer:Boolean = false
    lateinit var libraries:List<Library>

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        init()
    }

    private fun init() {
        mSettings = requireContext().getSharedPreferences("my_storage", Context.MODE_PRIVATE) as SharedPreferences
        mDBHelper = WorkLocalDB(requireContext())
        retrofit = RetrofitService()

        binding.rvFrFavorites.setHasFixedSize(true)
        binding.rvFrFavorites.layoutManager = LinearLayoutManager(requireContext())
        binding.srlFrFavorite.isRefreshing = true
        initData()
        binding.srlFrFavorite.setOnRefreshListener {
            if (conServer)
                initData()
        }
    }

    private fun initForm() {
        if(favorites.isEmpty()){
            //binding.tvFrFavoritesNoList.visibility = TextView.VISIBLE
            //binding.svFrFavorites.visibility = ScrollView.GONE
        }else{
            setAdapter()
        }
        binding.srlFrFavorite.isRefreshing = false
    }

    private fun setAdapter() {
        itemFavoritesAdapter = ItemFavoritesAdapter(favorites, conServer)
        itemFavoritesAdapter.onItemClick = { item ->
            if(conServer){
                val intent = Intent(context, ViewEditionActivity::class.java)
                intent.putExtra("edId", item.edId)
                startActivity(intent)
            }
        }
        itemFavoritesAdapter.onItemClickBasket = { item ->
            //showChooseLib(item)
            insertBasket(item)
        }
        itemFavoritesAdapter.onItemClickDelete = { it ->
            deleteFavorite(it)
        }
        binding.rvFrFavorites.adapter = itemFavoritesAdapter
    }

    private fun deleteFavorite(basket: Basket){
        //basket.usId = userId
        val basketApi = retrofit.retrofit.create(BasketApi::class.java)
        basketApi.deleteFavorite(token, basket.id).enqueue(object : Callback<Basket>{
            override fun onResponse(call: Call<Basket>, response: Response<Basket>) {
                if(response.isSuccessful){
                    removeFavorite(basket)
                    setLocalDB()
                    if(favorites.isEmpty())
                        setNoList()
                    else
                        setAdapter()
                }
            }

            private fun removeFavorite(basket: Basket) {
                var newFavorites = ArrayList<Basket>()
                for(fav in favorites){
                    if(fav.id != basket.id)
                        newFavorites.add(fav)
                }
                favorites = newFavorites
            }

            override fun onFailure(call: Call<Basket>, t: Throwable) {
                showAlert("Не удалось удалить издание из списка 'Избранное'. Попробуйте позже.")
            }
        })
    }

    private fun insertBasket(basket: Basket) {
        basket.count++
        if(basket.library != null){
            basket.libId = basket.library!!.id
        }
        basket.edId = basket.edition.id
        basket.usId = userId
        val basketApi = retrofit.retrofit.create(BasketApi::class.java)
        basketApi.save(token, basket).enqueue(object : Callback<Basket>{
            override fun onResponse(call: Call<Basket>, response: Response<Basket>) {
                if(response.isSuccessful){
                    Toast.makeText(requireContext(), getString(R.string.insertBasket),
                        Toast.LENGTH_SHORT).show()
                    setLocalDB()
                }else
                    showAlert("Добавить книгу в корзину не удалось. Попробуйте позже.")
            }

            override fun onFailure(call: Call<Basket>, t: Throwable) {
                showAlert("Добавить книгу в корзину не удалось. Попробуйте позже.")
            }

        })
    }

    /*private fun showChooseLib(basket: Basket) {
        if(basket.libId == 0L){
            val basketApi = retrofit.retrofit.create(BasketApi::class.java)
            basketApi.getLibsForInsBasket(token, basket.edId, basket.usId).enqueue(object : Callback<List<Library>>{
                override fun onResponse(call: Call<List<Library>>, response: Response<List<Library>>) {
                    if(response.isSuccessful){
                        if(response.body()!!.isNotEmpty()){
                            libraries = response.body()!!
                            var libStrs:Array<String> = getLibsToStrs()
                            showAlertLibs(libStrs, basket)
                        }else{
                            insertBasket(basket)
                        }
                    }else{
                        showAlert("Не удалось выгрузить список библиотек, в которых можно забронировать " +
                                "эту книгу. Попробуйте позже.")
                    }
                }

                override fun onFailure(call: Call<List<Library>>, t: Throwable) {
                    showAlert("Не удалось выгрузить список библиотек, в которых можно забронировать " +
                            "эту книгу. Попробуйте позже.")
                }

            })
        }else{
            insertBasket(basket)
        }
    }

    private fun showAlertLibs(libStrs:Array<String>, basket: Basket) {
        if(libStrs.isNotEmpty()){
            val builder = AlertDialog.Builder(requireContext())
            builder.setTitle(getString(R.string.chooseLibrary))
            builder.setSingleChoiceItems(libStrs, libStrs.size-1) { dialog, which ->
                basket.library = libraries[which]
            }
            // add OK and Cancel buttons
            builder.setPositiveButton("OK") { dialog, which ->
                if(basket.library != null)
                    insertBasket(basket)
            }
            builder.setNegativeButton("Отмена", null)
            // create and show the alert dialog
            val dialog = builder.create()
            dialog.show()
        }else{
            showAlert(getString(R.string.chooseLibListEmpty))
        }
    }

    private fun getLibsToStrs(): Array<String> {
        var list = ArrayList<String>()
        for(library in libraries){
            list.add(library.name + " " + library.address)
        }
        list.add("Добавить без библиотеки.")
        return list.toTypedArray()
    }*/

    private fun setLocalDB() {
        mDBHelper.favorites = favorites
    }

    private fun showAlert(str: String) {
        val builder = AlertDialog.Builder(requireContext())
        builder.setPositiveButton("OK") { dialog, which ->
            dialog.cancel()
        }
        builder.setMessage(str)
        builder.create()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        requireActivity().title = getString(R.string.favorites)
        binding = FragmentFavoritesBinding.inflate(layoutInflater)
        return binding!!.root
    }

    companion object {
        @JvmStatic
        fun newInstance() = FavoritesFragment()
    }

    private fun initData() {
        token = mSettings!!.getString("token", "") as String
        if(CheckConNetwork().checkConnectivity(requireContext())){
            userId = mSettings!!.getLong("userId", 0)
            if(userId > 0 && token.isNotEmpty()){
                getDataServer(userId)
            }
        }else{
            getLocalDB()
        }
    }

    private fun getLocalDB() {
        conServer = false
        user = mDBHelper.userWithServer
        favorites = mDBHelper.favorites
        initForm()
    }

    private fun getDataServer(userId: Long) {
        binding.srlFrFavorite.isRefreshing = true
        val basketApi = retrofit.retrofit.create(BasketApi::class.java)
        basketApi.getAllFavorites(token, userId).enqueue(object : Callback<List<Basket>>{
            override fun onResponse(call: Call<List<Basket>>, response: Response<List<Basket>>) {
                if(response.isSuccessful){
                    conServer = true
                    favorites = response.body()!!
                    if(response.body()!!.isNotEmpty()){
                        setLocalDB()
                        initForm()
                    }else{
                        setNoList()
                    }
                    //if(count == -1)
                        //initForm()
                }
            }

            override fun onFailure(call: Call<List<Basket>>, t: Throwable) {
                Toast.makeText(requireContext(), "Ошибка при загрузке списка 'Избранное'!!",
                    Toast.LENGTH_SHORT).show()
                getLocalDB()
            }

        })
    }
    private fun setNoList() {
        binding.tvFrFavoritesNoList.visibility = TextView.VISIBLE
        binding.svFrFavorites.visibility = ScrollView.GONE
        binding.srlFrFavorite.isRefreshing = false
    }
}