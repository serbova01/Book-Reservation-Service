package com.example.springclient.controllers

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import com.example.springclient.R
import com.example.springclient.databinding.FragmentLoginBinding
import com.example.springclient.fragments.LoginFragment
import com.example.springclient.fragments.RegistrationFragment
import com.example.springclient.fragments.VerifEmailFragment
import com.example.springclient.model.User
import com.example.springclient.reotrifit.RetrofitService
import com.example.springclient.reotrifit.WorkLocalDB

class LoginActivity : AppCompatActivity() {
    lateinit var activityLoginBinding: FragmentLoginBinding

    val loginFragment = LoginFragment()
    val registrationFragment = RegistrationFragment()
    val verifEmailFragment = VerifEmailFragment()

    public lateinit var user: User
    private lateinit var mSettings: SharedPreferences
    private lateinit var retrofit: RetrofitService
    private lateinit var mDBHelper: WorkLocalDB

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        replaceFragment(loginFragment)
        mDBHelper = WorkLocalDB(this)
        //binding = ActivityLoginBinding.inflate(layoutInflater)
        //setContentView(binding.root)
    }

    public fun replaceFragment(fragment: Fragment){
        if (fragment != null){
            val transaction = supportFragmentManager.beginTransaction()
            transaction.replace(R.id.fl_login, fragment)
            transaction.commit()
        }
    }

    fun onRegistration(view: View) {
        replaceFragment(registrationFragment)
    }

    fun replaceVerEmailFr() {
        replaceFragment(verifEmailFragment)
    }

    override fun onBackPressed() {
        val setIntent = Intent(this, MainActivity::class.java)
        setIntent.putExtra("fragment", 'P')
        startActivity(setIntent)
    }
}