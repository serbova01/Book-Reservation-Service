package com.example.springclient.reotrifit;

import com.example.springclient.model.Library;
import com.example.springclient.model.Subscription;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface SubscriptionApi {
    @GET("/rest/reader/get-all-subs/{id}")
    Call<List<Subscription>> getAllSubscriptions(@Header("Authorization") String token,
                                                 @Path(value = "id", encoded = false) long id);
    @GET("/rest/subscription/get/{id}")
    Call<Subscription> getSubscription(@Header("Authorization") String token,
                                       @Path(value = "id", encoded = false) long id);
}
