package com.example.springclient.model

class ViewLibReservs (var libName:String, var libAddress:String, var list:ArrayList<Reservation>){
}