package com.example.springclient.adapters

import android.graphics.Typeface
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.springclient.R
import com.example.springclient.model.ViewLibWithEd

class ItemResevInLibAdapter (private val list:List<ViewLibWithEd>, var flag:Boolean)  :
    RecyclerView.Adapter<ItemResevInLibAdapter.ItemResevInLibHolder>(){
    var onItemClick: ((ViewLibWithEd, CheckBox) -> Unit)? = null

    inner class ItemResevInLibHolder(itemView: View): RecyclerView.ViewHolder(itemView){
        val checkBox: CheckBox = itemView.findViewById(R.id.cb_itemReservInLib)
        val textView_name : TextView = itemView.findViewById(R.id.tv_itemReservInLib_name)
        val textView_address : TextView = itemView.findViewById(R.id.tv_itemReservInLib_address)
        val textView_num : TextView = itemView.findViewById(R.id.tv_itemReservInLib_num)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemResevInLibHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_reserv_lib, parent, false)
        return ItemResevInLibHolder(view)
    }

    override fun onBindViewHolder(holder: ItemResevInLibHolder, position: Int) {
        var item = list[position]
        holder.textView_name.text = item.library.name
        holder.textView_address.text = item.library.address
        holder.textView_num.text = item.count.toString()
        holder.checkBox.visibility = CheckBox.VISIBLE
        holder.checkBox.setOnClickListener(){
            onItemClick?.invoke(item, holder.checkBox)
        }
        if (!flag || !item.reg || item.count == 0L){
            holder.checkBox.visibility = CheckBox.INVISIBLE
        }
        holder.checkBox.isChecked = item.checked
    }

    override fun getItemCount(): Int {
       return list.size;
    }
}