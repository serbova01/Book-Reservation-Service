package com.example.springclient.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.example.springclient.R
import com.example.springclient.controllers.LoginActivity
import com.example.springclient.databinding.FragmentRegistrationBinding
import com.example.springclient.model.Reader
import com.example.springclient.model.User
import com.example.springclient.reotrifit.RetrofitService
import com.example.springclient.reotrifit.UserSystemApi
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.logging.Level
import java.util.logging.Logger

class RegistrationFragment : Fragment() {

    lateinit var binding: FragmentRegistrationBinding
    private lateinit var retrofit: RetrofitService
    var user: User = User()
    lateinit var token:String

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        init()
    }

    private fun init() {
        requireActivity().title = getString(R.string.registration)
        binding.btnRegGo.setOnClickListener(){onRegistration()}
    }

    private fun onRegistration() {
        checkUser()
    }

    private fun checkUser() {
        setUser()

        if(checkNullText()){
            retrofit = RetrofitService()
            val userApi: UserSystemApi = retrofit.retrofit.create(
                UserSystemApi::class.java)

            userApi.checkByEmail(user!!).enqueue(object : Callback<Reader>{
                override fun onFailure(call: Call<Reader>, t: Throwable) {
                    Toast.makeText(requireView().context, "Ошибка при проверке email-а!!",
                        Toast.LENGTH_SHORT).show()

                    //Logger.getLogger(requireView().javaClass.name).log(Level.SEVERE, "Error occurred in RegistrationFragment.")
                }

                override fun onResponse(call: Call<Reader>, response: Response<Reader>) {
                    if(response.isSuccessful){
                        if(response.body()!!.firstName != null){
                            userApi.checkByUsername(user).enqueue(object : Callback<User>{
                                override fun onFailure(call: Call<User>, t: Throwable) {
                                    Toast.makeText(requireView().context,
                                        "Ошибка при проверке имени пользователя!!",
                                        Toast.LENGTH_SHORT).show()
                                    Logger.getLogger(requireView().javaClass.name).log(
                                        Level.SEVERE,"Error occurred in RegistrationFragment.")
                                }

                                override fun onResponse(call: Call<User>, response: Response<User>) {
                                    if(response.isSuccessful){
                                        if(response.body()!!.id > 0) {
                                            (activity as LoginActivity).replaceVerEmailFr()
                                        }
                                    }
                                    else{
                                        //Toast.makeText(requireView().context, getString(R.string.userByNameIs), Toast.LENGTH_LONG).show()
                                        binding.tilRegUsername.error = getString(R.string.userByNameIs)
                                    }

                                }
                            })
                        }else{
                            var builder = AlertDialog.Builder(requireView().context)
                            builder.setTitle(getString(R.string.userByEmailIsNot))
                            builder.setMessage(getString((R.string.noRegWithEmail)))
                            builder.show()
                            //Toast.makeText(requireView().context, getString(R.string.userByEmailIs), Toast.LENGTH_LONG).show()
                            //binding.tilRegEmail.error = getString(R.string.userByNameIs)
                        }
                    }

                }
            })
        }
    }

    private fun setUser(){
        user.email = binding.etRegEmail.text.toString()
        user.username = binding.etRegLogin.text.toString()
        user.password = binding.etRegPass.text.toString()

        (activity as LoginActivity).user = user
    }

    private fun checkNullText(): Boolean {
        if (user.email.isNotEmpty()){
            if (user.username.isNotEmpty()){
                if (user.password.isNotEmpty()){
                    if (binding.etRegConfimPass.text.isNotEmpty()){
                        if(!user.password.equals(binding.etRegConfimPass.text.toString())){
                            binding.tilRegPass.error = getString(R.string.passwordsNotMatch)
                        } else return true
                    }else{
                        binding.tilRegConfimPass.error = getString(R.string.canNotBeEmpty)
                    }
                }else{
                    binding.tilRegPass.error = getString(R.string.canNotBeEmpty)
                }
            }else{
                binding.tilRegUsername.error = getString(R.string.canNotBeEmpty)
            }
        }else{
            binding.tilRegEmail.error = getString(R.string.canNotBeEmpty)
        }
        return false
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentRegistrationBinding.inflate(layoutInflater)
        // Inflate the layout for this fragment
        return binding!!.root
    }

    companion object {
        @JvmStatic
        fun newInstance() = RegistrationFragment()
    }
}