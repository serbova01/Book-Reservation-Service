package com.example.springclient.model

class User() {
    var id = 0L
    var username = ""
    var password = ""
    var email = ""
    var authorize = true
    var role = "READER"
    var libId = 0L
    lateinit var library:Library


    constructor(username: String?, password: String?, email: String?, role: String?) : this() {
        this.username = username.toString()
        this.password = password.toString()
        this.role = role.toString()
        this.email = email.toString()
    }

    constructor(id:Long, username:String, authorize:Boolean, password:String, email:String,
                role: String, library: Library) : this() {
        this.id=id
        this.username = username
        this.password = password
        this.email = email
        this.role = role
        this.library = library
        this.authorize = authorize
    }
    constructor(id:Long, username:String, authorize: Boolean, password:String, email:String,
                role: String, libId:Long) : this() {
        this.id=id
        this.username = username
        this.authorize = authorize
        this.password = password
        this.email = email
        this.role=role
        this.libId = libId
    }

    constructor(username:String, password:String, email:String) : this() {
        this.username = username
        this.password = password
        this.email = email
    }
}