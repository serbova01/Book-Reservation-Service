package com.example.springclient.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.springclient.R
import com.example.springclient.model.Basket
import com.example.springclient.model.Reservation
import com.example.springclient.model.ViewLibBasketReserv
import com.example.springclient.model.ViewLibReservs

class ItemLibBasketReservAdapter(var context: Context, var list:ArrayList<ViewLibBasketReserv>):
    RecyclerView.Adapter<ItemLibBasketReservAdapter.ItemLibBasketReservHolder>() {
    var onItemClick: ((Basket) -> Unit)? = null
    var onItemListEmpty: ((Basket) -> Unit)? = null

    inner class ItemLibBasketReservHolder(itemView: View): RecyclerView.ViewHolder(itemView){
        val tv_nameLib : TextView = itemView.findViewById(R.id.tv_reservWithLibItem_name)
        val tv_addressLib : TextView = itemView.findViewById(R.id.tv_reservWithLibItem_address)
        val recyclerView : RecyclerView = itemView.findViewById(R.id.rv_reservWithLibItem)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemLibBasketReservHolder {
        var view = LayoutInflater.from(parent.context).inflate(R.layout.item_lib_reserv_list, parent, false)
        return ItemLibBasketReservHolder(view)
    }

    override fun onBindViewHolder(holder: ItemLibBasketReservHolder, position: Int) {
        var view = list[position]
        var text:String = holder.tv_nameLib.text.toString()
        text+= "\t" + view.libName
        holder.tv_nameLib.text = text
        holder.tv_addressLib.text = view.libAddress
        holder.recyclerView.setHasFixedSize(true)
        holder.recyclerView.layoutManager =
            LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
        var itemBasketResrvAdapter = ItemBasketResrvAdapter(context, view.list)
        itemBasketResrvAdapter.onItemClick = { item ->
            onItemClick!!(item)
        }
        itemBasketResrvAdapter.onItemClickDelete = { item ->
            view.list.remove(item)
            if(view.list.isEmpty()){
                list.remove(view)
                notifyItemRemoved(position)
            }else
                notifyItemChanged(position)
            if(list.isEmpty())
                onItemListEmpty!!(item)
        }
        holder.recyclerView.adapter = itemBasketResrvAdapter
    }

    override fun getItemCount(): Int {
        return list.size
    }

}