package com.example.springclient.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.widget.AppCompatButton
import com.example.springclient.CheckConNetwork
import com.example.springclient.R
import com.example.springclient.controllers.EditProfileActivity
import com.example.springclient.databinding.FragmentViewReaderBinding
import com.example.springclient.databinding.FragmentViewReaderMapBinding
import com.example.springclient.model.Library
import com.example.springclient.model.User
import com.yandex.mapkit.Animation
import com.yandex.mapkit.MapKitFactory
import com.yandex.mapkit.geometry.Point
import com.yandex.mapkit.map.CameraPosition
import com.yandex.mapkit.mapview.MapView

class ViewReaderMapFragment : Fragment() {
    lateinit var library: Library
    lateinit var user: User
    var subsId:Long= 0L
    lateinit var binding: FragmentViewReaderMapBinding

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.headerFrViewReaderMap.tvUser.text = user.username
        binding.headerFrViewReaderMap.btnFrProfileEditProfile.visibility = AppCompatButton.INVISIBLE
        binding.headerFrViewReaderMap.btnHeaderBack.setOnClickListener(){
            (requireActivity() as EditProfileActivity).activeFr = "VR"
            (requireActivity() as EditProfileActivity).replaceViewReaderFragment(subsId)}
        setMap()
    }
    private fun setMap() {
            val mappoint = Point(library.latitude!!, library.longitude!!)
        binding.mvFrViewReader.map.move(
                CameraPosition(mappoint,17.0f, 0.0f,
                    0.0f), Animation(Animation.Type.SMOOTH, 1f), null)
        binding.mvFrViewReader.map.mapObjects.addPlacemark(mappoint)

        //map.map.addTapListener(this);
        //map.map.addInputListener(this);
    }
    override fun onStart() {
        binding.mvFrViewReader.onStart()
        MapKitFactory.getInstance().onStart()
        super.onStart()
    }

    override fun onStop() {
        binding.mvFrViewReader.onStop()
        MapKitFactory.getInstance().onStop()

        super.onStop()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        requireActivity().title = library.name
        if(CheckConNetwork().checkConnectivity(requireContext())){
            MapKitFactory.initialize(requireContext())
        }
        binding = FragmentViewReaderMapBinding.inflate(layoutInflater)

        return binding!!.root
    }

    companion object {
        @JvmStatic
        fun newInstance() =
            ViewReaderMapFragment()
    }
}