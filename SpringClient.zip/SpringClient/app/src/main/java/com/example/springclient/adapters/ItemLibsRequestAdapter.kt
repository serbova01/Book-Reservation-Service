package com.example.springclient.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.springclient.R
import com.example.springclient.model.Library
import com.example.springclient.model.Subscription

class ItemLibsRequestAdapter(var libraries:List<Library>) :
    RecyclerView.Adapter<ItemLibsRequestAdapter.ItemLibsRequestViewHolder>(){

    var onItemChecked: ((Library, Boolean) -> Unit)? = null

    inner class ItemLibsRequestViewHolder(itemView: View): RecyclerView.ViewHolder(itemView){
        val tv_name : TextView = itemView.findViewById(R.id.tv_libsReqItem_name)
        val tv_address : TextView = itemView.findViewById(R.id.tv_libsReqItem_address)
        val checkBox : CheckBox = itemView.findViewById(R.id.cb_libsReqItem)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemLibsRequestViewHolder {
        var view = LayoutInflater.from(parent.context).inflate(R.layout.item_libs_request, parent, false)
        return ItemLibsRequestViewHolder(view)
    }

    override fun onBindViewHolder(holder: ItemLibsRequestViewHolder, position: Int) {
        val item = libraries!![position]
        holder.tv_name.text = item.name
        holder.tv_address.text = item.address
        holder.checkBox.isChecked = item.isSelected
        holder.checkBox.setOnClickListener(){
            onItemChecked?.invoke(item, holder.checkBox.isChecked)
        }
    }

    override fun getItemCount(): Int {
        return libraries.size
    }
}