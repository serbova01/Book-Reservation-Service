package com.example.springclient.reotrifit;

import com.example.springclient.model.Basket;
import com.example.springclient.model.HistoryReader;
import com.example.springclient.model.Library;
import com.example.springclient.model.User;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface BasketApi {
    @GET("/rest/basket/get-all-favorite/{id}")
    Call<List<Basket>> getAllFavorites(@Header("Authorization") String token,
            @Path(value = "id", encoded = false) long id);
    @GET("/rest/basket/get-all-basket/{id}")
    Call<List<Basket>> getAllBaskets(@Header("Authorization") String token,
                                     @Path(value = "id", encoded = false) long id);
    @GET("/rest/basket/get-all-basket-by-ids/{ids}")
    Call<List<Basket>> getListBasketsByIds(@Header("Authorization") String token,
                                           @Path(value = "ids", encoded = false) String ids);
    @POST("/rest/basket/view/save")
    Call<Basket> save(@Header("Authorization") String token, @Body Basket basket);
    @POST("/rest/basket/add-basket")
    Call<Basket> addAsBasket(@Header("Authorization") String token, @Body Basket basket);
    @POST("/rest/basket/add-favorite")
    Call<Basket> addAsFavorite(@Header("Authorization") String token, @Body Basket basket);
    @GET("/rest/basket/get/{usId}/{edId}")
    Call<Basket> getByUsIdEdId(@Header("Authorization") String token,
                               @Path(value = "usId", encoded = false) long usId,
                               @Path(value = "edId", encoded = false) long edId);
    @GET("/rest/basket/delete-favorite/{id}")
    Call<Basket> deleteFavorite(@Header("Authorization") String token,
                                @Path(value = "id", encoded = false) long id);
    @GET("/rest/basket/delete-basket/{id}")
    Call<Basket> deleteBasket(@Header("Authorization") String token,
                              @Path(value = "id", encoded = false) long id);
    @GET("/rest/basket/delete-baskets/{ids}")
    Call<Basket> deleteBasket(@Header("Authorization") String token,
                              @Path(value = "ids", encoded = false) String ids);
    @GET("/rest/basket/get-libs-by-choose/{edId}/{userId}")
    Call<List<Library>> getLibsForInsBasket(@Header("Authorization") String token,
                                            @Path(value = "edId", encoded = false) long edId,
                                            @Path(value = "userId", encoded = false) long userId);
}
