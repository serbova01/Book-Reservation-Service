package com.example.springclient.reotrifit;

import com.example.springclient.AuthRequest;
import com.example.springclient.AuthResponse;
import com.example.springclient.model.CodeConfim;
import com.example.springclient.model.Library;
import com.example.springclient.model.Reader;
import com.example.springclient.model.Subscription;
import com.example.springclient.model.User;

import org.jetbrains.annotations.NotNull;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface UserSystemApi {
    @POST("/auth/login")
    Call<AuthResponse> check(@Body AuthRequest user);
    @POST("/rest/user/reg")
    Call<User> registration(@Body User email);
    @POST("/rest/user/check-email")
    Call<Reader> checkByEmail(@Body User email);
    @POST("/rest/user/check-username")
    Call<User> checkByUsername(@Body User username);
    @GET("/mail/send-code")
    Call<CodeConfim> code(@Body CodeConfim codeConfim);
    @GET("/rest/user/get/{id}")
    Call<User> get(@Header("Authorization") String token,
                   @Path(value = "id", encoded = false)  Long id);
    @GET("/rest/user/get-us-and-lib/{usId}/{libId}")
    Call<Subscription> getByUsLib(@Header("Authorization") String token,
                                  @Path(value = "usId", encoded = false)  Long usId,
                                  @Path(value = "libId", encoded = false)  Long libId);
    @GET("/rest/user/get-us-and-libs/{usId}/{libIds}")
    Call<List<Subscription>> getListSubsByUsLibs(@Header("Authorization") String token,
                                                 @Path(value = "usId", encoded = false) Long usId,
                                                 @Path(value = "libIds", encoded = false) String libIds);
    @GET("/rest/user/get-libs-by-user/{id}")
    Call<List<Library>> getLibsByUsEmail(@Header("Authorization") String token,
                                         @Path(value = "id", encoded = false) long id);
    @POST("/rest/user/save")
    Call<User> save(@Body User user);
    @POST("/rest/user/check-reservs")
    Call<Long> checkReservs(@Header("Authorization") String token,
                            @Body User user);
}
