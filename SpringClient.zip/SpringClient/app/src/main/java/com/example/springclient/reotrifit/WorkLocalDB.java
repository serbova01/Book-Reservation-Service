package com.example.springclient.reotrifit;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;
import android.util.Log;

import androidx.annotation.RequiresApi;

import com.example.springclient.model.Basket;
import com.example.springclient.model.Edition;
import com.example.springclient.model.HistoryReader;
import com.example.springclient.model.Library;
import com.example.springclient.model.Reader;
import com.example.springclient.model.ReaderId;
import com.example.springclient.model.Request;
import com.example.springclient.model.Reservation;
import com.example.springclient.model.Subscription;
import com.example.springclient.model.User;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class WorkLocalDB extends SQLiteOpenHelper {
    private static String DB_NAME = "localDB.db";
    private static String DB_PATH = "";
    private static final int DB_VERSION = 9;
    private SQLiteDatabase mDataBase;
    private final Context mContext;
    private boolean mNeedUpdate = false;
    //Context context;

    public void connect() throws Exception {
        try {
            updateDataBase();
        } catch (IOException mIOException) {
            throw new Exception("UnableToUpdateDatabase");
        }
        try {
            mDataBase = getWritableDatabase();
        } catch (SQLException mSQLException) {
            throw mSQLException;
        }
    }

    public WorkLocalDB(Context context) throws Exception {
        super(context, DB_NAME, null, DB_VERSION);
        //this.context = context;
        if (android.os.Build.VERSION.SDK_INT >= 17)
            DB_PATH = context.getApplicationInfo().dataDir + "/databases/";
        else
            DB_PATH = "/data/data/" + context.getPackageName() + "/databases/";
        this.mContext = context;
        copyDataBase();
        this.getReadableDatabase();
        connect();
    }

    public void updateDataBase() throws IOException {
        if (mNeedUpdate) {
            File dbFile = new File(DB_PATH + DB_NAME);
            if (dbFile.exists())
                dbFile.delete();
            copyDataBase();
            mNeedUpdate = false;
        }
    }
    private boolean checkDataBase() {
        File dbFile = new File(DB_PATH + DB_NAME);
        return dbFile.exists();
    }

    private void copyDataBase() {
        if (!checkDataBase()) {
            this.getReadableDatabase();
            this.close();
            try {
                copyDBFile();
            } catch (IOException mIOException) {
                throw new Error("ErrorCopyingDataBase");
            }
        }
    }
    private void copyDBFile() throws IOException {
        InputStream mInput = mContext.getAssets().open(DB_NAME);
        OutputStream mOutput = new FileOutputStream(DB_PATH +
                DB_NAME);
        byte[] mBuffer = new byte[1024];
        int mLength;
        while ((mLength = mInput.read(mBuffer)) > 0)
            mOutput.write(mBuffer, 0, mLength);
        mOutput.flush();
        mOutput.close();
        mInput.close();
    }
    public boolean openDataBase() throws SQLException {
        mDataBase = SQLiteDatabase.openDatabase(DB_PATH + DB_NAME,
                null, SQLiteDatabase.CREATE_IF_NECESSARY);
        return mDataBase != null;
    }

    @Override
    public synchronized void close() {
        if (mDataBase != null)
            mDataBase.close();
        super.close();
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        if (newVersion > oldVersion)
            mNeedUpdate = true;
    }

    public void setUser(User user){
        long num = 0;
        try {
            mDataBase.beginTransaction();
            num = mDataBase.delete("User", "id > 0 or id is null", null);
            num += insertUser(user);
            mDataBase.setTransactionSuccessful();
            mDataBase.endTransaction();
        }catch (Exception ex){
            Log.d(null, ex.getClass() + " error: " + ex.getMessage());
            throw ex;
        }
    }

    private long insertUser(User user) {
        if(user.getLibId()>0){
            Library library = getLibraryById(user.getLibId());
            if(library == null){
                ContentValues newDataForLib = new ContentValues();
                newDataForLib.put("id", user.getLibrary().getId());
                newDataForLib.put("longitude", user.getLibrary().getLongitude());
                newDataForLib.put("email", user.getLibrary().getEmail());
                newDataForLib.put("latitude", user.getLibrary().getLatitude());
                newDataForLib.put("address", user.getLibrary().getAddress());
                newDataForLib.put("name", user.getLibrary().getName());
                newDataForLib.put("cityNumber", user.getLibrary().getCityNumber());
                mDataBase.insert("Library", null, newDataForLib);
            }
        }
        ContentValues newDataForUser = new ContentValues();
        newDataForUser.put("id", user.getId());
        newDataForUser.put("username", user.getUsername());
        newDataForUser.put("email", user.getEmail());
        newDataForUser.put("password", "");
        newDataForUser.put("libId", user.getLibId());
        return mDataBase.insert("User", null, newDataForUser);
    }

    public User getUserWithServer(){
        Cursor cursor = mDataBase.rawQuery("SELECT * FROM User", null);
        cursor.moveToFirst();
        int[] i = new int[]{cursor.getColumnIndex("id"), cursor.getColumnIndex("username"),
                cursor.getColumnIndex("email"), cursor.getColumnIndex("password"),
                cursor.getColumnIndex("role"), cursor.getColumnIndex("libId")};
        long i1 = cursor.getLong(i[0]);

        User user = new User(cursor.getLong(i[0]), cursor.getString(i[1]), true,
                cursor.getString(i[3]), cursor.getString(i[2]), cursor.getString(i[4]),
                cursor.getLong(i[5]));
        cursor.close();
        return user;
    }

    public void setLibraries(List<Library> libraries){
        long num = mDataBase.delete("Library", "id > 0", null);
        for(Library library : libraries){
            ContentValues contentValues = new ContentValues();
            contentValues.put("id", library.getId());
            contentValues.put("name", library.getName());
            contentValues.put("email", library.getEmail());
            contentValues.put("address", library.getAddress());
            contentValues.put("cityNumber", library.getCityNumber());
            contentValues.put("latitude", library.getLatitude());
            contentValues.put("longitude", library.getLongitude());
            num += mDataBase.insert("Library", null, contentValues);
        }
    }

    public List<Library> getLibraries(){
        List<Library> libraries = new ArrayList<>();
        Cursor cursor = mDataBase.rawQuery("SELECT * FROM Library", null);
        cursor.moveToFirst();
        int[] i = new int[]{cursor.getColumnIndex("id"), cursor.getColumnIndex("name"),
                cursor.getColumnIndex("email"), cursor.getColumnIndex("cityNumber"),
                cursor.getColumnIndex("address"), cursor.getColumnIndex("latitude"),
                cursor.getColumnIndex("longitude")};
        while (!cursor.isAfterLast()){
            libraries.add(new Library(cursor.getInt(i[0]), cursor.getString(1),
                    cursor.getString(2), cursor.getString(3), cursor.getString(4),
                    cursor.getInt(i[5]), cursor.getInt(i[6])));
            cursor.moveToNext();
        }
        cursor.close();

        return  libraries;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void setReaders(List<Reader> readers){
        try{
            long num = mDataBase.delete("Reader", "id > 0", null);
            for(Reader reader : readers){
                ContentValues contentValues = new ContentValues();
                contentValues.put("id", reader.getReaderId().getReader_id());
                contentValues.put("subsId", reader.getSubsId());
                contentValues.put("lastName", reader.getLastName());
                contentValues.put("firstName", reader.getFirstName());
                contentValues.put("secondName", reader.getSecondName());
                contentValues.put("email", reader.getEmail());
                contentValues.put("dateRegistration", reader.getDateRegistration().toString());
                contentValues.put("phoneNumber", reader.getPhoneNumber());
                contentValues.put("address", reader.getAddress());
                if (reader.getParentId()>0L){
                    contentValues.put("parentId", reader.getParentId());
                }
                num += mDataBase.insert("Reader", null, contentValues);
            }
        }catch (Exception ex){
            String str = ex.getMessage();
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public List<Reader> getReaders(){
        List<Reader> readers = new ArrayList<>();
        Cursor cursor = mDataBase.rawQuery("SELECT * FROM Reader " +
                "join Subscription on subsId = Subscription.id", null);
        cursor.moveToFirst();
        int[] i = new int[]{cursor.getColumnIndex("subsId"), cursor.getColumnIndex("lastName"),
                cursor.getColumnIndex("firstName"), cursor.getColumnIndex("secondName"),
                cursor.getColumnIndex("email"), cursor.getColumnIndex("dateRegistration"),
                cursor.getColumnIndex("phoneNumber"), cursor.getColumnIndex("numbers"),
                cursor.getColumnIndex("actual_number"), cursor.getColumnIndex("libId"),
                cursor.getColumnIndex("parentId"), cursor.getColumnIndex("address")};
        while (!cursor.isAfterLast()){
            Subscription subscription = new Subscription(cursor.getLong(i[0]), cursor.getString(i[7]),
                    cursor.getInt(i[8]), getLibraryById(cursor.getLong(i[9])));
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDate localDate = LocalDate.parse(cursor.getString(i[5]), formatter);

            Reader reader =new Reader(new ReaderId(cursor.getLong(i[0]), subscription), cursor.getString(i[1]),
                    cursor.getString(i[2]), cursor.getString(i[3]), cursor.getString(i[4]),
                    cursor.getString(i[6]), cursor.getString(i[11]), cursor.getString(i[5])/*localDate*/);
            if(cursor.getInt(i[10])>0){
                reader.setParentId(i[10]);
            }
            readers.add(reader);
            cursor.moveToNext();
        }
        cursor.close();

        return  readers;
    }
    @Nullable
    public Library getLibraryById(long id) {
        if(id > 0){
            Cursor cursor = mDataBase.rawQuery("SELECT * FROM Library where id = " + id, null);
            cursor.moveToFirst();
            int[] i = new int[]{cursor.getColumnIndex("id"), cursor.getColumnIndex("name"),
                    cursor.getColumnIndex("email"), cursor.getColumnIndex("cityNumber"),
                    cursor.getColumnIndex("address"), cursor.getColumnIndex("latitude"),
                    cursor.getColumnIndex("longitude")};
            Library library = new Library(cursor.getInt(i[0]), cursor.getString(1),
                    cursor.getString(2), cursor.getString(3), cursor.getString(4),
                    cursor.getInt(i[5]), cursor.getInt(i[6]));
            cursor.close();
            return library;
        }else
            return null;
    }

    public void setHR(List<HistoryReader> historyReaders, String type){
        for(HistoryReader hr : historyReaders){
            checkIsEditionInDB(hr.getEdition());
            checkIsLibraryInDB(hr.getLibrary());
            ContentValues contentValues = new ContentValues();
            contentValues.put("id", hr.getId());
            contentValues.put("dateIssue", hr.getDateIssueStr());
            contentValues.put("dateReturn", hr.getDateReturnStr());
            contentValues.put("relevance", hr.getRelevance());
            contentValues.put("invNumber", hr.getInvNum());
            contentValues.put("editionId", hr.getEdition().getId());
            contentValues.put("type", type);
            contentValues.put("libId", hr.getLibrary().getId());

            long num = mDataBase.insert("HistoryReader", null, contentValues);
        }
    }

    private void checkIsLibraryInDB(Library library) {
        Cursor cursor = mDataBase.rawQuery("SELECT count(*) FROM Library where id = " + library.getId(), null);
        cursor.moveToFirst();
        long num=0L;
        ContentValues contentValues = new ContentValues();
        contentValues.put("id", library.getId());
        contentValues.put("name", library.getName());
        contentValues.put("email", library.getEmail());
        contentValues.put("address", library.getAddress());
        contentValues.put("cityNumber", library.getCityNumber());
        contentValues.put("latitude", library.getLatitude());
        contentValues.put("longitude", library.getLongitude());
        if(cursor.getInt(0) > 0){
            String where = "id = '" + library.getId() + "'";
            num = mDataBase.update("Library", contentValues, where, null);
        }else{
            num += mDataBase.insert("Library", null, contentValues);
        }
    }

    private void checkIsEditionInDB(Edition edition) {
        Cursor cursor = mDataBase.rawQuery("SELECT count(*) FROM Edition where id = " + edition.getId(), null);
        cursor.moveToFirst();
        long num=0L;
        ContentValues contentValues = new ContentValues();
        contentValues.put("year", edition.getYear());
        contentValues.put("discription", edition.getDiscription());
        contentValues.put("countPage", edition.getCountPage());
        contentValues.put("price", edition.getPrice());
        contentValues.put("publHouseName", edition.getPublHouseName());
        contentValues.put("bookName", edition.getBookName());
        contentValues.put("cycleName", edition.getCycleName());
        contentValues.put("isbn", edition.getIsbn());
        contentValues.put("bookAuthorStr", edition.getBookAuthorStr());
        contentValues.put("genreName", edition.getGenreName());
        if(cursor.getInt(0) > 0){
            String where = "id = '" + edition.getId() + "'";
            num = mDataBase.update("Edition", contentValues, where, null);
        }else{
            contentValues.put("id", edition.getId());
            num += mDataBase.insert("Edition", null, contentValues);
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public List<HistoryReader> getHR(){
        List<HistoryReader> historyReaders = new ArrayList<>();
        Cursor cursor = mDataBase.rawQuery("SELECT * FROM HistoryReader", null);
        cursor.moveToFirst();
        int[] i = new int[]{cursor.getColumnIndex("id"), cursor.getColumnIndex("dateIssue"),
                cursor.getColumnIndex("dateReturn"), cursor.getColumnIndex("relevance"),
                cursor.getColumnIndex("invNumber"), cursor.getColumnIndex("editionId"),
                cursor.getColumnIndex("libId"), cursor.getColumnIndex("type")};
        while (!cursor.isAfterLast()){
            historyReaders.add(new HistoryReader(cursor.getLong(i[0]), cursor.getString(i[1]),
                    cursor.getString(i[2]), cursor.getInt(i[3]), cursor.getString(i[4]),
                    getEditionById(cursor.getInt(i[5])), getLibraryById(cursor.getInt(i[6])),
                    cursor.getString(i[7])));
            cursor.moveToNext();
        }
        cursor.close();

        return  historyReaders;
    }

    public void setRequests(List<Request> requests){
        long num = mDataBase.delete("Request", "id > 0", null);
        for(Request request : requests){
            checkIsEditionInDB(request.getEdition());
            checkIsLibraryInDB(request.getLibrary());
            ContentValues contentValues = new ContentValues();
            contentValues.put("id", request.getId());
            contentValues.put("status", request.getStatus());
            contentValues.put("editionId", request.getEdId());
            contentValues.put("libId", request.getLibId());

            num += mDataBase.insert("Request", null, contentValues);
        }
    }

    public List<Request> getRequests(){
        List<Request> requests = new ArrayList<>();
        Cursor cursor = mDataBase.rawQuery("SELECT * FROM Request", null);
        cursor.moveToFirst();
        int[] i = new int[]{cursor.getColumnIndex("id"), cursor.getColumnIndex("status"),
                cursor.getColumnIndex("libId"), cursor.getColumnIndex("editionId")};
        while (!cursor.isAfterLast()){
            requests.add(new Request(cursor.getLong(i[0]), getLibraryById(i[2]),
                    getEditionById(cursor.getInt(i[3])), cursor.getString(i[1])));
            cursor.moveToNext();
        }
        cursor.close();
        return requests;
    }

    public Edition getEditionById(long id){
        Cursor cursor = mDataBase.rawQuery("SELECT * FROM Edition where id = " + id, null);
        cursor.moveToFirst();
        int[] i = new int[]{cursor.getColumnIndex("id"), cursor.getColumnIndex("year"),
                cursor.getColumnIndex("discription"), cursor.getColumnIndex("countPage"),
                cursor.getColumnIndex("price"), cursor.getColumnIndex("publHouseName"),
                cursor.getColumnIndex("bookName"), cursor.getColumnIndex("cycleName"),
                cursor.getColumnIndex("isbn"), cursor.getColumnIndex("bookAuthorStr"),
                cursor.getColumnIndex("genreName")};
        Edition edition = new Edition();
        if(cursor.getCount()>0){
            edition = new Edition(cursor.getLong(i[0]), cursor.getInt(i[1]), cursor.getString(i[2]),
                    cursor.getInt(i[3]), cursor.getDouble(i[4]), cursor.getString(i[8]),
                    cursor.getString(i[5]), cursor.getString(i[6]), cursor.getString(i[7]),
                    cursor.getString(i[9]), cursor.getString(i[10]));
        }
        cursor.close();
        return edition;
    }

    public void setReservations(List<Reservation> reservations){
        long num = mDataBase.delete("Reservation", "id > 0", null);
        for(Reservation reservation : reservations){
            checkIsEditionInDB(reservation.getEdition());
            checkIsLibraryInDB(reservation.getLibrary());
            ContentValues contentValues = new ContentValues();
            contentValues.put("id", reservation.getId());
            contentValues.put("dateForm", reservation.getDateFormStr());
            if(reservation.getDateReservStr() == null)
                contentValues.put("dateReserv", "");
            else
                contentValues.put("dateReserv", reservation.getDateReservStr());
            contentValues.put("editionId", reservation.getEdId());
            contentValues.put("libId", reservation.getLibId());
            contentValues.put("status", reservation.getStatus());

            num += mDataBase.insert("Reservation", null, contentValues);
        }
    }

    public List<Reservation> getReservation(){
        List<Reservation> reservations = new ArrayList<>();
        Cursor cursor = mDataBase.rawQuery("SELECT * FROM Reservation", null);
        cursor.moveToFirst();
        int[] i = new int[]{cursor.getColumnIndex("id"), cursor.getColumnIndex("status"),
                cursor.getColumnIndex("dateForm"), cursor.getColumnIndex("dateReserv"),
                cursor.getColumnIndex("libId"), cursor.getColumnIndex("editionId")};
        while (!cursor.isAfterLast()){
            reservations.add(new Reservation(cursor.getLong(i[0]), cursor.getString(i[2]),
                    cursor.getString(i[3]), cursor.getString(i[1]),
                    getEditionById(cursor.getInt(i[5])), getLibraryById(cursor.getInt(i[4]))));
            cursor.moveToNext();
        }
        cursor.close();
        return reservations;
    }

    public void updateEditions(List<Edition> editions) {
        for(Edition edition : editions){
            Cursor cursor = mDataBase.rawQuery("SELECT count(*) FROM Edition where id = " + edition.getId(), null);
            cursor.moveToFirst();
            if(cursor.getInt(0)>0){
                long num=0L;
                ContentValues contentValues = new ContentValues();
                contentValues.put("year", edition.getYear());
                contentValues.put("discription", edition.getDiscription());
                contentValues.put("countPage", edition.getCountPage());
                contentValues.put("price", edition.getPrice());
                contentValues.put("publHouseName", edition.getPublHouseName());
                contentValues.put("bookName", edition.getBookName());
                contentValues.put("cycleName", edition.getCycleName());
                contentValues.put("isbn", edition.getIsbn());
                contentValues.put("bookAuthorStr", edition.getBookAuthorStr());
                contentValues.put("genreName", edition.getGenreName());
                String where = "id = '" + edition.getId() + "'";
                num += mDataBase.update("Edition", contentValues, where, null);
            }
        }

    }

    public void setSubscriptions(List<Subscription> subscriptions){
        long num = mDataBase.delete("Subscription", "id > 0", null);
        for(Subscription subscription : subscriptions){
            ContentValues contentValues = new ContentValues();
            contentValues.put("id", subscription.getId());
            contentValues.put("numbers", subscription.getNumbers());
            contentValues.put("actual_number", subscription.getActualNumber());
            contentValues.put("libId", subscription.getLibrary().getId());

            num += mDataBase.insert("Subscription", null, contentValues);
        }
    }

    public List<Subscription> getSubscriptions(){
        List<Subscription> subscriptions = new ArrayList<>();
        Cursor cursor = mDataBase.rawQuery("SELECT * FROM Subscription", null);
        cursor.moveToFirst();
        int[] i = new int[]{cursor.getColumnIndex("id"), cursor.getColumnIndex("numbers"),
                cursor.getColumnIndex("actual_number"), cursor.getColumnIndex("libId")};
        while (!cursor.isAfterLast()){
            subscriptions.add(new Subscription(cursor.getLong(i[0]), cursor.getString(i[1]),
                    cursor.getInt(i[2]), getLibraryById(cursor.getLong(i[3]))));
            cursor.moveToNext();
        }
        cursor.close();
        return subscriptions;
    }

    public void updateLibraries(List<Library> libraries){
        for(Library library : libraries){
            long num=0L;

            setLibrary(library);
        }
    }

    public void setLibrary(@NotNull Library library) {
        Cursor cursor = mDataBase.rawQuery("SELECT count(*) FROM Library where id = " + library.getId(), null);
        cursor.moveToFirst();
        long num = 0;
        if(cursor.getInt(0)>0){
            ContentValues contentValues = new ContentValues();
            contentValues.put("name", library.getName());
            contentValues.put("cityNumber", library.getCityNumber());
            contentValues.put("email", library.getEmail());
            contentValues.put("address", library.getAddress());
            contentValues.put("latitude", library.getLatitude());
            contentValues.put("longitude", library.getLongitude());
            String where = "id = '" + library.getId() + "'";
            num = mDataBase.update("Library", contentValues, where, null);
        }else{
            ContentValues contentValues = new ContentValues();
            contentValues.put("id", library.getId());
            contentValues.put("cityNumber", library.getCityNumber());
            contentValues.put("email", library.getEmail());
            contentValues.put("address", library.getAddress());
            contentValues.put("latitude", library.getLatitude());
            contentValues.put("longitude", library.getLongitude());
            num = mDataBase.insert("Library", null, contentValues);
        }
    }
    public void setFavorites(List<Basket> baskets){
        try{
            long num = mDataBase.delete("Favorites", "id > 0", null);
            for(Basket basket : baskets){
                checkIsEditionInDB(basket.getEdition());
                ContentValues contentValues = new ContentValues();
                contentValues.put("id", basket.getId());
                contentValues.put("count", basket.getCount());
                if(basket.getLibId() > 0){
                    //checkIsLibraryInDB(basket.getLibrary());
                    contentValues.put("libId", basket.getLibId());
                }
                contentValues.put("edId", basket.getEdition().getId());
                num += mDataBase.insert("Favorites", null, contentValues);
            }
        }catch (Exception ex){
            String str = ex.getMessage();
        }
    }

    public List<Basket> getFavorites(){
        List<Basket> baskets = new ArrayList<>();
        Cursor cursor = mDataBase.rawQuery("SELECT * FROM Favorites", null);
        cursor.moveToFirst();
        int[] i = new int[]{cursor.getColumnIndex("id"), cursor.getColumnIndex("count"),
                cursor.getColumnIndex("libId"), cursor.getColumnIndex("edId")};
        while (!cursor.isAfterLast()){
            if(cursor.getLong(i[2]) > 0)
                baskets.add(new Basket(cursor.getLong(i[0]), true, cursor.getInt(i[1]),
                        getLibraryById(cursor.getLong(i[2])), getUserWithServer(),
                        getEditionById(cursor.getLong(i[3]))));
            else
                baskets.add(new Basket(cursor.getLong(i[0]), true, cursor.getInt(i[1]),
                        getUserWithServer(), getEditionById(cursor.getLong(i[3]))));
            cursor.moveToNext();
        }
        cursor.close();

        return  baskets;
    }

    public void setHR(List<HistoryReader> issueds, List<HistoryReader> delayeds) {
        long num = mDataBase.delete("HistoryReader", "id > 0", null);
        if(!issueds.isEmpty()){
            setHR(issueds, "issueds");
        }
        if(!delayeds.isEmpty()){
            setHR(delayeds, "delayeds");
        }
    }
}
