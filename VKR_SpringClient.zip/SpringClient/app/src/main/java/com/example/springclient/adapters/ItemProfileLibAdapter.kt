package com.example.springclient.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.springclient.R
import com.example.springclient.model.Subscription

class ItemProfileLibAdapter(var subscriptions:List<Subscription>, var conServer:Boolean) :
    RecyclerView.Adapter<ItemProfileLibAdapter.ItemProfileLibViewHolder>() {

    var onEditClick: ((Subscription) -> Unit)? = null
    lateinit var view: View

    inner class ItemProfileLibViewHolder(itemView: View): RecyclerView.ViewHolder(itemView){
        val tv_numSubs : TextView = itemView.findViewById(R.id.tv_item_profileLib_numSubs)
        val tv_nameLib : TextView = itemView.findViewById(R.id.tv_item_profileLib_nameLib)
        val tv_edit : TextView = itemView.findViewById(R.id.tv_item_profileLib_edit)
        init {
            tv_edit.setOnClickListener {
                onEditClick?.invoke(subscriptions!![adapterPosition])
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemProfileLibViewHolder {
        view = LayoutInflater.from(parent.context).inflate(R.layout.item_profile_lib, parent, false)
        return ItemProfileLibViewHolder(view)
    }

    override fun onBindViewHolder(holder: ItemProfileLibViewHolder, position: Int) {
        val subscription = subscriptions!![position]
        holder.tv_numSubs.text = subscription.actualNumber.toString()
        holder.tv_nameLib.text = subscription.library.name
        //if(!conServer)
            //holder.tv_edit.visibility = TextView.INVISIBLE
    }

    override fun getItemCount(): Int {
        return subscriptions!!.size
    }
}