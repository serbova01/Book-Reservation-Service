package com.example.springclient.adapters

import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.AppCompatButton
import androidx.recyclerview.widget.RecyclerView
import com.example.springclient.R
import com.example.springclient.model.Reservation

class ItemReservListAdapter(var context: Context, var list:List<Reservation>, var conServer:Boolean):
    RecyclerView.Adapter<ItemReservListAdapter.ItemReservListHolder>() {

    var onItemClick: ((Reservation) -> Unit)? = null
    var onItemClickDelete: ((Reservation) -> Unit)? = null

    inner class ItemReservListHolder(itemView: View): RecyclerView.ViewHolder(itemView){
        val imageView : ImageView = itemView.findViewById(R.id.iv_reservListItem_imageEd)
        val tv_title : TextView = itemView.findViewById(R.id.tv_reservListItem_titleBook)
        val tv_dateForm : TextView = itemView.findViewById(R.id.tv_reservListItem_dateForm)
        val tv_dateReserv : TextView = itemView.findViewById(R.id.tv_reservListItem_dateReserv)
        val tv_discription : TextView = itemView.findViewById(R.id.tv_reservListItem_descriptionBook)
        val tv_status: TextView = itemView.findViewById(R.id.tv_reservListItem_rStatus)
        val button: AppCompatButton = itemView.findViewById(R.id.btn_reservListItem_delete)
        init {
            imageView.setOnClickListener {
                onItemClick?.invoke(list[adapterPosition])
            }
            tv_title.setOnClickListener {
                onItemClick?.invoke(list[adapterPosition])
            }
            if(!conServer)
                button.visibility = AppCompatButton.GONE
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemReservListHolder {
        var view = LayoutInflater.from(parent.context).inflate(R.layout.item_reserv_list, parent, false)
        return ItemReservListHolder(view)
    }

    override fun onBindViewHolder(holder: ItemReservListHolder, position: Int) {
        val item = list[position]
        setImage(item.edition.setImage(), holder)
        holder.tv_title.text = item.edition.bookName
        holder.tv_discription.text = item.edition.bookAuthorStr
        holder.tv_dateForm.text = item.dateFormStr
        holder.tv_dateReserv.text = item.dateReservStr
        holder.tv_status.text = item.status
        if (item.status.equals("бронь")){
            holder.tv_status.setTextColor(Color.GREEN)
        }else
            holder.tv_status.setTextColor(Color.RED)

        holder.button.setOnClickListener(){
            createAlert(item)
        }
    }

    private fun setImage(byteArray: ByteArray, holder: ItemReservListHolder) {
        if(byteArray.isNotEmpty()){
            val bmp = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.size)
            holder.imageView.setImageBitmap(bmp)
        }
    }

    private fun createAlert(reservation: Reservation){
        val alertDialog = AlertDialog.Builder(context)
        alertDialog.setTitle(R.string.deleteReservation)

        alertDialog.setMessage(R.string.confimDeleteReservation)
        alertDialog.setIcon(R.mipmap.ic_launcher)
        alertDialog.setPositiveButton("Да"){dialog, id->
            onItemClickDelete!!(reservation)
        }
        alertDialog.setNegativeButton("Нет"){dialog, id->
            dialog.dismiss()
        }

        alertDialog.show()
    }

    override fun getItemCount(): Int {
        return list.size
    }
}