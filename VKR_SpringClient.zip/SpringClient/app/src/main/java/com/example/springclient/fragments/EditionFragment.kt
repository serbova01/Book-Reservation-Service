package com.example.springclient.fragments

import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.BitmapFactory
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.AppCompatButton
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.springclient.R
import com.example.springclient.adapters.ItemLibEditionAdapter
import com.example.springclient.controllers.RequestActivity
import com.example.springclient.controllers.ViewEditionActivity
import com.example.springclient.databinding.ActivityViewEditionBinding
import com.example.springclient.databinding.FragmentEditionBinding
import com.example.springclient.databinding.FragmentFavoritesBinding
import com.example.springclient.model.*
import com.example.springclient.reotrifit.BasketApi
import com.example.springclient.reotrifit.EditionApi
import com.example.springclient.reotrifit.RetrofitService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class EditionFragment : Fragment() {
    private lateinit var mSettings: SharedPreferences
    private lateinit var retrofit: RetrofitService
    lateinit var binding: FragmentEditionBinding
    lateinit var activity:ViewEditionActivity

    lateinit var user: User
    var userId = 0L
    lateinit var token:String
    lateinit var edition: Edition
    lateinit var libsForEdition:List<ViewLibWithEd>
    var is_logged = false
    var basketFav = Basket()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        activity = requireActivity() as ViewEditionActivity
        init()
    }

    private fun init() {
        mSettings = requireContext().getSharedPreferences("my_storage", Context.MODE_PRIVATE) as SharedPreferences
        retrofit = RetrofitService()

        user = activity.user
        userId = activity.userId
        edition = activity.edition
        libsForEdition = activity.libsForEdition
        is_logged = activity.is_logged
        token = activity.token
        basketFav = activity.basketFav
        initComp()

        initForm()
    }

    private fun initComp() {
        binding.ivFrEditionFavorite.setOnClickListener(){updateFav()}
        binding.btnFrEditionInBasket.setOnClickListener(){onInBasket()}
        binding.btnFrEditionReservation.setOnClickListener(){ onReservation()}
        binding.btnFrEditionOpenRequest.setOnClickListener(){onRequest()}
        if(activity.libsForReserv.isEmpty() || activity.libsForReserv.filter { view ->
                view.count>0 }.isEmpty()){
            binding.btnFrEditionReservation.visibility = AppCompatButton.GONE
            binding.btnFrEditionOpenRequest.visibility = AppCompatButton.VISIBLE
        }
        if(is_logged){
            //if(basketFav.favorite)
                //binding.ivFrEditionFavorite.set
            binding.rlFrEditionActions.visibility = LinearLayout.VISIBLE
        }
    }

    private fun onRequest() {
        val intent = Intent(requireContext(), RequestActivity::class.java)
        intent.putExtra("edId", edition.id)
        startActivity(intent)
    }

    private fun initForm() {
        binding.edition = edition
        initAdapter()
        requireActivity().title = edition.bookName
        var byteArray = edition.setImage()
        if(byteArray.isNotEmpty()){
            val bmp = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.size)
            binding.ivFrEditionImage.setImageBitmap(bmp)
        }
        if(is_logged && basketFav != null && basketFav.favorite){
            binding.ivFrEditionFavorite.setImageResource(R.drawable.ic_favorite_on)
        }else
            binding.ivFrEditionFavorite.setImageResource(R.drawable.ic_favorite_off)
    }
    private fun initAdapter() {
        binding.rvFrEditionLibs.setHasFixedSize(true)
        binding.rvFrEditionLibs.layoutManager = LinearLayoutManager(requireContext())

        var itemLibWithEd = ItemLibEditionAdapter(libsForEdition)
        binding.rvFrEditionLibs.adapter = itemLibWithEd
    }

    fun onInBasket(){
        var basket = Basket()
        basket.edId = edition.id
        basket.usId = userId
        var basketApi = retrofit.retrofit.create(BasketApi::class.java)
        basketApi.addAsBasket(token, basket).enqueue(object : Callback<Basket> {
            override fun onResponse(call: Call<Basket>, response: Response<Basket>) {
                if(response.isSuccessful){
                    //updateAdapter()
                    Toast.makeText(requireActivity(), getString(R.string.addBasketOK),
                        Toast.LENGTH_LONG).show()
                }else
                    Toast.makeText(requireActivity(), getString(R.string.addBasketMistake),
                        Toast.LENGTH_LONG).show()
            }

            override fun onFailure(call: Call<Basket>, t: Throwable) {
                Toast.makeText(requireActivity(), getString(R.string.addBasketMistake),
                    Toast.LENGTH_LONG).show()
            }

        })
    }

    fun onReservation(){
        (requireActivity() as ViewEditionActivity).replaceReservFragment()
    }

    fun updateFav(){
        if(is_logged){
            if(basketFav.favorite){
                deleteFavorite()
            }else
                addFavorite()
        }
    }

    private fun addFavorite() {
        var basketApi = retrofit.retrofit.create(BasketApi::class.java)
        basketApi.addAsFavorite(token, basketFav).enqueue(object : Callback<Basket> {
            override fun onResponse(call: Call<Basket>, response: Response<Basket>) {
                if(response.isSuccessful){
                    basketFav = response.body()!!
                    binding.ivFrEditionFavorite.setImageResource(R.drawable.ic_favorite_on)

                }else
                    showAlert("Не удалось добавить в спискок 'Избранное'. Попробуйте позже.")
            }

            override fun onFailure(call: Call<Basket>, t: Throwable) {
                showAlert("Не удалось добавить в спискок 'Избранное'. Попробуйте позже.")
            }

        })
    }

    private fun deleteFavorite() {
        var basketApi = retrofit.retrofit.create(BasketApi::class.java)
        basketApi.deleteFavorite(token, basketFav.id).enqueue(object : Callback<Basket> {
            override fun onResponse(call: Call<Basket>, response: Response<Basket>) {
                if(response.isSuccessful){
                    basketFav = response.body()!!
                    binding.ivFrEditionFavorite.setImageResource(R.drawable.ic_favorite_off)
                }else
                    showAlert("Не удалось удалить из списка 'Избранное'. Попробуйте позже.")
            }

            override fun onFailure(call: Call<Basket>, t: Throwable) {
                showAlert("Не удалось удалить из списка 'Избранное'. Попробуйте позже.")
            }

        })
    }

    private fun showAlert(str: String) {
        val builder = AlertDialog.Builder(requireContext())
        builder.setPositiveButton("OK", DialogInterface.OnClickListener { dialog, which ->
            dialog.cancel()
        })
        builder.setMessage(str)
        builder.show()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentEditionBinding.inflate(layoutInflater)
        return binding!!.root
    }

    companion object {
        @JvmStatic
        fun newInstance() = EditionFragment()
    }
}