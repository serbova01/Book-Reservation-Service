package com.example.springclient.adapters

import android.graphics.Typeface
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.springclient.R
import com.example.springclient.model.Library
import com.example.springclient.model.ViewLibReservs
import com.example.springclient.model.ViewLibWithEd

class ItemLibEditionAdapter (private val list:List<ViewLibWithEd>)  :
    RecyclerView.Adapter<ItemLibEditionAdapter.ItemLibEditionHolder>(){

    inner class ItemLibEditionHolder(itemView: View): RecyclerView.ViewHolder(itemView){
        val textView_name : TextView = itemView.findViewById(R.id.tv_itemLibEd_name)
        val textView_address : TextView = itemView.findViewById(R.id.tv_itemLibEd_address)
        val textView_num : TextView = itemView.findViewById(R.id.tv_itemLibEd_num)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemLibEditionHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_lib_with_edition, parent, false)
        return ItemLibEditionHolder(view)
    }

    override fun onBindViewHolder(holder: ItemLibEditionHolder, position: Int) {
        var item = list[position]
        holder.textView_name.text = item.library.name
        holder.textView_address.text = item.library.address
        holder.textView_num.text = item.count.toString()
        if (item.reg){
            holder.textView_name.setTypeface(null, Typeface.BOLD)
            holder.textView_address.setTypeface(null, Typeface.BOLD)
            holder.textView_num.setTypeface(null, Typeface.BOLD)
        }
    }

    override fun getItemCount(): Int {
        return list.size
    }
}