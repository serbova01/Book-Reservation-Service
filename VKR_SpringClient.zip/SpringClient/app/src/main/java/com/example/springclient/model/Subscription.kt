package com.example.springclient.model

class Subscription (){
    var id = 0L
    var numbers = ""
    var actualNumber = 0
    var cur_count_issueds = 0
    var max_count_issueds = 0
    var libId = 0L
    var library = Library()

    constructor(id:Long, numbers:String, actual_number:Int, library:Library):this(){
        this.id = id
        this.numbers = numbers
        this.actualNumber = actual_number
        this.libId = library.id
        this.library = library
    }

    constructor(id:Long, numbers:String, actual_number:Int, cur_count_issueds:Int,
                max_count_issueds:Int, libId:Long):this(){
        this.id = id
        this.numbers = numbers
        this.actualNumber = actual_number
        this.cur_count_issueds = cur_count_issueds
        this.max_count_issueds = max_count_issueds
        this.libId = libId
    }
    constructor(id:Long, numbers:String, actual_number:Int, cur_count_issueds:Int,
                max_count_issueds:Int, library:Library):this(){
        this.id = id
        this.numbers = numbers
        this.actualNumber = actual_number
        this.cur_count_issueds = cur_count_issueds
        this.max_count_issueds = max_count_issueds
        this.libId = library.id
        this.library = library
    }
}