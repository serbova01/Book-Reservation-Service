package com.example.springclient.model

import java.time.LocalDate

class HistoryReader() {
    var id = 0L
    var dateIssueStr = ""
    var dateReturnStr = ""
    var relevance = true
    var invNum = ""
    var edId = 0L
    var booName = ""
    var text = ""
    var libId = 0L
    var canBeExtended = false
    lateinit var edition:Edition
    lateinit var library:Library

    var type = "issueds"

    constructor(id:Long, dateIssue:LocalDate, dateReturn:LocalDate, relevance:Boolean, invNum:String,
                libId:Long,edId:Long):this(){
        this.id = id
        this.dateIssueStr = dateIssue.toString()
        this.dateReturnStr = dateReturn.toString()
        this.relevance = relevance
        this.libId = libId
        this.edId = edId
        this.invNum = invNum
    }

    constructor(id:Long, dateIssue:String, dateReturn:String, relevance:Int, invNumber:String,
                edition:Edition, library:Library, type:String):this(){
        this.id = id
        this.dateIssueStr = dateIssue
        this.dateReturnStr = dateReturn
        this.relevance = relevance == 1
        this.edId = edition.id
        this.libId = library.id
        this.edition = edition
        this.library = library
        this.invNum = invNumber
        this.booName = edition.bookName
        this.text = edition.text
        this.type = type
    }
}
