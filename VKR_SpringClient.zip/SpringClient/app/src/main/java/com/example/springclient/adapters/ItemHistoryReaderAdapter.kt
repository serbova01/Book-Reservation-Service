package com.example.springclient.adapters

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.springclient.R
import com.example.springclient.model.Edition
import com.example.springclient.model.HistoryReader

class ItemHistoryReaderAdapter (var historyReader:List<HistoryReader>):
    RecyclerView.Adapter<ItemHistoryReaderAdapter.ItemHistoryReaderHolder>(){

    var onItemClick: ((HistoryReader) -> Unit)? = null

    inner class ItemHistoryReaderHolder(itemView: View): RecyclerView.ViewHolder(itemView){
        val imageView : ImageView = itemView.findViewById(R.id.iv_alsoHRItem_imageEd)
        val tv_title : TextView = itemView.findViewById(R.id.tv_alsoHRItem_titleBook)
        val tv_discription: TextView = itemView.findViewById(R.id.tv_alsoHRItem_discriptionBook)
        val tv_dateIssue : TextView = itemView.findViewById(R.id.tv_alsoHRItem_dateIssue)
        val tv_dateReturn : TextView = itemView.findViewById(R.id.tv_alsoHRItem_dateReturn)
        val tv_libName : TextView = itemView.findViewById(R.id.tv_alsoHRItem_libName)
        val tv_libAddress : TextView = itemView.findViewById(R.id.tv_alsoHRItem_libAddress)
        val tv_invNumber : TextView = itemView.findViewById(R.id.tv_alsoHRItem_invNumber)
        init {
            itemView.setOnClickListener(){
                onItemClick?.invoke(historyReader[adapterPosition])
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemHistoryReaderHolder {
        var view = LayoutInflater.from(parent.context).inflate(R.layout.item_histories_reader, parent, false)
        return ItemHistoryReaderHolder(view)
    }

    override fun onBindViewHolder(holder: ItemHistoryReaderHolder, position: Int) {
        val item = historyReader[position]
        setImage(item.edition.setImage(), holder)
        holder.tv_title.text = item.edition.bookName
        holder.tv_discription.text = item.edition.getShortText()
        holder.tv_dateIssue.text = item.dateIssueStr
        holder.tv_dateReturn.text = item.dateReturnStr
        holder.tv_libName.text = item.library.name
        holder.tv_libAddress.text = item.library.address
        holder.tv_invNumber.text = item.invNum
    }

    private fun setImage(byteArray: ByteArray, holder: ItemHistoryReaderHolder) {
        if(byteArray.isNotEmpty()){
            val bmp = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.size)
            holder.imageView.setImageBitmap(bmp)
        }
    }

    override fun getItemCount(): Int {
        return historyReader.size
    }


}