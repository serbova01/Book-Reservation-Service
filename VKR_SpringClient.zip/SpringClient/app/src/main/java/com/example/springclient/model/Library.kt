package com.example.springclient.model

class Library (){
    var id:Long = 0
    var name:String = ""
    var cityNumber:String = ""
    var email:String = ""
    var address:String = ""
    var latitude:Double? = null
    var longitude:Double? = null
    var isSelected = false

    constructor(name:String, cityNumber:String, email:String, address:String, latitude:Double,
                longitude:Double ):this(){
        this.name = name
        this.cityNumber = cityNumber
        this.email = email
        this.address = address
        this.latitude = latitude
        this.longitude = longitude
    }

    constructor(_id:Long, _name:String, _email:String, _cityNumber:String, _address:String,
                _latitude:Double, _longitude:Double):
            this(_name, _cityNumber, _email, _address, _latitude, _longitude){

        id = _id
        name = _name
        cityNumber = _cityNumber
        email = _email
        address = _address
        latitude = _latitude
        longitude = _longitude
    }
}