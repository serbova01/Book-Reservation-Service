package com.example.springclient.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.springclient.R
import com.example.springclient.model.Reservation
import com.example.springclient.model.ViewLibReservs

class ItemLibReservsAdapter(var context: Context, var list:List<ViewLibReservs>, var conServer:Boolean) :
    RecyclerView.Adapter<ItemLibReservsAdapter.ItemLibReservsHolder>(){
    var onItemClick: ((Reservation) -> Unit)? = null
    var onItemClickDelete: ((Reservation) -> Unit)? = null

    inner class ItemLibReservsHolder(itemView: View): RecyclerView.ViewHolder(itemView){
        val tv_nameLib : TextView = itemView.findViewById(R.id.tv_reservWithLibItem_name)
        val tv_addressLib : TextView = itemView.findViewById(R.id.tv_reservWithLibItem_address)
        val recyclerView : RecyclerView = itemView.findViewById(R.id.rv_reservWithLibItem)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemLibReservsHolder {
        var     view = LayoutInflater.from(parent.context).inflate(R.layout.item_lib_reserv_list, parent, false)
        return ItemLibReservsHolder(view)
    }

    override fun onBindViewHolder(holder: ItemLibReservsHolder, position: Int) {
        var item = list[position]
        var text:String = holder.tv_nameLib.text.toString()
        text+= "\t" + item.libName
        holder.tv_nameLib.text = text
        holder.tv_addressLib.text = item.libAddress
        holder.recyclerView.setHasFixedSize(true)

        holder.recyclerView.layoutManager =
            LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
        var itemReservationAdapter = ItemReservListAdapter(context, item.list, conServer)
        itemReservationAdapter.onItemClick = { item ->
            if(conServer)
                onItemClick!!(item)
        }
        itemReservationAdapter.onItemClickDelete = { item ->
            onItemClickDelete!!(item)
        }
        holder.recyclerView.adapter = itemReservationAdapter
    }

    override fun getItemCount(): Int {
        return list.size
    }
}