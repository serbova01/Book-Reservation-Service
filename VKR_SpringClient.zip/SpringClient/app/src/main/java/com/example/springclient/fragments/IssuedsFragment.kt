package com.example.springclient.fragments

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.AppCompatButton
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.springclient.CheckConNetwork
import com.example.springclient.R
import com.example.springclient.adapters.ItemIssuedsAdapter
import com.example.springclient.controllers.ViewEditionActivity
import com.example.springclient.databinding.FragmentIssuedsBinding
import com.example.springclient.model.*
import com.example.springclient.reotrifit.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class IssuedsFragment : Fragment() {
    lateinit var binding: FragmentIssuedsBinding
    private lateinit var mSettings: SharedPreferences
    private lateinit var mDBHelper: WorkLocalDB
    private lateinit var retrofit: RetrofitService

    lateinit var issueds:List<HistoryReader>
    lateinit var delayedList:List<HistoryReader>
    lateinit var selectedHRList:ArrayList<HistoryReader>
    lateinit var user: User
    var conServer = true
    var userId = 0L
    lateinit var token:String

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        init()
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun init() {
        mSettings = requireContext().getSharedPreferences("my_storage", Context.MODE_PRIVATE) as SharedPreferences
        mDBHelper = WorkLocalDB(requireContext())
        retrofit = RetrofitService()

        binding.rvFrIssuedsIssueds.layoutManager = LinearLayoutManager(requireContext())
        binding.rvFrIssuedsIssueds.setHasFixedSize(true)
        binding.rvFrIssuedsDelayeds.layoutManager = LinearLayoutManager(requireContext())
        binding.rvFrIssuedsDelayeds.setHasFixedSize(true)
        binding.btnFrIssuedsProlong.setOnClickListener(){onProlongList()}
        binding.svFrIssueds.visibility = ScrollView.GONE

        binding.srlFrIssueds.setOnRefreshListener {
            if(conServer)
                initData()
        }
        initData()
    }

    private fun onProlongList() {
        if(selectedHRList.isNotEmpty()){
            val historyReaderApi = retrofit.retrofit.create(HistroryRApi::class.java)
            historyReaderApi.prolongHR(token, getStrListIds()).enqueue(object : Callback<HistoryReader> {

                @RequiresApi(Build.VERSION_CODES.O)
                override fun onResponse(
                    call: Call<HistoryReader>,
                    response: Response<HistoryReader>
                ) {
                    if (response.isSuccessful){
                        initData()
                    }else
                        showAlert("Продлить выданные книги не удалось. Попробуйте позже.")
                }

                override fun onFailure(call: Call<HistoryReader>, t: Throwable) {
                    showAlert("Продлить выданные книги не удалось. Попробуйте позже.")
                }
            })
        }
    }

    private fun getStrListIds(): String {
        var ids = ""
        for(hr in selectedHRList){
            ids += (hr.id.toString() + ", ")
        }
        ids = ids.dropLast(2)
        return ids
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun initData() {
        token = mSettings!!.getString("token", "") as String
        if(CheckConNetwork().checkConnectivity(requireContext())){
            userId = mSettings.getLong("userId", 0)
            if(userId > 0 && token.isNotEmpty()){
                getDataServer(userId)
            }
        }else{
            getLocalDB()
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun getLocalDB() {
        conServer = false
        user = mDBHelper.userWithServer
        issueds = mDBHelper.hr.filter { hr -> hr.type.equals("issueds") }
        delayedList = mDBHelper.hr.filter { hr -> hr.type.equals("delayeds") }
        if(issueds.isEmpty() && delayedList.isEmpty())
            setNoList()
        else{
            initForm()
        }
    }

    private fun initForm() {
        selectedHRList = arrayListOf()
        if(issueds.isEmpty())
            binding.llFrIssuedsIssueds.visibility = LinearLayout.GONE
        else
            setAdapter(binding.rvFrIssuedsIssueds, issueds)
        if(delayedList.isEmpty())
            binding.llFrIssuedsDelayeds.visibility = LinearLayout.GONE
        else
            setAdapter(binding.rvFrIssuedsDelayeds, delayedList)
        binding.srlFrIssueds.isRefreshing = false
        binding.svFrIssueds.visibility = ScrollView.VISIBLE
    }

    private fun setAdapter(recyclerView: RecyclerView, list: List<HistoryReader>) {
        val itemIssuedsAdapter  = ItemIssuedsAdapter(list, conServer)
        itemIssuedsAdapter.onItemClickProlong = { item ->
            prolong(item)
        }
        itemIssuedsAdapter.onItemClick = { item ->
            if(conServer){
                val intent = Intent(context, ViewEditionActivity::class.java)
                intent.putExtra("edId", item.edId)
                startActivity(intent)
            }
        }
        itemIssuedsAdapter.onItemClickSelected = { item, isChecked ->
            if (isChecked){
                if (!selectedHRList.contains(item))
                    selectedHRList.add(item)
            }else{
                if (selectedHRList.contains(item))
                    selectedHRList.remove(item)
            }
            if (selectedHRList.isNotEmpty())
                binding.btnFrIssuedsProlong.visibility = AppCompatButton.VISIBLE
            else
                binding.btnFrIssuedsProlong.visibility = AppCompatButton.GONE
        }
        recyclerView.adapter = itemIssuedsAdapter
    }

    private fun prolong(historyReader: HistoryReader) {
        val historyReaderApi = retrofit.retrofit.create(HistroryRApi::class.java)
        historyReaderApi.prolongHR(token, historyReader.id).enqueue(object : Callback<HistoryReader>{
            override fun onResponse(call: Call<HistoryReader>, response: Response<HistoryReader>) {
                if(response.isSuccessful){
                    val hr = response.body()!!
                    if(hr.relevance){
                        updateList(hr, historyReader)
                    }else
                        removeList(hr)
                    setAdapters()
                }else
                    showAlert("Продлить выданные книги не удалось. Попробуйте позже.")
            }

            override fun onFailure(call: Call<HistoryReader>, t: Throwable) {
                showAlert("Продлить выданные книги не удалось. Попробуйте позже.")
            }

        })
    }

    private fun setAdapters() {
        if(issueds.isEmpty() && delayedList.isEmpty())
            setNoList()
        else{
            if(issueds.isEmpty())
                binding.llFrIssuedsIssueds.visibility = LinearLayout.GONE
            else{
                binding.llFrIssuedsIssueds.visibility = LinearLayout.VISIBLE
                setAdapter(binding.rvFrIssuedsIssueds, issueds)
            }
            if(delayedList.isEmpty())
                binding.llFrIssuedsDelayeds.visibility = LinearLayout.GONE
            else{
                binding.llFrIssuedsDelayeds.visibility = LinearLayout.VISIBLE
                setAdapter(binding.rvFrIssuedsDelayeds, delayedList)
            }

        }
    }

    private fun removeList(historyReader: HistoryReader) {
        val newIssueds = ArrayList<HistoryReader>()
        for(hr in issueds){
            if(hr.id != historyReader.id){
                newIssueds.add(hr)
            }
        }
        issueds = newIssueds
        val newDelayeds = ArrayList<HistoryReader>()
        for(hr in delayedList){
            if(hr.id != historyReader.id){
                newDelayeds.add(hr)
            }
        }
        delayedList = newDelayeds
    }

    private fun updateList(new_hr: HistoryReader, old_hr: HistoryReader) {
        if(new_hr.type.equals(old_hr.type)){
            val newIssueds = ArrayList<HistoryReader>()
            for(hr in issueds){
                if(hr.id != new_hr.id && new_hr.type.equals(hr.type)){
                    newIssueds.add(hr)
                }else{
                    newIssueds.add(new_hr)
                }
            }
            issueds = newIssueds
            val newDelayeds = ArrayList<HistoryReader>()
            for(hr in delayedList){
                if(hr.id != new_hr.id && new_hr.type.equals(hr.type)){
                    newDelayeds.add(hr)
                }else
                    newDelayeds.add(new_hr)
            }
            delayedList = newDelayeds
        }else{
            val list = ArrayList<HistoryReader>()
            list.add(new_hr)
            if(new_hr.type == "issueds"){
                for(hr in issueds){
                    list.add(hr)
                }
                issueds = list
                val newDelayeds = ArrayList<HistoryReader>()
                for(hr in delayedList){
                    if(hr.id != new_hr.id){
                        newDelayeds.add(hr)
                    }
                }
                delayedList = newDelayeds
            }else{
                for(hr in delayedList){
                    list.add(hr)
                }
                delayedList = list
                val newIssueds = ArrayList<HistoryReader>()
                for(hr in issueds){
                    if(hr.id != new_hr.id){
                        newIssueds.add(hr)
                    }
                }
                issueds = newIssueds
            }
        }
    }

    private fun showAlert(str: String) {
        val builder = AlertDialog.Builder(requireContext())
        builder.setPositiveButton("OK") { dialog, which ->
            dialog.cancel()
        }
        builder.setMessage(str)
        builder.show()
    }

    private fun setNoList() {
        binding.tvFrIssuedsNoList.visibility = TextView.VISIBLE
        binding.svFrIssueds.visibility = RecyclerView.GONE
        binding.srlFrIssueds.isRefreshing = false
    }

    private fun getDataServer(userId: Long) {
        binding.srlFrIssueds.isRefreshing = true
        val userSystemApi = retrofit.retrofit.create(UserSystemApi::class.java)
        userSystemApi.get(token, userId).enqueue(object : Callback<User> {
            @RequiresApi(Build.VERSION_CODES.O)
            override fun onResponse(call: Call<User>, response: Response<User>) {
                if(response.isSuccessful){
                    user = response.body()!!
                    val histroryRApi = retrofit.retrofit.create(HistroryRApi::class.java)
                    histroryRApi.getIssedsByUser(token, user.id).enqueue(object :
                        Callback<List<HistoryReader>> {

                        override fun onResponse(
                            call: Call<List<HistoryReader>>,
                            response: Response<List<HistoryReader>>
                        ) {
                            if(response.isSuccessful){
                                issueds = response.body()!!
                                getDelayeds()
                            }else {
                                getLocalDB()
                            }
                        }

                        private fun getDelayeds() {
                            histroryRApi.getDelayedsByUser(token, user.id).enqueue(object :
                                Callback<List<HistoryReader>> {

                                override fun onResponse(
                                    call: Call<List<HistoryReader>>,
                                    response: Response<List<HistoryReader>>
                                ) {
                                    if(response.isSuccessful){
                                        delayedList = response.body()!!
                                        conServer = true
                                        if(delayedList.isNotEmpty() || issueds.isNotEmpty()){
                                            setLocalDB()
                                            initForm()
                                        }else
                                            setNoList()
                                    }else {
                                        getLocalDB()
                                    }
                                }

                                override fun onFailure(call: Call<List<HistoryReader>>, t: Throwable) {
                                    getLocalDB()
                                }

                            })
                        }

                        override fun onFailure(call: Call<List<HistoryReader>>, t: Throwable) {
                            getLocalDB()
                        }

                    })
                }else{
                    getLocalDB()
                }
            }

            @RequiresApi(Build.VERSION_CODES.O)
            override fun onFailure(call: Call<User>, t: Throwable) {
                getLocalDB()
            }

        })
    }

    private fun setLocalDB() {
        mDBHelper.setHR(issueds, delayedList)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        requireActivity().title = getString(R.string.historyReader)
        binding = FragmentIssuedsBinding.inflate(layoutInflater)
        return binding.root
    }

    companion object {
        @JvmStatic
        fun newInstance() = IssuedsFragment()
    }
}