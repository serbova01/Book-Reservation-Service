package com.example.springclient.reotrifit;

import com.example.springclient.model.Basket;
import com.example.springclient.model.Edition;
import com.example.springclient.model.ViewLibWithEd;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Path;

public interface EditionApi {
    @GET("/rest/edition/catalog/get-all")
    Call<ArrayList<Edition>> getAllEditions();
    @GET("/rest/edition/catalog/get/{id}")
    Call<Edition> getEdition(@Path(value = "id", encoded = false) long id);
    @GET("/rest/edition/catalog/get/{edId}/{id}")
    Call<List<ViewLibWithEd>> getLibsWithEdition(@Header("Authorization") String token,
                                                 @Path(value = "edId", encoded = false) long edId,
                                                 @Path(value = "id", encoded = false) long id);
    @GET("/rest/edition/catalog/get-for-reserv/{edId}/{id}")
    Call<List<ViewLibWithEd>> getLibsForReserv(@Header("Authorization") String token,
                                               @Path(value = "edId", encoded = false) long edId,
                                               @Path(value = "id", encoded = false) long id);
}
