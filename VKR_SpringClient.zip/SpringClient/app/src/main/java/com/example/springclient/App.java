package com.example.springclient;

import android.app.Application;

import com.yandex.mapkit.MapKitFactory;

public class App extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        //Parse SDK stuff goes here
        MapKitFactory.setApiKey("f719a147-aaa9-4b70-bc20-0b571f3b6c7a");
    }
}
