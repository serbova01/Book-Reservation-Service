package com.example.springclient.controllers

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.example.springclient.CheckConNetwork
import com.example.springclient.R
import com.example.springclient.fragments.ReservListBasketFragment
import com.example.springclient.fragments.ReservOneBasketFragment
import com.example.springclient.model.Basket
import com.example.springclient.model.User
import com.example.springclient.reotrifit.BasketApi
import com.example.springclient.reotrifit.RetrofitService
import com.example.springclient.reotrifit.UserSystemApi
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.create


class ReservBasketActivity : AppCompatActivity() {
    private lateinit var mSettings: SharedPreferences
    private lateinit var retrofit: RetrofitService
    var fragmentOneBasket = ReservOneBasketFragment()
    var fragmentListBasket = ReservListBasketFragment()

    lateinit var listBasket:List<Basket>
    lateinit var list:Array<Long>
    var userId = 0L
    lateinit var user: User
    lateinit var token:String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reserv_basket)

        title = getString(R.string.reservation)
        list = intent.extras!!.getSerializable("ARRAYLIST") as Array<Long>
        initData()
    }

    private fun initData() {
        mSettings = getSharedPreferences("my_storage", Context.MODE_PRIVATE) as SharedPreferences
        var is_logged = mSettings!!.getBoolean("is_logged", false)
        token = mSettings!!.getString("token", "") as String
        if(CheckConNetwork().checkConnectivity(this) ){
            retrofit = RetrofitService()
            if(is_logged && token.isNotEmpty()) {
                userId = mSettings!!.getLong("userId", 0)
                setUserData()
            }
        }

    }

    private fun setUserData() {
        var userApi = retrofit.retrofit.create(UserSystemApi::class.java)
        userApi.get(token, userId).enqueue(object : Callback<User>{
            override fun onResponse(call: Call<User>, response: Response<User>) {
                if(response.isSuccessful){
                    user = response.body()!!
                    setList()

                }else
                    Toast.makeText(this@ReservBasketActivity, "Не удалось получить данные " +
                            "о пользователе.", Toast.LENGTH_LONG).show()
            }

            override fun onFailure(call: Call<User>, t: Throwable) {
                Toast.makeText(this@ReservBasketActivity, "Не удалось получить данные " +
                        "о пользователе.", Toast.LENGTH_LONG).show()
            }

        })
    }

    private fun setList() {
        var basketApi = retrofit.retrofit.create(BasketApi::class.java)
        var str = convertListToStr()
        basketApi.getListBasketsByIds(token, str).enqueue(object : Callback<List<Basket>>{
            override fun onResponse(call: Call<List<Basket>>, response: Response<List<Basket>>) {
                if(response.isSuccessful){
                    listBasket = response.body()!!
                    if(listBasket.size == 1){
                        replaceFragment(fragmentOneBasket)
                    }else
                        replaceFragment(fragmentListBasket)
                }else{
                    Toast.makeText(this@ReservBasketActivity, getString(R.string.setListBasketReserBad),
                        Toast.LENGTH_LONG).show()
                    onBackPressed()
                }
            }

            override fun onFailure(call: Call<List<Basket>>, t: Throwable) {
                Toast.makeText(this@ReservBasketActivity, getString(R.string.setListBasketReserBad),
                    Toast.LENGTH_LONG).show()
                onBackPressed()
            }

        })
    }

    private fun convertListToStr(): String {
        var str = ""
        for(l in list){
            str += "$l, "
        }
        str = str.removeRange(str.length-2, str.length)
        return str
    }

    private fun replaceFragment(fragment: Fragment){
        if (fragment != null){
            val transaction = supportFragmentManager.beginTransaction()
            transaction.replace(R.id.fl_reservBasket, fragment)
            transaction.commit()
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle presses on the action bar menu items
        when (item.itemId) {
            android.R.id.home -> {
                this.onBackPressed()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onBackPressed() {
        val setIntent = Intent(this, MainActivity::class.java)
        setIntent.putExtra("fragment", 'B')
        startActivity(setIntent)
    }
}