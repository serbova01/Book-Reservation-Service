package com.example.springclient.reotrifit;

import com.example.springclient.model.Basket;
import com.example.springclient.model.Request;
import com.example.springclient.model.Reservation;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface ReservationApi {
    @GET("/rest/reservation/get-all-user/{id}")
    Call<List<Reservation>> getAllByUser(@Header("Authorization") String token,
                                         @Path(value = "id", encoded = false) long id);
    @GET("/rest/reservation/delete/{id}")
    Call<Reservation> delete(@Header("Authorization") String token,
                             @Path(value = "id", encoded = false) long id);
    @POST("/rest/reservation/add-to-reader-basket")
    Call<Reservation> add(@Header("Authorization") String token,
                          @Body Basket reservation);
    @POST("/rest/reservation/add-to-reader")
    Call<Reservation> add(@Header("Authorization") String token,
                          @Body Reservation reservation);
    @GET("/rest/reservation/add-to-reader-basket/{ids}")
    Call<Reservation> add(@Header("Authorization") String token,
                          @Path(value = "ids", encoded = false) String ids);
}
