package com.example.springclient.fragments

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.springclient.CheckConNetwork
import com.example.springclient.R
import com.example.springclient.adapters.ItemRequestsAdapter
import com.example.springclient.controllers.ViewEditionActivity
import com.example.springclient.databinding.FragmentRequestsBinding
import com.example.springclient.model.Request
import com.example.springclient.model.User
import com.example.springclient.reotrifit.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class RequestsFragment : Fragment() {
    lateinit var binding: FragmentRequestsBinding
    private lateinit var mSettings: SharedPreferences
    private lateinit var mDBHelper: WorkLocalDB
    private lateinit var retrofit: RetrofitService
    lateinit var itemRequestsAdapter: ItemRequestsAdapter

    lateinit var requests:List<Request>
    lateinit var user:User
    var conServer = false
    var userId = 0L
    lateinit var token:String

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        init()
    }

    private fun init() {
        mSettings = requireContext().getSharedPreferences("my_storage", Context.MODE_PRIVATE) as SharedPreferences
        mDBHelper = WorkLocalDB(requireContext())
        retrofit = RetrofitService()

        binding.rvFrRequests.layoutManager = LinearLayoutManager(requireContext())
        binding.rvFrRequests.setHasFixedSize(true)
        binding.srlFrRequests.isRefreshing = true
        initData()
        binding.srlFrRequests.setOnRefreshListener {
            initData()
        }
        //initForm()
    }

    private fun initData() {
        token = mSettings!!.getString("token", "") as String
        if(CheckConNetwork().checkConnectivity(requireContext())){
            userId = mSettings!!.getLong("userId", 0)
            if(userId > 0 && token.isNotEmpty()){
                getDataServer(userId)
            }
        }else{
            getLocalDB()
        }
    }

    private fun getLocalDB() {
        conServer = false
        user = mDBHelper.userWithServer
        requests = mDBHelper.requests
        if(requests.isEmpty())
            setNoList()
        else
            initForm()
    }

    private fun getDataServer(userId: Long) {
        val userSystemApi = retrofit.retrofit.create(UserSystemApi::class.java)
        userSystemApi.get(token, userId).enqueue(object : Callback<User> {
            override fun onResponse(call: Call<User>, response: Response<User>) {
                if(response.isSuccessful){
                    user = response.body()!!
                    val requestApi = retrofit.retrofit.create(RequestApi::class.java)
                    requestApi.getAllByUser(token, user.id).enqueue(object : Callback<List<Request>> {
                        override fun onResponse(
                            call: Call<List<Request>>,
                            response: Response<List<Request>>
                        ) {
                            if(response.isSuccessful){
                                requests = response.body()!!
                                conServer = true
                                if(response.body()!!.isNotEmpty()){
                                    setLocalDB()
                                    initForm()
                                }else{
                                    setNoList()
                                }
                            }else
                                getLocalDB()
                        }

                        override fun onFailure(call: Call<List<Request>>, t: Throwable) {
                            showAlert("Ошибка при загрузке списка заявок. Попробуйте позже.")
                            getLocalDB()
                        }


                    })
                }else
                    getLocalDB()
            }

            override fun onFailure(call: Call<User>, t: Throwable) {
                getLocalDB()
            }
        })
    }

    private fun showAlert(str: String) {
        val builder = AlertDialog.Builder(requireContext())
        builder.setMessage(str)
        builder.show()
    }

    private fun setNoList() {
        binding.tvFrRequestsNoList.visibility = TextView.VISIBLE
        binding.svFrRequests.visibility = ScrollView.GONE
        binding.srlFrRequests.isRefreshing = false
    }

    private fun setLocalDB() {
        mDBHelper.requests = requests
    }

    private fun initForm() {
        setAdapter()
        binding.srlFrRequests.isRefreshing = false
    }

    private fun setAdapter() {
        itemRequestsAdapter = ItemRequestsAdapter(requests, conServer)
        itemRequestsAdapter.onItemClick = { item ->
            if(conServer){
                val intent = Intent(context, ViewEditionActivity::class.java)
                intent.putExtra("edId", item.edId)
                startActivity(intent)
            }
        }
        itemRequestsAdapter.onItemClickCancelReq = { item ->
            createAlert(item)
        }
        binding.rvFrRequests.adapter = itemRequestsAdapter
    }
    private fun createAlert(request: Request){
        val alertDialog = AlertDialog.Builder(requireContext())
        alertDialog.setTitle(R.string.deleteRequest)

        alertDialog.setMessage(R.string.confimDeleteRequest)
        alertDialog.setIcon(R.mipmap.ic_launcher)
        alertDialog.setPositiveButton("Да"){dialog, id->
            deleteRequest(request)
        }
        alertDialog.setNegativeButton("Нет"){dialog, id->
            dialog.dismiss()
        }

        alertDialog.show()
    }

    private fun deleteRequest(request: Request) {
        val requestApi = retrofit.retrofit.create(RequestApi::class.java)
        requestApi.delete(token, request.id).enqueue(object : Callback<Request>{
            override fun onResponse(call: Call<Request>, response: Response<Request>) {
                if (response.isSuccessful){
                    removeRequest(request)
                    setLocalDB()
                    if(requests.isEmpty())
                        setNoList()
                    else
                        setAdapter()
                }else
                    showAlert("Не удалось отменить заявку на заказ книги. Попробуйте позже.")
            }

            private fun removeRequest(request: Request) {
                var newRequests = ArrayList<Request>()
                for(fav in requests){
                    if(fav.id != request.id)
                        newRequests.add(fav)
                }
                requests = newRequests
            }

            override fun onFailure(call: Call<Request>, t: Throwable) {
                showAlert("Не удалось отменить заявку на заказ книги. Попробуйте позже.")
            }

        })
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        requireActivity().title = getString(R.string.listRequest)
        binding = FragmentRequestsBinding.inflate(layoutInflater)
        return binding!!.root
    }

    companion object {
        @JvmStatic
        fun newInstance() = RequestsFragment()
    }
}