package com.example.springclient.fragments

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SearchView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.springclient.CheckConNetwork
import com.example.springclient.R
import com.example.springclient.adapters.ItemEditionAdapter
import com.example.springclient.controllers.ViewEditionActivity
import com.example.springclient.databinding.FragmentMainFormCatalogBinding
import com.example.springclient.model.Edition
import com.example.springclient.reotrifit.EditionApi
import com.example.springclient.reotrifit.RetrofitService
import com.example.springclient.reotrifit.WorkLocalDB
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.logging.Level
import java.util.logging.Logger


class CatalogFragment : Fragment() {
    lateinit var binding: FragmentMainFormCatalogBinding
    private lateinit var retrofit: RetrofitService
    private lateinit var mDBHelper: WorkLocalDB
    private lateinit var mSettings: SharedPreferences

    private lateinit var catalog:ArrayList<Edition>
    lateinit var itemCatalogAdapter:ItemEditionAdapter

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        init()
    }

    private fun init() {
        binding.rvFrCatalogEditionList.layoutManager = LinearLayoutManager(requireView().context)
        binding.rvFrCatalogEditionList.setHasFixedSize(true)
        binding.srlEditionList.isRefreshing = true
        initData()
        binding.srlEditionList.setOnRefreshListener {
            initData()
        }

    }

    private fun initData() {
        if(CheckConNetwork().checkConnectivity(requireContext())){
            loadCatalog()
        }else{
            binding.tvFrCatalogNoConNetwork.visibility = TextView.VISIBLE
            binding.rvFrCatalogEditionList.visibility = RecyclerView.GONE
            binding.srlEditionList.isRefreshing = false
        }
    }

    private fun loadCatalog() {
        retrofit = RetrofitService()
        val editionApi:EditionApi = retrofit.retrofit.create(EditionApi::class.java)
        editionApi.allEditions
            .enqueue(object : Callback<ArrayList<Edition>> {
                override fun onFailure(call: Call<ArrayList<Edition>>, t: Throwable) {
                    Toast.makeText(requireContext(), "Ошибка при загрузке каталога книг!!", Toast.LENGTH_SHORT).show()
                    Logger.getLogger(requireView().javaClass.name).log(Level.SEVERE, t.message)
                    setNoList()
                    setConServer(false)
                }

                override fun onResponse(
                    call: Call<ArrayList<Edition>>,
                    response: Response<ArrayList<Edition>>
                ) {
                    if(response.isSuccessful){
                        Toast.makeText(requireView().context, "Save successful!!!", Toast.LENGTH_SHORT).show()
                        catalog = response.body()!!
                        if(catalog.isNotEmpty()){
                            populateListView(response.body())
                            initForm()
                        }else
                            setNoList()
                    }
                }
            })
    }

    private fun setNoList() {
        binding.tvFrCatalogNoConNetwork.visibility = TextView.VISIBLE
        binding.rvFrCatalogEditionList.visibility = RecyclerView.GONE
        binding.srlEditionList.isRefreshing = false
    }

    private fun initForm() {
        binding.tvFrCatalogNoConNetwork.visibility = TextView.GONE
        binding.rvFrCatalogEditionList.visibility = RecyclerView.VISIBLE
        binding.srlEditionList.isRefreshing = false
        setConServer(true)
        binding.svEditionList.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                if (newText != null) {
                    filter(newText)
                }
                return false
            }
        })
    }

    private fun filter(text: String) {
        val filteredlist: ArrayList<Edition> = ArrayList()

        // running a for loop to compare elements.
        for (item in catalog) {
            // checking if the entered string matched with any item of our recycler view.
            if (item.bookName.toLowerCase().contains(text.toLowerCase()) ||
                item.cycleName?.toLowerCase()?.contains(text.toLowerCase()) ?: false ||
                item.publHouseName.toLowerCase().contains(text.toLowerCase()) ||
                item.bookAuthorStr.contains(text.toLowerCase())){
                // if the item is matched we are
                // adding it to our filtered list.
                filteredlist.add(item)
            }
        }
        if (filteredlist.isEmpty()) {
            // if no item is added in filtered list we are
            // displaying a toast message as no data found.
            Toast.makeText(context, "No Data Found..", Toast.LENGTH_SHORT).show()
        } else {
            // at last we are passing that filtered
            // list to our adapter class.
            itemCatalogAdapter.filterList(filteredlist)
        }
    }

    private fun setConServer(b: Boolean) {
        mSettings = requireContext().getSharedPreferences("my_storage", Context.MODE_PRIVATE) as SharedPreferences
        var editor = mSettings.edit()
        editor.putBoolean("is_conServer", b).apply()
    }

    private fun populateListView(body: ArrayList<Edition>?) {
        mDBHelper = WorkLocalDB(requireContext())
        mDBHelper.updateEditions(body)

        itemCatalogAdapter = ItemEditionAdapter(body)
        itemCatalogAdapter.onItemClick = { item ->
            val intent = Intent(context, ViewEditionActivity::class.java)
            intent.putExtra("edId", item.id)
            startActivity(intent)
        }
        binding.rvFrCatalogEditionList.adapter = itemCatalogAdapter
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        requireActivity().title = getString(R.string.catalog)
        binding = FragmentMainFormCatalogBinding.inflate(layoutInflater)
        // Inflate the layout for this fragment

        return binding!!.root
    }

    companion object {
        @JvmStatic
        fun newInstance() = CatalogFragment()
    }
}
