package com.example.springclient.controllers

import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.BitmapFactory
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.widget.FrameLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.springclient.CheckConNetwork
import com.example.springclient.R
import com.example.springclient.adapters.ItemLibsRequestAdapter
import com.example.springclient.databinding.ActivityRequestBinding
import com.example.springclient.databinding.ActivityViewEditionBinding
import com.example.springclient.fragments.EditionFragment
import com.example.springclient.fragments.ResevationFragment
import com.example.springclient.model.Edition
import com.example.springclient.model.Library
import com.example.springclient.model.Request
import com.example.springclient.model.User
import com.example.springclient.reotrifit.EditionApi
import com.example.springclient.reotrifit.RequestApi
import com.example.springclient.reotrifit.RetrofitService
import com.example.springclient.reotrifit.UserSystemApi
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.create

class RequestActivity : AppCompatActivity() {
    private lateinit var mSettings: SharedPreferences
    private lateinit var retrofit: RetrofitService
    lateinit var binding: ActivityRequestBinding
    lateinit var userApi:UserSystemApi

    lateinit var user: User
    var userId = 0L
    var editionId = 0L
    lateinit var edition: Edition
    lateinit var library: Library
    lateinit var listLibs: List<Library>
    lateinit var token:String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityRequestBinding.inflate(layoutInflater)
        setContentView(R.layout.activity_request)
        setContentView(binding.root)
        title = getString(R.string.request)
        init()
    }

    fun init(){
        mSettings = getSharedPreferences("my_storage", Context.MODE_PRIVATE) as SharedPreferences
        retrofit = RetrofitService()

        binding.rvRequestListLib.layoutManager = LinearLayoutManager(this)
        binding.rvRequestListLib.setHasFixedSize(true)
        binding.btnRequestRequest.setOnClickListener(){onAddRequest()}

        initData()
    }

    private fun onAddRequest() {
        if(library != null || library.id > 0){
            var requestApi = retrofit.retrofit.create(RequestApi::class.java)
            var request = Request(editionId, userId, library.id)
            requestApi.add(token, editionId, userId, library.id).enqueue(object : Callback<Request>{
                override fun onResponse(call: Call<Request>, response: Response<Request>) {
                    if(response.isSuccessful){
                        Toast.makeText(this@RequestActivity, getString(R.string.requestOK),
                            Toast.LENGTH_LONG).show()
                        val intent = Intent(this@RequestActivity, MainActivity::class.java)
                        startActivity(intent)
                    }
                }

                override fun onFailure(call: Call<Request>, t: Throwable) {
                    Toast.makeText(this@RequestActivity, getString(R.string.requestBad),
                        Toast.LENGTH_LONG).show()
                }

            })
        }else
            showAlert("Для оформления заявки нужно выбрать библиотеку, в которую будет отправлена " +
                    "заявка на заказ данного издания.")
    }

    private fun showAlert(str: String) {
        val builder = AlertDialog.Builder(this)
        builder.setPositiveButton("OK", DialogInterface.OnClickListener { dialog, which ->
            dialog.cancel()
        })
        builder.setMessage(str)
        builder.show()
    }

    private fun initData() {
        if(CheckConNetwork().checkConnectivity(this) ){
            retrofit = RetrofitService()
            userId = mSettings!!.getLong("userId", 0)
            token = mSettings!!.getString("token", "")as String
            if(token.isNotEmpty()){
                val bundle = intent.extras
                if (bundle != null){
                    editionId = bundle.getLong("edId")
                    if(editionId != null){
                        userApi = retrofit.retrofit.create(UserSystemApi::class.java)
                        setDataServer()
                    }else
                        noCon()
                }else
                    noCon()
            }else
                noCon()

        }else
            noCon()
    }

    private fun noCon() {
        Toast.makeText(this, "Произошла ошибка. Попробуйте позже.", Toast.LENGTH_LONG).show()
        val intent = Intent(this, ViewEditionActivity::class.java)
        intent.putExtra("edId", editionId)
        startActivity(intent)
    }

    private fun setDataServer() {
        userApi.get(token, userId).enqueue(object : Callback<User> {
            override fun onResponse(call: Call<User>, response: Response<User>) {
                if(response.isSuccessful){
                    user = response.body()!!
                    setEd()
                }else
                    noCon()
            }

            override fun onFailure(call: Call<User>, t: Throwable) {
                noCon()
            }
        })
    }

    private fun setEd() {
        var editionApi = retrofit.retrofit.create(EditionApi::class.java)
        editionApi.getEdition(editionId).enqueue(object : Callback<Edition>{
            override fun onResponse(call: Call<Edition>, response: Response<Edition>) {
                if(response.isSuccessful){
                    edition = response.body()!!
                    setLibraries()
                }else
                    noCon()
            }

            override fun onFailure(call: Call<Edition>, t: Throwable) {
                noCon()
            }

        })
    }

    private fun setLibraries() {
        userApi.getLibsByUsEmail(token, user.id).enqueue(object : Callback<List<Library>>{
            override fun onResponse(call: Call<List<Library>>, response: Response<List<Library>>) {
                if(response.isSuccessful){
                    listLibs = response.body()!!
                    initForm()
                }else
                    noCon()
            }

            override fun onFailure(call: Call<List<Library>>, t: Throwable) {
                noCon()
            }

        })
    }

    private fun initForm() {
        var byteArray = edition.setImage()
        if(byteArray.isNotEmpty()){
            val bmp = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.size)
            binding.ivRequestImage.setImageBitmap(bmp)
        }
        binding.edition = edition
        setAdapter()
    }

    private fun setAdapter() {
        var itemLibsRequestAdapter = ItemLibsRequestAdapter(listLibs)
        itemLibsRequestAdapter.onItemChecked = {item, isChecked ->
            if(isChecked){
                library = item
                listLibs.filter { lib -> lib.id != item.id }.forEach{lib ->
                    lib.isSelected = false
                }
            }else
                library = Library()
            listLibs.first { lib -> lib.id == item.id }.isSelected = isChecked
            setAdapter()
        }
        binding.rvRequestListLib.adapter = itemLibsRequestAdapter
    }

    /*override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle presses on the action bar menu items
        when (item.itemId) {
            android.R.id.home -> {
                this.onBackPressed()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onBackPressed() {
        val setIntent = Intent(this, ViewEditionActivity::class.java)
        startActivity(setIntent)
    }*/
}