package com.example.springclient.model

import android.location.Address

class Request (edId:Long, usId:Long, libId:Long){
    var id = 0L
    var libId = libId
    var edId = edId
    var usId = usId
    var bookName = ""
    var text = ""
    var imagePath = ""
    var libName = ""
    var libAddress = ""
    lateinit var library:Library
    lateinit var edition:Edition
    var status = ""

    constructor(id:Long, libId:Long, edId:Long, bookName:String, text:String, imagePath:String,
                libName:String, libAddress:String, status:String):this(edId, 0L, libId){
        this.id = id
        this.bookName = bookName
        this.text = text
        this.imagePath = imagePath
        this.libName = libName
        this.libAddress = libAddress
        this.status = status
                }

    constructor(id:Long, library: Library, edition:Edition, status:String): this(id, library.id,
        edition.id, edition.bookName, edition.text, "", library.name, library.address,
        status){
        this.library = library
        this.edition = edition
    }
}