package com.example.springclient.model

import android.util.Base64

class Edition() {
    var id = 0L
    var year = 0
    var discription: String? = null
    var countPage = 0
    var isbn = ""
    var price = 0.0
    var publHouseName = ""
    var bookName = ""
    var cycleName: String? = null
    var bookAuthorStr = ""
    var genreName = ""
    var text = ""
    var imagePath:String = ""
    var imageArr:ByteArray = Base64.decode(imagePath, Base64.DEFAULT);

    constructor(id:Long, year : Int, discription : String?, countPage : Int,
                price : Double, isbn:String, publHouseName:String, bookName : String,
                cycleName : String?, bookAuthorStr:String, genreName:String):this(){
        this.id = id
        this.year = year
        this.discription = discription
        this.countPage = countPage
        this.price = price
        this.isbn = isbn
        this.publHouseName = publHouseName
        this.bookName = bookName
        this.cycleName = cycleName
        this.bookAuthorStr = bookAuthorStr
        this.genreName = genreName
                }

    fun getShortText(): String {
        var str = "${publHouseName}"

        if (cycleName != null)
            str += "\n${cycleName!!}"
        var authorStr:String = bookAuthorStr
        return "$str\n$authorStr"
    }

    fun setImage():ByteArray{
        return Base64.decode(imagePath, Base64.DEFAULT)
    }
}
