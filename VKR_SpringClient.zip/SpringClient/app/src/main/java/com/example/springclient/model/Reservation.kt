package com.example.springclient.model

import android.os.Build
import androidx.annotation.RequiresApi
import java.time.LocalDate

class Reservation (edition: Edition, user: User, library: Library) {
    var id = 0L
    var dateFormStr = ""
    var dateReservStr = ""
    var edId = edition.id
    var bookName = edition.bookName
    var text = edition.text
    var imagePath = edition.imagePath
    var maxCopies = 0L
    var libId = library.id
    var libName = library.name
    var libAddress = library.address
    var library:Library = library
    var edition:Edition = edition
    var user:User = user
    var status = ""
    var subsId = 0L

    constructor(id:Long, dateForm:String, dateReserv:String, libId: Long, edId:Long, bookName:String,
                text:String, imagePath:String, maxCopies:Long, libName:String, libAddress:String,
                status:String):this(Edition(), User(), Library()){
        this.id = id
        this.dateFormStr = dateForm
        this.dateReservStr = dateReserv
        this.edId = edId
        this.bookName = bookName
        this.text = text
        this.imagePath = imagePath
        this.maxCopies = maxCopies
        this.libId = libId
        this.libName = libName
        this.libAddress = libAddress
        this.status = status
        this.user = User()
                }

    constructor(id:Long, dateForm:LocalDate, dateReserv:LocalDate, status:String, maxCopies:Long,
                edition:Edition, library: Library):this(id, dateForm.toString(), dateReserv.toString(),
        library.id, edition.id, edition.bookName, edition.text, "", maxCopies, library.name,
        library.address, status){
        this.library = library
        this.edition = edition
    }

    constructor(id:Long, dateForm:String, dateReserv:String, status:String, maxCopies:Long, edition:Edition,
                library: Library)
            :this(id, dateForm, dateReserv, library.id, edition.id, edition.bookName, edition.text,
        "", maxCopies, library.name, library.address, status){
        this.library = library
        this.edition = edition
    }

    constructor(id:Long, dateForm:String, dateReserv:String, status:String, edition:Edition,
                library: Library)
            :this(id, dateForm, dateReserv, library.id, edition.id, edition.bookName, edition.text,
        "", 0, library.name, library.address, status){
        this.library = library
        this.edition = edition
    }

    @RequiresApi(Build.VERSION_CODES.O)
    fun setData(){
        bookName = edition.bookName
    }
}