package com.example.springclient.reotrifit;

import com.example.springclient.model.Library;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface LibraryApi {
    @GET("/rest/library/get/{id}")
    Call<Library> getLibrary(@Header("Authorization") String token,
                             @Path(value = "id", encoded = false)  Long id);

    @POST("/rest/library/save")
    Call<Library> save(@Header("Authorization") String token,
                       @Body Library library);
}
