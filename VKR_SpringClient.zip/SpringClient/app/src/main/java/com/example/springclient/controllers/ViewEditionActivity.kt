package com.example.springclient.controllers

import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.BitmapFactory
import android.os.Bundle
import android.widget.FrameLayout
import android.widget.ScrollView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.springclient.CheckConNetwork
import com.example.springclient.R
import com.example.springclient.adapters.ItemLibEditionAdapter
import com.example.springclient.databinding.ActivityViewEditionBinding
import com.example.springclient.fragments.EditionFragment
import com.example.springclient.fragments.ResevationFragment
import com.example.springclient.model.*
import com.example.springclient.reotrifit.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class ViewEditionActivity : AppCompatActivity() {
    private lateinit var mSettings: SharedPreferences
    private lateinit var retrofit: RetrofitService
    lateinit var binding: ActivityViewEditionBinding
    lateinit var editionApi:EditionApi

    lateinit var editionFragment: EditionFragment
    lateinit var reservationFragment: ResevationFragment
    var activFragment = ""

    lateinit var user: User
    var userId = 0L
    var editionId = 0L
    lateinit var edition:Edition
    lateinit var libsForEdition:List<ViewLibWithEd>
    lateinit var libsForReserv:List<ViewLibWithEd>
    var is_logged = false
    lateinit var token:String
    var selectedLib = ViewLibWithEd()
    var basketFav = Basket()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //binding = DataBindingUtil.setContentView<ActivityViewEditionBinding>(this, R.layout.activity_view_edition)
        binding = ActivityViewEditionBinding.inflate(layoutInflater)
        setContentView(R.layout.activity_view_edition)
        setContentView(binding.root)
        title = getString(R.string.ediition)

        init()
    }

    fun init(){
        mSettings = getSharedPreferences("my_storage", Context.MODE_PRIVATE) as SharedPreferences
        retrofit = RetrofitService()

        editionFragment = EditionFragment()
        reservationFragment = ResevationFragment()

        binding.srlViewEdition.isRefreshing = true
        binding.srlViewEdition.setOnRefreshListener {
            initData()
        }
        activFragment = "editionFragment"
        initData()
    }

    private fun initData() {
        is_logged = mSettings!!.getBoolean("is_logged", false)
        token = mSettings!!.getString("token", "") as String
        if(CheckConNetwork().checkConnectivity(this) ){
            retrofit = RetrofitService()
            if(is_logged && token.isNotEmpty()) {
                userId = mSettings!!.getLong("userId", 0)
            }
            val bundle = intent.extras
            if (bundle != null){
                editionId = bundle.getLong("edId")
                if(editionId != null){
                    setDataServer()
                }else
                    noCon()
            }else
                noCon()
        }else
            noCon()
    }

    private fun noCon() {
        binding.flViewEdition.visibility = FrameLayout.GONE
        Toast.makeText(this, "Произошла ошибка. Попробуйте позже.",Toast.LENGTH_LONG).show()
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }

    private fun setDataServer() {
        if(is_logged){
            var userApi = retrofit.retrofit.create(UserSystemApi::class.java)
            userApi.get(token, userId).enqueue(object : Callback<User>{
                override fun onResponse(call: Call<User>, response: Response<User>) {
                    if(response.isSuccessful){
                        user = response.body()!!
                        setEd()
                    }else
                        noCon()
                }

                override fun onFailure(call: Call<User>, t: Throwable) {
                    noCon()
                }
            })
        }else{
            user = User()
            setEd()
        }
    }

    private fun setEd() {
        editionApi = retrofit.retrofit.create(EditionApi::class.java)
        editionApi.getEdition(editionId).enqueue(object : Callback<Edition>{
            override fun onResponse(call: Call<Edition>, response: Response<Edition>) {
                if(response.isSuccessful){
                    edition = response.body()!!
                    if(is_logged)
                        setFavorite()
                    else
                        setLists()
                }else
                    noCon()
            }

            override fun onFailure(call: Call<Edition>, t: Throwable) {
                noCon()
            }

        })
    }

    private fun setFavorite() {
        var basketApi = retrofit.retrofit.create(BasketApi::class.java)
        basketApi.getByUsIdEdId(token, userId, editionId).enqueue(object : Callback<Basket>{
            override fun onResponse(call: Call<Basket>, response: Response<Basket>) {
                if(response.isSuccessful){
                    basketFav = response.body()!!
                    setLists()
                }
            }

            override fun onFailure(call: Call<Basket>, t: Throwable) {
                showAlert("Ошибка при загрузке списка 'Избранное'!!")
            }

        })
    }

    private fun setLists() {
        setListLbForEd()

    }

    private fun setListLbForEd() {
        var email = "1"
        if(user.id>0)
            email = user.email
        editionApi.getLibsWithEdition(token, editionId, user.id).enqueue(object : Callback<List<ViewLibWithEd>>{
            override fun onResponse(
                call: Call<List<ViewLibWithEd>>,
                response: Response<List<ViewLibWithEd>>
            ) {
                if(response.isSuccessful){
                    libsForEdition = response.body()!!
                    setLibsForReserv1()
                    //initForm()
                }else
                    noCon()
            }

            private fun setLibsForReserv1() {
                var list:ArrayList<ViewLibWithEd> = ArrayList()
                for(libs in libsForEdition){
                    if(libs.reg && libs.count > 0)
                        list.add(libs)
                }
                libsForReserv = list
                replaceActivFragment()
                binding.srlViewEdition.isRefreshing = false
            }

            override fun onFailure(call: Call<List<ViewLibWithEd>>, t: Throwable) {
                noCon()
            }

        })
    }

    private fun setLibsForReserv() {
        editionApi.getLibsForReserv(token, edition.id, user.id).enqueue(object : Callback<List<ViewLibWithEd>>{
            override fun onResponse(
                call: Call<List<ViewLibWithEd>>,
                response: Response<List<ViewLibWithEd>>
            ) {
                if(response.isSuccessful){
                    libsForReserv = response.body()!!
                    replaceActivFragment()
                    binding.srlViewEdition.isRefreshing = false
                }else
                    noCon()
            }

            override fun onFailure(call: Call<List<ViewLibWithEd>>, t: Throwable) {
                noCon()
            }

        })
    }

    private fun replaceActivFragment() {
        when (activFragment){
            "editionFragment" -> replaceFragment(editionFragment)
            "reservationFragment" -> replaceReservFragment()
        }
    }

    private fun replaceFragment(fragment: Fragment){
        if (fragment != null){
            val transaction = supportFragmentManager.beginTransaction()
            transaction.replace(R.id.fl_viewEdition, fragment)
            transaction.commit()
        }
    }

    private fun showAlert(str: String) {
        val builder = AlertDialog.Builder(this)
        builder.setPositiveButton("OK", DialogInterface.OnClickListener { dialog, which ->
            dialog.cancel()
        })
        builder.setMessage(str)
        builder.show()
    }

    fun replaceReservFragment() {
        activFragment = "reservationFragment"
        replaceFragment(reservationFragment)
    }
}