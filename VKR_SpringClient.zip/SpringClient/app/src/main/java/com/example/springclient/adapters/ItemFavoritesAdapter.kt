package com.example.springclient.adapters

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.springclient.R
import com.example.springclient.model.Basket

class ItemFavoritesAdapter(var favorites: List<Basket>, var conServer:Boolean) :
    RecyclerView.Adapter<ItemFavoritesAdapter.ItemFavoritesViewHolder>(){

    var onItemClick: ((Basket) -> Unit)? = null
    var onItemClickBasket: ((Basket) -> Unit)? = null
    var onItemClickDelete: ((Basket) -> Unit)? = null

    inner class ItemFavoritesViewHolder(itemView: View): RecyclerView.ViewHolder(itemView){
        val imageView : ImageView = itemView.findViewById(R.id.iv_favorites_imageEd)
        val textView_title : TextView = itemView.findViewById(R.id.tv_favorites_nameItem)
        val textView_text : TextView = itemView.findViewById(R.id.tv_favorites_discriptionItem)
        val btn_delete: ImageButton = itemView.findViewById(R.id.ib_favorites_delete)
        val btn_basket: ImageButton = itemView.findViewById(R.id.ib_favorites_basket)
        init {
            itemView.setOnClickListener {
                onItemClick?.invoke(favorites[adapterPosition])
            }
            if(conServer){
                btn_basket.setOnClickListener(){
                    if(conServer)
                        onItemClickBasket?.invoke(favorites[adapterPosition])
                }
            }else{
                btn_basket.visibility = ImageButton.INVISIBLE
                btn_delete.visibility = ImageButton.INVISIBLE
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemFavoritesViewHolder {
        var view = LayoutInflater.from(parent.context).inflate(R.layout.item_favorites_layout, parent, false)

        return ItemFavoritesViewHolder(view)
    }

    override fun onBindViewHolder(holder: ItemFavoritesViewHolder, position: Int) {
        val item = favorites[position]
        setImage(item.edition.setImage(), holder)
        holder.textView_title.text = item.edition.bookName
        holder.textView_text.text = item.edition.getShortText()
        holder.btn_delete.setOnClickListener(){
            onItemClickDelete?.invoke(item)
                favorites.toMutableList().remove(item)
        }
    }
    private fun setImage(byteArray: ByteArray, holder: ItemFavoritesViewHolder) {
        if(byteArray.isNotEmpty()){
            val bmp = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.size)
            holder.imageView.setImageBitmap(bmp)
        }
    }
    fun deleteItem(item : Basket){

    }

    override fun getItemCount(): Int {
        return favorites.size
    }
}