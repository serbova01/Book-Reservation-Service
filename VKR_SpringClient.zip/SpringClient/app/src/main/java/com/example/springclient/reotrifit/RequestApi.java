package com.example.springclient.reotrifit;

import com.example.springclient.model.Reader;
import com.example.springclient.model.Request;
import com.example.springclient.model.User;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface RequestApi {
    @GET("/rest/request/get-all-user/{id}")
    Call<List<Request>> getAllByUser(@Header("Authorization") String token,
                                     @Path(value = "id", encoded = false) long id);
    @GET("/rest/request/delete/{id}")
    Call<Request> delete(@Header("Authorization") String token,
                         @Path(value = "id", encoded = false) long id);
    @POST("/rest/request/add/{id}")
    Call<Request> add(@Header("Authorization") String token,
                      @Path(value = "id", encoded = false) long id, @Body Request request);
    @POST("/rest/request/add")
    Call<Request> add(@Header("Authorization") String token,
                      @Body Request request);
    @POST("/rest/request/add/{edId}/{usId}/{libId}")
    Call<Request> add(@Header("Authorization") String token,
                      @Path(value = "edId", encoded = false) long edId,
                      @Path(value = "usId", encoded = false) long usId,
                      @Path(value = "libId", encoded = false) long libId);
}
