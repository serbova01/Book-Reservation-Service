package com.example.springclient.fragments

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.NonNull
import androidx.annotation.RequiresApi
import androidx.appcompat.widget.AppCompatButton
import androidx.fragment.app.Fragment
import com.example.springclient.CheckConNetwork
import com.example.springclient.R
import com.example.springclient.controllers.EditProfileActivity
import com.example.springclient.databinding.FragmentViewReaderBinding
import com.example.springclient.model.*
import com.example.springclient.reotrifit.*
import com.yandex.mapkit.Animation
import com.yandex.mapkit.MapKitFactory
import com.yandex.mapkit.geometry.Point
import com.yandex.mapkit.layers.GeoObjectTapEvent
import com.yandex.mapkit.layers.GeoObjectTapListener
import com.yandex.mapkit.map.CameraPosition
import com.yandex.mapkit.map.GeoObjectSelectionMetadata
import com.yandex.mapkit.map.InputListener
import com.yandex.mapkit.map.Map
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class ViewReaderFragment : Fragment(), GeoObjectTapListener, InputListener {

    lateinit var binding: FragmentViewReaderBinding
    private lateinit var mSettings: SharedPreferences
    private lateinit var mDBHelper: WorkLocalDB
    private lateinit var retrofit: RetrofitService

    lateinit var reader: Reader
    lateinit var library: Library
    lateinit var subscription: Subscription
    var user: User = User()
    var subsId:Long = 0L
    var conServer = false
    lateinit var token:String

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        init()
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun init() {
        (requireActivity() as EditProfileActivity).activeFr = "VR"
        binding.llFrViewReaderContent.visibility = LinearLayout.INVISIBLE
        binding.srlFrViewReader.isRefreshing = true
        binding.btnFrViewReaderEdit.setOnClickListener(){onEditReader()}
        binding.headerFrViewReader.btnHeaderBack.setOnClickListener(){
            (requireActivity() as EditProfileActivity).activeFr = "EP"
            (requireActivity() as EditProfileActivity).replaceFragment(EditProfileFragment())}
        binding.tvFrViewReaderHistoriesReader.setOnClickListener(){
            var historyReaderFragment = HistoryReaderFragment()
            historyReaderFragment.subsId = subsId
            (requireActivity() as EditProfileActivity).replaceFragment(historyReaderFragment)}
        subsId = (requireActivity() as EditProfileActivity).subsId
        initData()
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun initData() {
        mSettings = requireContext().getSharedPreferences("my_storage", Context.MODE_PRIVATE) as SharedPreferences
        mDBHelper = WorkLocalDB(requireContext())
        val is_logged = mSettings!!.getBoolean("is_logged", false)
        token = mSettings!!.getString("token", "") as String
        if(is_logged && token.isNotEmpty()){
            if(CheckConNetwork().checkConnectivity(requireContext())&&
                mSettings!!.getBoolean("is_conServer", false)){
                val userId = mSettings!!.getLong("userId", 0)
                if(userId > 0){
                    retrofit = RetrofitService()
                    setDataServer(userId)
                }
            }else{
                noConServer()
            }

        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun setDataLocalDB() {
        user = mDBHelper.userWithServer
        var list = mDBHelper.readers
        reader = mDBHelper.readers.first { reader -> reader.subsId == subsId }
        subscription = mDBHelper.subscriptions.first { subs -> subs.id == subsId }
        library = mDBHelper.getLibraryById(subscription.libId)!!
        initForm()
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun setDataServer(id: Long) {
        //mDBHelper = WorkLocalDB(requireContext())
        val userApi = retrofit.retrofit.create(UserSystemApi::class.java)
        userApi.get(token, id).enqueue(object : Callback<User>{
            override fun onResponse(call: Call<User>, response: Response<User>) {
                user = response.body()!!
                val subscriptionApi = retrofit.retrofit.create(SubscriptionApi::class.java)
                subscriptionApi.getSubscription(token, subsId).enqueue(object : Callback<Subscription>{
                    override fun onResponse(call: Call<Subscription>, response: Response<Subscription>) {
                        if(response.isSuccessful){
                            subscription = response.body()!!
                            getLib()
                        }
                    }

                    override fun onFailure(call: Call<Subscription>, t: Throwable) {
                        Toast.makeText(requireContext(), "Ошибка получения данных абонемента.",
                            Toast.LENGTH_LONG)
                        conServer = false
                        noConServer()
                    }

                })

            }

            override fun onFailure(call: Call<User>, t: Throwable) {
                Toast.makeText(requireContext(), "Ошибка получения данных пользователя.", Toast.LENGTH_LONG)
                conServer = false
                noConServer()
            }

        })
    }

    private fun getLib() {
        val libraryApi = retrofit.retrofit.create(LibraryApi::class.java)
        libraryApi.getLibrary(token, subscription.libId).enqueue(object : Callback<Library>{
            override fun onResponse( call: Call<Library>, response: Response<Library>) {
                if(response.isSuccessful){
                    library = response.body()!!
                    val readerApi = retrofit.retrofit.create(ReaderApi::class.java)
                    readerApi.getAllReaderByEmail(token, user.id).enqueue(
                        object : Callback<List<Reader>>{
                            @RequiresApi(Build.VERSION_CODES.O)
                            override fun onResponse(call: Call<List<Reader>>,
                                                    response: Response<List<Reader>>) {
                                conServer = response.isSuccessful
                                if(response.isSuccessful){
                                    reader = response.body()!!.first { reader ->
                                        reader.subsId == subsId }
                                    updateLocalDB(response.body()!!)
                                    initForm()
                                }else {
                                    noConServer()
                                }
                            }

                            @RequiresApi(Build.VERSION_CODES.O)
                            override fun onFailure(call: Call<List<Reader>>, t: Throwable) {
                                Toast.makeText(requireContext(), "Ошибка получения данных читателя.",
                                    Toast.LENGTH_LONG)
                                conServer = false
                                noConServer()
                            }

                        })
                }
            }

            @RequiresApi(Build.VERSION_CODES.O)
            override fun onFailure(call: Call<Library>, t: Throwable) {
                Toast.makeText(requireContext(), "Ошибка получения данных библиотеки.", Toast.LENGTH_LONG)
                conServer = false
                noConServer()
            }

        })
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun updateLocalDB(readers:List<Reader>) {
        mDBHelper.setUser(user)
        mDBHelper.setLibrary(library)
        mDBHelper.readers = readers
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun noConServer() {
        setDataLocalDB()
        binding.btnFrViewReaderEdit.visibility = AppCompatButton.INVISIBLE
        binding.tvFrViewReaderHistoriesReader.visibility = AppCompatButton.INVISIBLE
    }

    private fun initForm() {
        binding.headerFrViewReader.tvUser.text = user.username
        binding.headerFrViewReader.btnFrProfileEditProfile.visibility = AppCompatButton.INVISIBLE
        binding.btnFrViewReaderEdit.visibility = AppCompatButton.VISIBLE
        if(reader != null){
            binding.reader = reader
            if(reader.parentId > 0)
                binding.tvFrViewReaderIsChildReader.visibility = TextView.VISIBLE
            else binding.tvFrViewReaderIsChildReader.visibility = TextView.GONE
            if(library != null){
                binding.library = library
                setMap(library)
            }

        }
        binding.srlFrViewReader.isRefreshing = false
        binding.llFrViewReaderContent.visibility = LinearLayout.VISIBLE
        binding.tvFrViewReaderSubsNumber.text = subscription.numbers
    }

    private fun setMap(library: Library) {
        if(CheckConNetwork().checkConnectivity(requireContext()) &&
            library.latitude != null && library.longitude != null && conServer){
            val mappoint = Point(library.latitude!!, library.longitude!!)
            binding.mvFrViewReader.map.move(CameraPosition(mappoint,17.0f, 0.0f,
                0.0f), Animation(Animation.Type.SMOOTH, 1f), null)
            binding.mvFrViewReader.map.mapObjects.addPlacemark(mappoint)

            binding.mvFrViewReader.getMap().addTapListener(this);
            binding.mvFrViewReader.getMap().addInputListener(this);
        }else
            binding.mvFrViewReader.visibility = View.GONE
    }
    override fun onObjectTap(@NonNull geoObjectTapEvent: GeoObjectTapEvent): Boolean {
        /*val selectionMetadata = geoObjectTapEvent
            .geoObject
            .metadataContainer
            .getItem(GeoObjectSelectionMetadata::class.java)
        if (selectionMetadata != null) {
            binding.mvFrViewReader.getMap().selectGeoObject(selectionMetadata.id, selectionMetadata.layerId)
        }
        return selectionMetadata != null*/
        return true
    }

    override fun onMapTap(p0: com.yandex.mapkit.map.Map, p1: Point) {
        //binding.mvFrViewReader.getMap().deselectGeoObject()
    }

    override fun onMapLongTap(p0: Map, p1: Point) {}

    private fun onEditReader() {
        (requireActivity() as EditProfileActivity).replaceEditProfileFragment(reader)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        requireActivity().title = getString(R.string.editUser)
        if(CheckConNetwork().checkConnectivity(requireContext())){
           MapKitFactory.initialize(requireContext())
        }
        binding = FragmentViewReaderBinding.inflate(layoutInflater)

        return binding!!.root
    }

    companion object {

        @JvmStatic
        fun newInstance() =
            ViewReaderFragment()
    }

    override fun onStart() {
        if(CheckConNetwork().checkConnectivity(requireContext())){
            binding.mvFrViewReader.onStart()
            MapKitFactory.getInstance().onStart()
        }
        super.onStart()
    }

    override fun onStop() {
        if(CheckConNetwork().checkConnectivity(requireContext())){
            binding.mvFrViewReader.onStop()
            MapKitFactory.getInstance().onStop()
        }

        super.onStop()
    }
}